<?php
	error_reporting(0);
	include_once "config/koneksi.php";

	$username 		=$_POST['username'];
	$pass_standar 	=$_POST['password'];

	$pass_md5=md5($pass_standar);

	$query="SELECT * FROM standar WHERE username='$username' AND pass='$pass_md5'";

	$login	= mysqli_query($koneksi, $query);
	$ketemu	= mysqli_num_rows($login);
	$data	= mysqli_fetch_array($login);

	// jika user & pass tidak di temukan di db
	if ($ketemu>0 AND $data['aktif']=='Y') {
		session_start();

		$_SESSION['user']=$data['username'];
		$_SESSION['pass']=$data['pass'];

		echo"<script>alert('SELAMAT DATANG !');</script>";
		header("location:standar/index.php");
	}
	elseif ($ketemu>0 AND $data['aktif']=='N') {
		echo "<script>alert('Maaf, Ada tidak dapat mengakses halaman ini..');window.location='index.php';
		</script>";
	}
	else{

		echo "<script>alert('Login GAGAL ! Username dan Password salah');window.location='index.php';
		</script>";
		
	}
?>