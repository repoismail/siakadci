<div class="content-wrapper">
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-warning box-solid">
    
                    <div class="box-header">
                        <h3 class="box-title">KELOLA DATA MAHASISWA</h3>
                    </div>
        
        <div class="box-body">
        <div style="padding-bottom: 10px;"'>
        <?php echo anchor(site_url('mahasiswa/create'), '<i class="fa fa-wpforms" aria-hidden="true"></i> Tambah Data', 'class="btn btn-danger btn-sm"'); ?>
		<?php echo anchor(site_url('mahasiswa/excel'), '<i class="fa fa-file-excel-o" aria-hidden="true"></i> Export Ms Excel', 'class="btn btn-success btn-sm"'); ?>
		<?php echo anchor(site_url('mahasiswa/word'), '<i class="fa fa-file-word-o" aria-hidden="true"></i> Export Ms Word', 'class="btn btn-primary btn-sm"'); ?></div>
        <table class="table table-bordered table-striped" id="mytable">
            <thead>
                <tr>
                    <th width="30px">No</th>
		    <th>Nm Pd</th>
		    <th>Jk</th>
		    <th>Jln</th>
		    <th>Rt</th>
		    <th>Rw</th>
		    <th>Nm Dsn</th>
		    <th>Ds Kel</th>
		    <th>Kode Pos</th>
		    <th>Nisn</th>
		    <th>Nik</th>
		    <th>Tmpt Lahir</th>
		    <th>Tgl Lahir</th>
		    <th>Nm Ayah</th>
		    <th>Tgl Lahir Ayah</th>
		    <th>Nik Ayah</th>
		    <th>Id Jenjang Pendidikan Ayah</th>
		    <th>Id Pekerjaan Ayah</th>
		    <th>Id Penghasilan Ayah</th>
		    <th>Id Kebutuhan Khusus Ayah</th>
		    <th>Nm Ibu Kandung</th>
		    <th>Tgl Lahir Ibu</th>
		    <th>Nik Ibu</th>
		    <th>Id Jenjang Pendidikan Ibu</th>
		    <th>Id Pekerjaan Ibu</th>
		    <th>Id Penghasilan Ibu</th>
		    <th>Id Kebutuhan Khusus Ibu</th>
		    <th>Nm Wali</th>
		    <th>Tgl Lahir Wali</th>
		    <th>Id Jenjang Pendidikan Wali</th>
		    <th>Id Pekerjaan Wali</th>
		    <th>Id Penghasilan Wali</th>
		    <th>Id Kk</th>
		    <th>No Tel Rmh</th>
		    <th>No Hp</th>
		    <th>Email</th>
		    <th>A Terima Kps</th>
		    <th>No Kps</th>
		    <th>Npwp</th>
		    <th>Id Wil</th>
		    <th>Id Jns Tinggal</th>
		    <th>Id Agama</th>
		    <th>Id Alat Transport</th>
		    <th>Kewarganegaraan</th>
		    <th width="200px">Action</th>
                </tr>
            </thead>
	    
        </table>
        </div>
                    </div>
            </div>
            </div>
    </section>
</div>
        <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/datatables/jquery.dataTables.js') ?>"></script>
        <script src="<?php echo base_url('assets/datatables/dataTables.bootstrap.js') ?>"></script>
        <script type="text/javascript">
            $(document).ready(function() {
                $.fn.dataTableExt.oApi.fnPagingInfo = function(oSettings)
                {
                    return {
                        "iStart": oSettings._iDisplayStart,
                        "iEnd": oSettings.fnDisplayEnd(),
                        "iLength": oSettings._iDisplayLength,
                        "iTotal": oSettings.fnRecordsTotal(),
                        "iFilteredTotal": oSettings.fnRecordsDisplay(),
                        "iPage": Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength),
                        "iTotalPages": Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength)
                    };
                };

                var t = $("#mytable").dataTable({
                    initComplete: function() {
                        var api = this.api();
                        $('#mytable_filter input')
                                .off('.DT')
                                .on('keyup.DT', function(e) {
                                    if (e.keyCode == 13) {
                                        api.search(this.value).draw();
                            }
                        });
                    },
                    oLanguage: {
                        sProcessing: "loading..."
                    },
                    processing: true,
                    serverSide: true,
                    ajax: {"url": "mahasiswa/json", "type": "POST"},
                    columns: [
                        {
                            "data": "id_pd",
                            "orderable": false
                        },{"data": "nm_pd"},{"data": "jk"},{"data": "jln"},{"data": "rt"},{"data": "rw"},{"data": "nm_dsn"},{"data": "ds_kel"},{"data": "kode_pos"},{"data": "nisn"},{"data": "nik"},{"data": "tmpt_lahir"},{"data": "tgl_lahir"},{"data": "nm_ayah"},{"data": "tgl_lahir_ayah"},{"data": "nik_ayah"},{"data": "id_jenjang_pendidikan_ayah"},{"data": "id_pekerjaan_ayah"},{"data": "id_penghasilan_ayah"},{"data": "id_kebutuhan_khusus_ayah"},{"data": "nm_ibu_kandung"},{"data": "tgl_lahir_ibu"},{"data": "nik_ibu"},{"data": "id_jenjang_pendidikan_ibu"},{"data": "id_pekerjaan_ibu"},{"data": "id_penghasilan_ibu"},{"data": "id_kebutuhan_khusus_ibu"},{"data": "nm_wali"},{"data": "tgl_lahir_wali"},{"data": "id_jenjang_pendidikan_wali"},{"data": "id_pekerjaan_wali"},{"data": "id_penghasilan_wali"},{"data": "id_kk"},{"data": "no_tel_rmh"},{"data": "no_hp"},{"data": "email"},{"data": "a_terima_kps"},{"data": "no_kps"},{"data": "npwp"},{"data": "id_wil"},{"data": "id_jns_tinggal"},{"data": "id_agama"},{"data": "id_alat_transport"},{"data": "kewarganegaraan"},
                        {
                            "data" : "action",
                            "orderable": false,
                            "className" : "text-center"
                        }
                    ],
                    order: [[0, 'desc']],
                    rowCallback: function(row, data, iDisplayIndex) {
                        var info = this.fnPagingInfo();
                        var page = info.iPage;
                        var length = info.iLength;
                        var index = page * length + (iDisplayIndex + 1);
                        $('td:eq(0)', row).html(index);
                    }
                });
            });
        </script>