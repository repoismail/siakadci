<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Mahasiswa List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Nm Pd</th>
		<th>Jk</th>
		<th>Jln</th>
		<th>Rt</th>
		<th>Rw</th>
		<th>Nm Dsn</th>
		<th>Ds Kel</th>
		<th>Kode Pos</th>
		<th>Nisn</th>
		<th>Nik</th>
		<th>Tmpt Lahir</th>
		<th>Tgl Lahir</th>
		<th>Nm Ayah</th>
		<th>Tgl Lahir Ayah</th>
		<th>Nik Ayah</th>
		<th>Id Jenjang Pendidikan Ayah</th>
		<th>Id Pekerjaan Ayah</th>
		<th>Id Penghasilan Ayah</th>
		<th>Id Kebutuhan Khusus Ayah</th>
		<th>Nm Ibu Kandung</th>
		<th>Tgl Lahir Ibu</th>
		<th>Nik Ibu</th>
		<th>Id Jenjang Pendidikan Ibu</th>
		<th>Id Pekerjaan Ibu</th>
		<th>Id Penghasilan Ibu</th>
		<th>Id Kebutuhan Khusus Ibu</th>
		<th>Nm Wali</th>
		<th>Tgl Lahir Wali</th>
		<th>Id Jenjang Pendidikan Wali</th>
		<th>Id Pekerjaan Wali</th>
		<th>Id Penghasilan Wali</th>
		<th>Id Kk</th>
		<th>No Tel Rmh</th>
		<th>No Hp</th>
		<th>Email</th>
		<th>A Terima Kps</th>
		<th>No Kps</th>
		<th>Npwp</th>
		<th>Id Wil</th>
		<th>Id Jns Tinggal</th>
		<th>Id Agama</th>
		<th>Id Alat Transport</th>
		<th>Kewarganegaraan</th>
		
            </tr><?php
            foreach ($mahasiswa_data as $mahasiswa)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $mahasiswa->nm_pd ?></td>
		      <td><?php echo $mahasiswa->jk ?></td>
		      <td><?php echo $mahasiswa->jln ?></td>
		      <td><?php echo $mahasiswa->rt ?></td>
		      <td><?php echo $mahasiswa->rw ?></td>
		      <td><?php echo $mahasiswa->nm_dsn ?></td>
		      <td><?php echo $mahasiswa->ds_kel ?></td>
		      <td><?php echo $mahasiswa->kode_pos ?></td>
		      <td><?php echo $mahasiswa->nisn ?></td>
		      <td><?php echo $mahasiswa->nik ?></td>
		      <td><?php echo $mahasiswa->tmpt_lahir ?></td>
		      <td><?php echo $mahasiswa->tgl_lahir ?></td>
		      <td><?php echo $mahasiswa->nm_ayah ?></td>
		      <td><?php echo $mahasiswa->tgl_lahir_ayah ?></td>
		      <td><?php echo $mahasiswa->nik_ayah ?></td>
		      <td><?php echo $mahasiswa->id_jenjang_pendidikan_ayah ?></td>
		      <td><?php echo $mahasiswa->id_pekerjaan_ayah ?></td>
		      <td><?php echo $mahasiswa->id_penghasilan_ayah ?></td>
		      <td><?php echo $mahasiswa->id_kebutuhan_khusus_ayah ?></td>
		      <td><?php echo $mahasiswa->nm_ibu_kandung ?></td>
		      <td><?php echo $mahasiswa->tgl_lahir_ibu ?></td>
		      <td><?php echo $mahasiswa->nik_ibu ?></td>
		      <td><?php echo $mahasiswa->id_jenjang_pendidikan_ibu ?></td>
		      <td><?php echo $mahasiswa->id_pekerjaan_ibu ?></td>
		      <td><?php echo $mahasiswa->id_penghasilan_ibu ?></td>
		      <td><?php echo $mahasiswa->id_kebutuhan_khusus_ibu ?></td>
		      <td><?php echo $mahasiswa->nm_wali ?></td>
		      <td><?php echo $mahasiswa->tgl_lahir_wali ?></td>
		      <td><?php echo $mahasiswa->id_jenjang_pendidikan_wali ?></td>
		      <td><?php echo $mahasiswa->id_pekerjaan_wali ?></td>
		      <td><?php echo $mahasiswa->id_penghasilan_wali ?></td>
		      <td><?php echo $mahasiswa->id_kk ?></td>
		      <td><?php echo $mahasiswa->no_tel_rmh ?></td>
		      <td><?php echo $mahasiswa->no_hp ?></td>
		      <td><?php echo $mahasiswa->email ?></td>
		      <td><?php echo $mahasiswa->a_terima_kps ?></td>
		      <td><?php echo $mahasiswa->no_kps ?></td>
		      <td><?php echo $mahasiswa->npwp ?></td>
		      <td><?php echo $mahasiswa->id_wil ?></td>
		      <td><?php echo $mahasiswa->id_jns_tinggal ?></td>
		      <td><?php echo $mahasiswa->id_agama ?></td>
		      <td><?php echo $mahasiswa->id_alat_transport ?></td>
		      <td><?php echo $mahasiswa->kewarganegaraan ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>