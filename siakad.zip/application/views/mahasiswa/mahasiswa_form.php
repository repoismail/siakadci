<div class="content-wrapper">
    
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">INPUT DATA MAHASISWA</h3>
            </div>
            <form action="<?php echo $action; ?>" method="post">
            
<table class='table table-bordered>'        

	    <tr><td width='200'>Nm Pd <?php echo form_error('nm_pd') ?></td><td><input type="text" class="form-control" name="nm_pd" id="nm_pd" placeholder="Nm Pd" value="<?php echo $nm_pd; ?>" /></td></tr>
	    <tr><td width='200'>Jk <?php echo form_error('jk') ?></td><td><input type="text" class="form-control" name="jk" id="jk" placeholder="Jk" value="<?php echo $jk; ?>" /></td></tr>
	    <tr><td width='200'>Jln <?php echo form_error('jln') ?></td><td><input type="text" class="form-control" name="jln" id="jln" placeholder="Jln" value="<?php echo $jln; ?>" /></td></tr>
	    <tr><td width='200'>Rt <?php echo form_error('rt') ?></td><td><input type="text" class="form-control" name="rt" id="rt" placeholder="Rt" value="<?php echo $rt; ?>" /></td></tr>
	    <tr><td width='200'>Rw <?php echo form_error('rw') ?></td><td><input type="text" class="form-control" name="rw" id="rw" placeholder="Rw" value="<?php echo $rw; ?>" /></td></tr>
	    <tr><td width='200'>Nm Dsn <?php echo form_error('nm_dsn') ?></td><td><input type="text" class="form-control" name="nm_dsn" id="nm_dsn" placeholder="Nm Dsn" value="<?php echo $nm_dsn; ?>" /></td></tr>
	    <tr><td width='200'>Ds Kel <?php echo form_error('ds_kel') ?></td><td><input type="text" class="form-control" name="ds_kel" id="ds_kel" placeholder="Ds Kel" value="<?php echo $ds_kel; ?>" /></td></tr>
	    <tr><td width='200'>Kode Pos <?php echo form_error('kode_pos') ?></td><td><input type="text" class="form-control" name="kode_pos" id="kode_pos" placeholder="Kode Pos" value="<?php echo $kode_pos; ?>" /></td></tr>
	    <tr><td width='200'>Nisn <?php echo form_error('nisn') ?></td><td><input type="text" class="form-control" name="nisn" id="nisn" placeholder="Nisn" value="<?php echo $nisn; ?>" /></td></tr>
	    <tr><td width='200'>Nik <?php echo form_error('nik') ?></td><td><input type="text" class="form-control" name="nik" id="nik" placeholder="Nik" value="<?php echo $nik; ?>" /></td></tr>
	    <tr><td width='200'>Tmpt Lahir <?php echo form_error('tmpt_lahir') ?></td><td><input type="text" class="form-control" name="tmpt_lahir" id="tmpt_lahir" placeholder="Tmpt Lahir" value="<?php echo $tmpt_lahir; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Lahir <?php echo form_error('tgl_lahir') ?></td><td><input type="date" class="form-control" name="tgl_lahir" id="tgl_lahir" placeholder="Tgl Lahir" value="<?php echo $tgl_lahir; ?>" /></td></tr>
	    <tr><td width='200'>Nm Ayah <?php echo form_error('nm_ayah') ?></td><td><input type="text" class="form-control" name="nm_ayah" id="nm_ayah" placeholder="Nm Ayah" value="<?php echo $nm_ayah; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Lahir Ayah <?php echo form_error('tgl_lahir_ayah') ?></td><td><input type="date" class="form-control" name="tgl_lahir_ayah" id="tgl_lahir_ayah" placeholder="Tgl Lahir Ayah" value="<?php echo $tgl_lahir_ayah; ?>" /></td></tr>
	    <tr><td width='200'>Nik Ayah <?php echo form_error('nik_ayah') ?></td><td><input type="text" class="form-control" name="nik_ayah" id="nik_ayah" placeholder="Nik Ayah" value="<?php echo $nik_ayah; ?>" /></td></tr>
	    <tr><td width='200'>Id Jenjang Pendidikan Ayah <?php echo form_error('id_jenjang_pendidikan_ayah') ?></td><td><input type="text" class="form-control" name="id_jenjang_pendidikan_ayah" id="id_jenjang_pendidikan_ayah" placeholder="Id Jenjang Pendidikan Ayah" value="<?php echo $id_jenjang_pendidikan_ayah; ?>" /></td></tr>
	    <tr><td width='200'>Id Pekerjaan Ayah <?php echo form_error('id_pekerjaan_ayah') ?></td><td><input type="text" class="form-control" name="id_pekerjaan_ayah" id="id_pekerjaan_ayah" placeholder="Id Pekerjaan Ayah" value="<?php echo $id_pekerjaan_ayah; ?>" /></td></tr>
	    <tr><td width='200'>Id Penghasilan Ayah <?php echo form_error('id_penghasilan_ayah') ?></td><td><input type="text" class="form-control" name="id_penghasilan_ayah" id="id_penghasilan_ayah" placeholder="Id Penghasilan Ayah" value="<?php echo $id_penghasilan_ayah; ?>" /></td></tr>
	    <tr><td width='200'>Id Kebutuhan Khusus Ayah <?php echo form_error('id_kebutuhan_khusus_ayah') ?></td><td><input type="text" class="form-control" name="id_kebutuhan_khusus_ayah" id="id_kebutuhan_khusus_ayah" placeholder="Id Kebutuhan Khusus Ayah" value="<?php echo $id_kebutuhan_khusus_ayah; ?>" /></td></tr>
	    <tr><td width='200'>Nm Ibu Kandung <?php echo form_error('nm_ibu_kandung') ?></td><td><input type="text" class="form-control" name="nm_ibu_kandung" id="nm_ibu_kandung" placeholder="Nm Ibu Kandung" value="<?php echo $nm_ibu_kandung; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Lahir Ibu <?php echo form_error('tgl_lahir_ibu') ?></td><td><input type="date" class="form-control" name="tgl_lahir_ibu" id="tgl_lahir_ibu" placeholder="Tgl Lahir Ibu" value="<?php echo $tgl_lahir_ibu; ?>" /></td></tr>
	    <tr><td width='200'>Nik Ibu <?php echo form_error('nik_ibu') ?></td><td><input type="text" class="form-control" name="nik_ibu" id="nik_ibu" placeholder="Nik Ibu" value="<?php echo $nik_ibu; ?>" /></td></tr>
	    <tr><td width='200'>Id Jenjang Pendidikan Ibu <?php echo form_error('id_jenjang_pendidikan_ibu') ?></td><td><input type="text" class="form-control" name="id_jenjang_pendidikan_ibu" id="id_jenjang_pendidikan_ibu" placeholder="Id Jenjang Pendidikan Ibu" value="<?php echo $id_jenjang_pendidikan_ibu; ?>" /></td></tr>
	    <tr><td width='200'>Id Pekerjaan Ibu <?php echo form_error('id_pekerjaan_ibu') ?></td><td><input type="text" class="form-control" name="id_pekerjaan_ibu" id="id_pekerjaan_ibu" placeholder="Id Pekerjaan Ibu" value="<?php echo $id_pekerjaan_ibu; ?>" /></td></tr>
	    <tr><td width='200'>Id Penghasilan Ibu <?php echo form_error('id_penghasilan_ibu') ?></td><td><input type="text" class="form-control" name="id_penghasilan_ibu" id="id_penghasilan_ibu" placeholder="Id Penghasilan Ibu" value="<?php echo $id_penghasilan_ibu; ?>" /></td></tr>
	    <tr><td width='200'>Id Kebutuhan Khusus Ibu <?php echo form_error('id_kebutuhan_khusus_ibu') ?></td><td><input type="text" class="form-control" name="id_kebutuhan_khusus_ibu" id="id_kebutuhan_khusus_ibu" placeholder="Id Kebutuhan Khusus Ibu" value="<?php echo $id_kebutuhan_khusus_ibu; ?>" /></td></tr>
	    <tr><td width='200'>Nm Wali <?php echo form_error('nm_wali') ?></td><td><input type="text" class="form-control" name="nm_wali" id="nm_wali" placeholder="Nm Wali" value="<?php echo $nm_wali; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Lahir Wali <?php echo form_error('tgl_lahir_wali') ?></td><td><input type="date" class="form-control" name="tgl_lahir_wali" id="tgl_lahir_wali" placeholder="Tgl Lahir Wali" value="<?php echo $tgl_lahir_wali; ?>" /></td></tr>
	    <tr><td width='200'>Id Jenjang Pendidikan Wali <?php echo form_error('id_jenjang_pendidikan_wali') ?></td><td><input type="text" class="form-control" name="id_jenjang_pendidikan_wali" id="id_jenjang_pendidikan_wali" placeholder="Id Jenjang Pendidikan Wali" value="<?php echo $id_jenjang_pendidikan_wali; ?>" /></td></tr>
	    <tr><td width='200'>Id Pekerjaan Wali <?php echo form_error('id_pekerjaan_wali') ?></td><td><input type="text" class="form-control" name="id_pekerjaan_wali" id="id_pekerjaan_wali" placeholder="Id Pekerjaan Wali" value="<?php echo $id_pekerjaan_wali; ?>" /></td></tr>
	    <tr><td width='200'>Id Penghasilan Wali <?php echo form_error('id_penghasilan_wali') ?></td><td><input type="text" class="form-control" name="id_penghasilan_wali" id="id_penghasilan_wali" placeholder="Id Penghasilan Wali" value="<?php echo $id_penghasilan_wali; ?>" /></td></tr>
	    <tr><td width='200'>Id Kk <?php echo form_error('id_kk') ?></td><td><input type="text" class="form-control" name="id_kk" id="id_kk" placeholder="Id Kk" value="<?php echo $id_kk; ?>" /></td></tr>
	    <tr><td width='200'>No Tel Rmh <?php echo form_error('no_tel_rmh') ?></td><td><input type="text" class="form-control" name="no_tel_rmh" id="no_tel_rmh" placeholder="No Tel Rmh" value="<?php echo $no_tel_rmh; ?>" /></td></tr>
	    <tr><td width='200'>No Hp <?php echo form_error('no_hp') ?></td><td><input type="text" class="form-control" name="no_hp" id="no_hp" placeholder="No Hp" value="<?php echo $no_hp; ?>" /></td></tr>
	    <tr><td width='200'>Email <?php echo form_error('email') ?></td><td><input type="text" class="form-control" name="email" id="email" placeholder="Email" value="<?php echo $email; ?>" /></td></tr>
	    <tr><td width='200'>A Terima Kps <?php echo form_error('a_terima_kps') ?></td><td><input type="text" class="form-control" name="a_terima_kps" id="a_terima_kps" placeholder="A Terima Kps" value="<?php echo $a_terima_kps; ?>" /></td></tr>
	    <tr><td width='200'>No Kps <?php echo form_error('no_kps') ?></td><td><input type="text" class="form-control" name="no_kps" id="no_kps" placeholder="No Kps" value="<?php echo $no_kps; ?>" /></td></tr>
	    <tr><td width='200'>Npwp <?php echo form_error('npwp') ?></td><td><input type="text" class="form-control" name="npwp" id="npwp" placeholder="Npwp" value="<?php echo $npwp; ?>" /></td></tr>
	    <tr><td width='200'>Id Wil <?php echo form_error('id_wil') ?></td><td><input type="text" class="form-control" name="id_wil" id="id_wil" placeholder="Id Wil" value="<?php echo $id_wil; ?>" /></td></tr>
	    <tr><td width='200'>Id Jns Tinggal <?php echo form_error('id_jns_tinggal') ?></td><td><input type="text" class="form-control" name="id_jns_tinggal" id="id_jns_tinggal" placeholder="Id Jns Tinggal" value="<?php echo $id_jns_tinggal; ?>" /></td></tr>
	    <tr><td width='200'>Id Agama <?php echo form_error('id_agama') ?></td><td><input type="text" class="form-control" name="id_agama" id="id_agama" placeholder="Id Agama" value="<?php echo $id_agama; ?>" /></td></tr>
	    <tr><td width='200'>Id Alat Transport <?php echo form_error('id_alat_transport') ?></td><td><input type="text" class="form-control" name="id_alat_transport" id="id_alat_transport" placeholder="Id Alat Transport" value="<?php echo $id_alat_transport; ?>" /></td></tr>
	    <tr><td width='200'>Kewarganegaraan <?php echo form_error('kewarganegaraan') ?></td><td><input type="text" class="form-control" name="kewarganegaraan" id="kewarganegaraan" placeholder="Kewarganegaraan" value="<?php echo $kewarganegaraan; ?>" /></td></tr>
	    <tr><td></td><td><input type="hidden" name="id_pd" value="<?php echo $id_pd; ?>" /> 
	    <button type="submit" class="btn btn-danger"><i class="fa fa-floppy-o"></i> <?php echo $button ?></button> 
	    <a href="<?php echo site_url('mahasiswa') ?>" class="btn btn-info"><i class="fa fa-sign-out"></i> Kembali</a></td></tr>
	</table></form>        </div>
</div>
</div>