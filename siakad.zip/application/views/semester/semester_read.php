<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Semester Read</h2>
        <table class="table">
	    <tr><td>Id Thn Ajaran</td><td><?php echo $id_thn_ajaran; ?></td></tr>
	    <tr><td>Nm Smt</td><td><?php echo $nm_smt; ?></td></tr>
	    <tr><td>Smt</td><td><?php echo $smt; ?></td></tr>
	    <tr><td>A Periode Aktif</td><td><?php echo $a_periode_aktif; ?></td></tr>
	    <tr><td>Tgl Mulai</td><td><?php echo $tgl_mulai; ?></td></tr>
	    <tr><td>Tgl Selesai</td><td><?php echo $tgl_selesai; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('semester') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>