<div class="content-wrapper">
    
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">INPUT DATA SEMESTER</h3>
            </div>
            <form action="<?php echo $action; ?>" method="post">
            
<table class='table table-bordered>'        

	    <tr><td width='200'>Id Thn Ajaran <?php echo form_error('id_thn_ajaran') ?></td><td><input type="text" class="form-control" name="id_thn_ajaran" id="id_thn_ajaran" placeholder="Id Thn Ajaran" value="<?php echo $id_thn_ajaran; ?>" /></td></tr>
	    <tr><td width='200'>Nm Smt <?php echo form_error('nm_smt') ?></td><td><input type="text" class="form-control" name="nm_smt" id="nm_smt" placeholder="Nm Smt" value="<?php echo $nm_smt; ?>" /></td></tr>
	    <tr><td width='200'>Smt <?php echo form_error('smt') ?></td><td><input type="text" class="form-control" name="smt" id="smt" placeholder="Smt" value="<?php echo $smt; ?>" /></td></tr>
	    <tr><td width='200'>A Periode Aktif <?php echo form_error('a_periode_aktif') ?></td><td><input type="text" class="form-control" name="a_periode_aktif" id="a_periode_aktif" placeholder="A Periode Aktif" value="<?php echo $a_periode_aktif; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Mulai <?php echo form_error('tgl_mulai') ?></td><td><input type="date" class="form-control" name="tgl_mulai" id="tgl_mulai" placeholder="Tgl Mulai" value="<?php echo $tgl_mulai; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Selesai <?php echo form_error('tgl_selesai') ?></td><td><input type="date" class="form-control" name="tgl_selesai" id="tgl_selesai" placeholder="Tgl Selesai" value="<?php echo $tgl_selesai; ?>" /></td></tr>
	    <tr><td></td><td><input type="hidden" name="id_smt" value="<?php echo $id_smt; ?>" /> 
	    <button type="submit" class="btn btn-danger"><i class="fa fa-floppy-o"></i> <?php echo $button ?></button> 
	    <a href="<?php echo site_url('semester') ?>" class="btn btn-info"><i class="fa fa-sign-out"></i> Kembali</a></td></tr>
	</table></form>        </div>
</div>
</div>