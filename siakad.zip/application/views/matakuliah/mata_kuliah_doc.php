<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Mata_kuliah List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Id Sms</th>
		<th>Id Jenj Didik</th>
		<th>Kode Mk</th>
		<th>Nm Mk</th>
		<th>Jns Mk</th>
		<th>Kel Mk</th>
		<th>Sks Mk</th>
		<th>Sks Tm</th>
		<th>Sks Prak</th>
		<th>Sks Prak Lap</th>
		<th>Sks Sim</th>
		<th>Metode Pelaksanaan Kuliah</th>
		<th>A Sap</th>
		<th>A Silabus</th>
		<th>A Bahan Ajar</th>
		<th>Acara Prak</th>
		<th>A Diktat</th>
		<th>Tgl Mulai Efektif</th>
		<th>Tgl Akhir Efektif</th>
		
            </tr><?php
            foreach ($matakuliah_data as $matakuliah)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $matakuliah->id_sms ?></td>
		      <td><?php echo $matakuliah->id_jenj_didik ?></td>
		      <td><?php echo $matakuliah->kode_mk ?></td>
		      <td><?php echo $matakuliah->nm_mk ?></td>
		      <td><?php echo $matakuliah->jns_mk ?></td>
		      <td><?php echo $matakuliah->kel_mk ?></td>
		      <td><?php echo $matakuliah->sks_mk ?></td>
		      <td><?php echo $matakuliah->sks_tm ?></td>
		      <td><?php echo $matakuliah->sks_prak ?></td>
		      <td><?php echo $matakuliah->sks_prak_lap ?></td>
		      <td><?php echo $matakuliah->sks_sim ?></td>
		      <td><?php echo $matakuliah->metode_pelaksanaan_kuliah ?></td>
		      <td><?php echo $matakuliah->a_sap ?></td>
		      <td><?php echo $matakuliah->a_silabus ?></td>
		      <td><?php echo $matakuliah->a_bahan_ajar ?></td>
		      <td><?php echo $matakuliah->acara_prak ?></td>
		      <td><?php echo $matakuliah->a_diktat ?></td>
		      <td><?php echo $matakuliah->tgl_mulai_efektif ?></td>
		      <td><?php echo $matakuliah->tgl_akhir_efektif ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>