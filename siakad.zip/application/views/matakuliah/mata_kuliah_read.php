<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Mata_kuliah Read</h2>
        <table class="table">
	    <tr><td>Id Sms</td><td><?php echo $id_sms; ?></td></tr>
	    <tr><td>Id Jenj Didik</td><td><?php echo $id_jenj_didik; ?></td></tr>
	    <tr><td>Kode Mk</td><td><?php echo $kode_mk; ?></td></tr>
	    <tr><td>Nm Mk</td><td><?php echo $nm_mk; ?></td></tr>
	    <tr><td>Jns Mk</td><td><?php echo $jns_mk; ?></td></tr>
	    <tr><td>Kel Mk</td><td><?php echo $kel_mk; ?></td></tr>
	    <tr><td>Sks Mk</td><td><?php echo $sks_mk; ?></td></tr>
	    <tr><td>Sks Tm</td><td><?php echo $sks_tm; ?></td></tr>
	    <tr><td>Sks Prak</td><td><?php echo $sks_prak; ?></td></tr>
	    <tr><td>Sks Prak Lap</td><td><?php echo $sks_prak_lap; ?></td></tr>
	    <tr><td>Sks Sim</td><td><?php echo $sks_sim; ?></td></tr>
	    <tr><td>Metode Pelaksanaan Kuliah</td><td><?php echo $metode_pelaksanaan_kuliah; ?></td></tr>
	    <tr><td>A Sap</td><td><?php echo $a_sap; ?></td></tr>
	    <tr><td>A Silabus</td><td><?php echo $a_silabus; ?></td></tr>
	    <tr><td>A Bahan Ajar</td><td><?php echo $a_bahan_ajar; ?></td></tr>
	    <tr><td>Acara Prak</td><td><?php echo $acara_prak; ?></td></tr>
	    <tr><td>A Diktat</td><td><?php echo $a_diktat; ?></td></tr>
	    <tr><td>Tgl Mulai Efektif</td><td><?php echo $tgl_mulai_efektif; ?></td></tr>
	    <tr><td>Tgl Akhir Efektif</td><td><?php echo $tgl_akhir_efektif; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('matakuliah') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>