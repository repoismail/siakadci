<div class="content-wrapper">
    
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">INPUT DATA MATA_KULIAH</h3>
            </div>
            <form action="<?php echo $action; ?>" method="post">
            
<table class='table table-bordered>'        

	    <tr><td width='200'>Id Sms <?php echo form_error('id_sms') ?></td><td><input type="text" class="form-control" name="id_sms" id="id_sms" placeholder="Id Sms" value="<?php echo $id_sms; ?>" /></td></tr>
	    <tr><td width='200'>Id Jenj Didik <?php echo form_error('id_jenj_didik') ?></td><td><input type="text" class="form-control" name="id_jenj_didik" id="id_jenj_didik" placeholder="Id Jenj Didik" value="<?php echo $id_jenj_didik; ?>" /></td></tr>
	    <tr><td width='200'>Kode Mk <?php echo form_error('kode_mk') ?></td><td><input type="text" class="form-control" name="kode_mk" id="kode_mk" placeholder="Kode Mk" value="<?php echo $kode_mk; ?>" /></td></tr>
	    <tr><td width='200'>Nm Mk <?php echo form_error('nm_mk') ?></td><td><input type="text" class="form-control" name="nm_mk" id="nm_mk" placeholder="Nm Mk" value="<?php echo $nm_mk; ?>" /></td></tr>
	    <tr><td width='200'>Jns Mk <?php echo form_error('jns_mk') ?></td><td><input type="text" class="form-control" name="jns_mk" id="jns_mk" placeholder="Jns Mk" value="<?php echo $jns_mk; ?>" /></td></tr>
	    <tr><td width='200'>Kel Mk <?php echo form_error('kel_mk') ?></td><td><input type="text" class="form-control" name="kel_mk" id="kel_mk" placeholder="Kel Mk" value="<?php echo $kel_mk; ?>" /></td></tr>
	    <tr><td width='200'>Sks Mk <?php echo form_error('sks_mk') ?></td><td><input type="text" class="form-control" name="sks_mk" id="sks_mk" placeholder="Sks Mk" value="<?php echo $sks_mk; ?>" /></td></tr>
	    <tr><td width='200'>Sks Tm <?php echo form_error('sks_tm') ?></td><td><input type="text" class="form-control" name="sks_tm" id="sks_tm" placeholder="Sks Tm" value="<?php echo $sks_tm; ?>" /></td></tr>
	    <tr><td width='200'>Sks Prak <?php echo form_error('sks_prak') ?></td><td><input type="text" class="form-control" name="sks_prak" id="sks_prak" placeholder="Sks Prak" value="<?php echo $sks_prak; ?>" /></td></tr>
	    <tr><td width='200'>Sks Prak Lap <?php echo form_error('sks_prak_lap') ?></td><td><input type="text" class="form-control" name="sks_prak_lap" id="sks_prak_lap" placeholder="Sks Prak Lap" value="<?php echo $sks_prak_lap; ?>" /></td></tr>
	    <tr><td width='200'>Sks Sim <?php echo form_error('sks_sim') ?></td><td><input type="text" class="form-control" name="sks_sim" id="sks_sim" placeholder="Sks Sim" value="<?php echo $sks_sim; ?>" /></td></tr>
	    <tr><td width='200'>Metode Pelaksanaan Kuliah <?php echo form_error('metode_pelaksanaan_kuliah') ?></td><td><input type="text" class="form-control" name="metode_pelaksanaan_kuliah" id="metode_pelaksanaan_kuliah" placeholder="Metode Pelaksanaan Kuliah" value="<?php echo $metode_pelaksanaan_kuliah; ?>" /></td></tr>
	    <tr><td width='200'>A Sap <?php echo form_error('a_sap') ?></td><td><input type="text" class="form-control" name="a_sap" id="a_sap" placeholder="A Sap" value="<?php echo $a_sap; ?>" /></td></tr>
	    <tr><td width='200'>A Silabus <?php echo form_error('a_silabus') ?></td><td><input type="text" class="form-control" name="a_silabus" id="a_silabus" placeholder="A Silabus" value="<?php echo $a_silabus; ?>" /></td></tr>
	    <tr><td width='200'>A Bahan Ajar <?php echo form_error('a_bahan_ajar') ?></td><td><input type="text" class="form-control" name="a_bahan_ajar" id="a_bahan_ajar" placeholder="A Bahan Ajar" value="<?php echo $a_bahan_ajar; ?>" /></td></tr>
	    <tr><td width='200'>Acara Prak <?php echo form_error('acara_prak') ?></td><td><input type="text" class="form-control" name="acara_prak" id="acara_prak" placeholder="Acara Prak" value="<?php echo $acara_prak; ?>" /></td></tr>
	    <tr><td width='200'>A Diktat <?php echo form_error('a_diktat') ?></td><td><input type="text" class="form-control" name="a_diktat" id="a_diktat" placeholder="A Diktat" value="<?php echo $a_diktat; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Mulai Efektif <?php echo form_error('tgl_mulai_efektif') ?></td><td><input type="date" class="form-control" name="tgl_mulai_efektif" id="tgl_mulai_efektif" placeholder="Tgl Mulai Efektif" value="<?php echo $tgl_mulai_efektif; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Akhir Efektif <?php echo form_error('tgl_akhir_efektif') ?></td><td><input type="date" class="form-control" name="tgl_akhir_efektif" id="tgl_akhir_efektif" placeholder="Tgl Akhir Efektif" value="<?php echo $tgl_akhir_efektif; ?>" /></td></tr>
	    <tr><td></td><td><input type="hidden" name="id_mk" value="<?php echo $id_mk; ?>" /> 
	    <button type="submit" class="btn btn-danger"><i class="fa fa-floppy-o"></i> <?php echo $button ?></button> 
	    <a href="<?php echo site_url('matakuliah') ?>" class="btn btn-info"><i class="fa fa-sign-out"></i> Kembali</a></td></tr>
	</table></form>        </div>
</div>
</div>