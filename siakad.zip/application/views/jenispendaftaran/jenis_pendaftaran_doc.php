<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Jenis_pendaftaran List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Nm Jns Daftar</th>
		<th>U Daftar Sekolah</th>
		<th>U Daftar Rombel</th>
		
            </tr><?php
            foreach ($jenispendaftaran_data as $jenispendaftaran)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $jenispendaftaran->nm_jns_daftar ?></td>
		      <td><?php echo $jenispendaftaran->u_daftar_sekolah ?></td>
		      <td><?php echo $jenispendaftaran->u_daftar_rombel ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>