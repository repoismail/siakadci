<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Jenis_pendaftaran Read</h2>
        <table class="table">
	    <tr><td>Nm Jns Daftar</td><td><?php echo $nm_jns_daftar; ?></td></tr>
	    <tr><td>U Daftar Sekolah</td><td><?php echo $u_daftar_sekolah; ?></td></tr>
	    <tr><td>U Daftar Rombel</td><td><?php echo $u_daftar_rombel; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('jenispendaftaran') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>