<div class="content-wrapper">
    
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">INPUT DATA JENIS_PENDAFTARAN</h3>
            </div>
            <form action="<?php echo $action; ?>" method="post">
            
<table class='table table-bordered>'        

	    <tr><td width='200'>Nm Jns Daftar <?php echo form_error('nm_jns_daftar') ?></td><td><input type="text" class="form-control" name="nm_jns_daftar" id="nm_jns_daftar" placeholder="Nm Jns Daftar" value="<?php echo $nm_jns_daftar; ?>" /></td></tr>
	    <tr><td width='200'>U Daftar Sekolah <?php echo form_error('u_daftar_sekolah') ?></td><td><input type="text" class="form-control" name="u_daftar_sekolah" id="u_daftar_sekolah" placeholder="U Daftar Sekolah" value="<?php echo $u_daftar_sekolah; ?>" /></td></tr>
	    <tr><td width='200'>U Daftar Rombel <?php echo form_error('u_daftar_rombel') ?></td><td><input type="text" class="form-control" name="u_daftar_rombel" id="u_daftar_rombel" placeholder="U Daftar Rombel" value="<?php echo $u_daftar_rombel; ?>" /></td></tr>
	    <tr><td></td><td><input type="hidden" name="id_jns_daftar" value="<?php echo $id_jns_daftar; ?>" /> 
	    <button type="submit" class="btn btn-danger"><i class="fa fa-floppy-o"></i> <?php echo $button ?></button> 
	    <a href="<?php echo site_url('jenispendaftaran') ?>" class="btn btn-info"><i class="fa fa-sign-out"></i> Kembali</a></td></tr>
	</table></form>        </div>
</div>
</div>