<div class="content-wrapper">
    
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">INPUT DATA SMS</h3>
            </div>
            <form action="<?php echo $action; ?>" method="post">
            
<table class='table table-bordered>'        

	    <tr><td width='200'>Nm Lemb <?php echo form_error('nm_lemb') ?></td><td><input type="text" class="form-control" name="nm_lemb" id="nm_lemb" placeholder="Nm Lemb" value="<?php echo $nm_lemb; ?>" /></td></tr>
	    <tr><td width='200'>Smt Mulai <?php echo form_error('smt_mulai') ?></td><td><input type="text" class="form-control" name="smt_mulai" id="smt_mulai" placeholder="Smt Mulai" value="<?php echo $smt_mulai; ?>" /></td></tr>
	    <tr><td width='200'>Kode Prodi <?php echo form_error('kode_prodi') ?></td><td><input type="text" class="form-control" name="kode_prodi" id="kode_prodi" placeholder="Kode Prodi" value="<?php echo $kode_prodi; ?>" /></td></tr>
	    <tr><td width='200'>Nm Prodi English <?php echo form_error('nm_prodi_english') ?></td><td><input type="text" class="form-control" name="nm_prodi_english" id="nm_prodi_english" placeholder="Nm Prodi English" value="<?php echo $nm_prodi_english; ?>" /></td></tr>
	    <tr><td width='200'>Jln <?php echo form_error('jln') ?></td><td><input type="text" class="form-control" name="jln" id="jln" placeholder="Jln" value="<?php echo $jln; ?>" /></td></tr>
	    <tr><td width='200'>Rt <?php echo form_error('rt') ?></td><td><input type="text" class="form-control" name="rt" id="rt" placeholder="Rt" value="<?php echo $rt; ?>" /></td></tr>
	    <tr><td width='200'>Rw <?php echo form_error('rw') ?></td><td><input type="text" class="form-control" name="rw" id="rw" placeholder="Rw" value="<?php echo $rw; ?>" /></td></tr>
	    <tr><td width='200'>Nm Dsn <?php echo form_error('nm_dsn') ?></td><td><input type="text" class="form-control" name="nm_dsn" id="nm_dsn" placeholder="Nm Dsn" value="<?php echo $nm_dsn; ?>" /></td></tr>
	    <tr><td width='200'>Ds Kel <?php echo form_error('ds_kel') ?></td><td><input type="text" class="form-control" name="ds_kel" id="ds_kel" placeholder="Ds Kel" value="<?php echo $ds_kel; ?>" /></td></tr>
	    <tr><td width='200'>Kode Pos <?php echo form_error('kode_pos') ?></td><td><input type="text" class="form-control" name="kode_pos" id="kode_pos" placeholder="Kode Pos" value="<?php echo $kode_pos; ?>" /></td></tr>
	    <tr><td width='200'>Lintang <?php echo form_error('lintang') ?></td><td><input type="text" class="form-control" name="lintang" id="lintang" placeholder="Lintang" value="<?php echo $lintang; ?>" /></td></tr>
	    <tr><td width='200'>Bujur <?php echo form_error('bujur') ?></td><td><input type="text" class="form-control" name="bujur" id="bujur" placeholder="Bujur" value="<?php echo $bujur; ?>" /></td></tr>
	    <tr><td width='200'>No Tel <?php echo form_error('no_tel') ?></td><td><input type="text" class="form-control" name="no_tel" id="no_tel" placeholder="No Tel" value="<?php echo $no_tel; ?>" /></td></tr>
	    <tr><td width='200'>No Fax <?php echo form_error('no_fax') ?></td><td><input type="text" class="form-control" name="no_fax" id="no_fax" placeholder="No Fax" value="<?php echo $no_fax; ?>" /></td></tr>
	    <tr><td width='200'>Email <?php echo form_error('email') ?></td><td><input type="text" class="form-control" name="email" id="email" placeholder="Email" value="<?php echo $email; ?>" /></td></tr>
	    <tr><td width='200'>Website <?php echo form_error('website') ?></td><td><input type="text" class="form-control" name="website" id="website" placeholder="Website" value="<?php echo $website; ?>" /></td></tr>
	    <tr><td width='200'>Singkatan <?php echo form_error('singkatan') ?></td><td><input type="text" class="form-control" name="singkatan" id="singkatan" placeholder="Singkatan" value="<?php echo $singkatan; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Berdiri <?php echo form_error('tgl_berdiri') ?></td><td><input type="date" class="form-control" name="tgl_berdiri" id="tgl_berdiri" placeholder="Tgl Berdiri" value="<?php echo $tgl_berdiri; ?>" /></td></tr>
	    <tr><td width='200'>Sk Selenggara <?php echo form_error('sk_selenggara') ?></td><td><input type="text" class="form-control" name="sk_selenggara" id="sk_selenggara" placeholder="Sk Selenggara" value="<?php echo $sk_selenggara; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Sk Selenggara <?php echo form_error('tgl_sk_selenggara') ?></td><td><input type="date" class="form-control" name="tgl_sk_selenggara" id="tgl_sk_selenggara" placeholder="Tgl Sk Selenggara" value="<?php echo $tgl_sk_selenggara; ?>" /></td></tr>
	    <tr><td width='200'>Tmt Sk Selenggara <?php echo form_error('tmt_sk_selenggara') ?></td><td><input type="date" class="form-control" name="tmt_sk_selenggara" id="tmt_sk_selenggara" placeholder="Tmt Sk Selenggara" value="<?php echo $tmt_sk_selenggara; ?>" /></td></tr>
	    <tr><td width='200'>Tst Sk Selenggara <?php echo form_error('tst_sk_selenggara') ?></td><td><input type="date" class="form-control" name="tst_sk_selenggara" id="tst_sk_selenggara" placeholder="Tst Sk Selenggara" value="<?php echo $tst_sk_selenggara; ?>" /></td></tr>
	    <tr><td width='200'>Kpst Pd <?php echo form_error('kpst_pd') ?></td><td><input type="text" class="form-control" name="kpst_pd" id="kpst_pd" placeholder="Kpst Pd" value="<?php echo $kpst_pd; ?>" /></td></tr>
	    <tr><td width='200'>Sks Lulus <?php echo form_error('sks_lulus') ?></td><td><input type="text" class="form-control" name="sks_lulus" id="sks_lulus" placeholder="Sks Lulus" value="<?php echo $sks_lulus; ?>" /></td></tr>
	    <tr><td width='200'>Gelar Lulusan <?php echo form_error('gelar_lulusan') ?></td><td><input type="text" class="form-control" name="gelar_lulusan" id="gelar_lulusan" placeholder="Gelar Lulusan" value="<?php echo $gelar_lulusan; ?>" /></td></tr>
	    <tr><td width='200'>Stat Prodi <?php echo form_error('stat_prodi') ?></td><td><input type="text" class="form-control" name="stat_prodi" id="stat_prodi" placeholder="Stat Prodi" value="<?php echo $stat_prodi; ?>" /></td></tr>
	    <tr><td width='200'>Polesei Nilai <?php echo form_error('polesei_nilai') ?></td><td><input type="text" class="form-control" name="polesei_nilai" id="polesei_nilai" placeholder="Polesei Nilai" value="<?php echo $polesei_nilai; ?>" /></td></tr>
	    <tr><td width='200'>A Kependidikan <?php echo form_error('a_kependidikan') ?></td><td><input type="text" class="form-control" name="a_kependidikan" id="a_kependidikan" placeholder="A Kependidikan" value="<?php echo $a_kependidikan; ?>" /></td></tr>
	    <tr><td width='200'>Sistem Ajar <?php echo form_error('sistem_ajar') ?></td><td><input type="text" class="form-control" name="sistem_ajar" id="sistem_ajar" placeholder="Sistem Ajar" value="<?php echo $sistem_ajar; ?>" /></td></tr>
	    <tr><td width='200'>Luas Lab <?php echo form_error('luas_lab') ?></td><td><input type="text" class="form-control" name="luas_lab" id="luas_lab" placeholder="Luas Lab" value="<?php echo $luas_lab; ?>" /></td></tr>
	    <tr><td width='200'>Kapasitas Prak Satu Shift <?php echo form_error('kapasitas_prak_satu_shift') ?></td><td><input type="text" class="form-control" name="kapasitas_prak_satu_shift" id="kapasitas_prak_satu_shift" placeholder="Kapasitas Prak Satu Shift" value="<?php echo $kapasitas_prak_satu_shift; ?>" /></td></tr>
	    <tr><td width='200'>Jml Mhs Pengguna <?php echo form_error('jml_mhs_pengguna') ?></td><td><input type="text" class="form-control" name="jml_mhs_pengguna" id="jml_mhs_pengguna" placeholder="Jml Mhs Pengguna" value="<?php echo $jml_mhs_pengguna; ?>" /></td></tr>
	    <tr><td width='200'>Jml Jam Penggunaan <?php echo form_error('jml_jam_penggunaan') ?></td><td><input type="text" class="form-control" name="jml_jam_penggunaan" id="jml_jam_penggunaan" placeholder="Jml Jam Penggunaan" value="<?php echo $jml_jam_penggunaan; ?>" /></td></tr>
	    <tr><td width='200'>Jml Prodi Pengguna <?php echo form_error('jml_prodi_pengguna') ?></td><td><input type="text" class="form-control" name="jml_prodi_pengguna" id="jml_prodi_pengguna" placeholder="Jml Prodi Pengguna" value="<?php echo $jml_prodi_pengguna; ?>" /></td></tr>
	    <tr><td width='200'>Jml Modul Prak Sendiri <?php echo form_error('jml_modul_prak_sendiri') ?></td><td><input type="text" class="form-control" name="jml_modul_prak_sendiri" id="jml_modul_prak_sendiri" placeholder="Jml Modul Prak Sendiri" value="<?php echo $jml_modul_prak_sendiri; ?>" /></td></tr>
	    <tr><td width='200'>Jml Modul Prak Lain <?php echo form_error('jml_modul_prak_lain') ?></td><td><input type="text" class="form-control" name="jml_modul_prak_lain" id="jml_modul_prak_lain" placeholder="Jml Modul Prak Lain" value="<?php echo $jml_modul_prak_lain; ?>" /></td></tr>
	    <tr><td width='200'>Fungsi Selain Prak <?php echo form_error('fungsi_selain_prak') ?></td><td><input type="text" class="form-control" name="fungsi_selain_prak" id="fungsi_selain_prak" placeholder="Fungsi Selain Prak" value="<?php echo $fungsi_selain_prak; ?>" /></td></tr>
	    <tr><td width='200'>Penggunaan Lab <?php echo form_error('penggunaan_lab') ?></td><td><input type="text" class="form-control" name="penggunaan_lab" id="penggunaan_lab" placeholder="Penggunaan Lab" value="<?php echo $penggunaan_lab; ?>" /></td></tr>
	    <tr><td width='200'>Id Sp <?php echo form_error('id_sp') ?></td><td><input type="text" class="form-control" name="id_sp" id="id_sp" placeholder="Id Sp" value="<?php echo $id_sp; ?>" /></td></tr>
	    <tr><td width='200'>Id Jenj Didik <?php echo form_error('id_jenj_didik') ?></td><td><input type="text" class="form-control" name="id_jenj_didik" id="id_jenj_didik" placeholder="Id Jenj Didik" value="<?php echo $id_jenj_didik; ?>" /></td></tr>
	    <tr><td width='200'>Id Jns Sms <?php echo form_error('id_jns_sms') ?></td><td><input type="text" class="form-control" name="id_jns_sms" id="id_jns_sms" placeholder="Id Jns Sms" value="<?php echo $id_jns_sms; ?>" /></td></tr>
	    <tr><td width='200'>Id Fungsi Lab <?php echo form_error('id_fungsi_lab') ?></td><td><input type="text" class="form-control" name="id_fungsi_lab" id="id_fungsi_lab" placeholder="Id Fungsi Lab" value="<?php echo $id_fungsi_lab; ?>" /></td></tr>
	    <tr><td width='200'>Id Kel Usaha <?php echo form_error('id_kel_usaha') ?></td><td><input type="text" class="form-control" name="id_kel_usaha" id="id_kel_usaha" placeholder="Id Kel Usaha" value="<?php echo $id_kel_usaha; ?>" /></td></tr>
	    <tr><td width='200'>Id Blob <?php echo form_error('id_blob') ?></td><td><input type="text" class="form-control" name="id_blob" id="id_blob" placeholder="Id Blob" value="<?php echo $id_blob; ?>" /></td></tr>
	    <tr><td width='200'>Id Wil <?php echo form_error('id_wil') ?></td><td><input type="text" class="form-control" name="id_wil" id="id_wil" placeholder="Id Wil" value="<?php echo $id_wil; ?>" /></td></tr>
	    <tr><td width='200'>Id Jur <?php echo form_error('id_jur') ?></td><td><input type="text" class="form-control" name="id_jur" id="id_jur" placeholder="Id Jur" value="<?php echo $id_jur; ?>" /></td></tr>
	    <tr><td width='200'>Id Induk Sms <?php echo form_error('id_induk_sms') ?></td><td><input type="text" class="form-control" name="id_induk_sms" id="id_induk_sms" placeholder="Id Induk Sms" value="<?php echo $id_induk_sms; ?>" /></td></tr>
	    <tr><td></td><td><input type="hidden" name="id_sms" value="<?php echo $id_sms; ?>" /> 
	    <button type="submit" class="btn btn-danger"><i class="fa fa-floppy-o"></i> <?php echo $button ?></button> 
	    <a href="<?php echo site_url('sms') ?>" class="btn btn-info"><i class="fa fa-sign-out"></i> Kembali</a></td></tr>
	</table></form>        </div>
</div>
</div>