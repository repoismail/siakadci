<div class="content-wrapper">
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-warning box-solid">
    
                    <div class="box-header">
                        <h3 class="box-title">KELOLA DATA SMS</h3>
                    </div>
        
        <div class="box-body">
        <div style="padding-bottom: 10px;"'>
        <?php echo anchor(site_url('sms/create'), '<i class="fa fa-wpforms" aria-hidden="true"></i> Tambah Data', 'class="btn btn-danger btn-sm"'); ?>
		<?php echo anchor(site_url('sms/excel'), '<i class="fa fa-file-excel-o" aria-hidden="true"></i> Export Ms Excel', 'class="btn btn-success btn-sm"'); ?>
		<?php echo anchor(site_url('sms/word'), '<i class="fa fa-file-word-o" aria-hidden="true"></i> Export Ms Word', 'class="btn btn-primary btn-sm"'); ?></div>
        <table class="table table-bordered table-striped" id="mytable">
            <thead>
                <tr>
                    <th width="30px">No</th>
		    <th>Nm Lemb</th>
		    <th>Smt Mulai</th>
		    <th>Kode Prodi</th>
		    <th>Nm Prodi English</th>
		    <th>Jln</th>
		    <th>Rt</th>
		    <th>Rw</th>
		    <th>Nm Dsn</th>
		    <th>Ds Kel</th>
		    <th>Kode Pos</th>
		    <th>Lintang</th>
		    <th>Bujur</th>
		    <th>No Tel</th>
		    <th>No Fax</th>
		    <th>Email</th>
		    <th>Website</th>
		    <th>Singkatan</th>
		    <th>Tgl Berdiri</th>
		    <th>Sk Selenggara</th>
		    <th>Tgl Sk Selenggara</th>
		    <th>Tmt Sk Selenggara</th>
		    <th>Tst Sk Selenggara</th>
		    <th>Kpst Pd</th>
		    <th>Sks Lulus</th>
		    <th>Gelar Lulusan</th>
		    <th>Stat Prodi</th>
		    <th>Polesei Nilai</th>
		    <th>A Kependidikan</th>
		    <th>Sistem Ajar</th>
		    <th>Luas Lab</th>
		    <th>Kapasitas Prak Satu Shift</th>
		    <th>Jml Mhs Pengguna</th>
		    <th>Jml Jam Penggunaan</th>
		    <th>Jml Prodi Pengguna</th>
		    <th>Jml Modul Prak Sendiri</th>
		    <th>Jml Modul Prak Lain</th>
		    <th>Fungsi Selain Prak</th>
		    <th>Penggunaan Lab</th>
		    <th>Id Sp</th>
		    <th>Id Jenj Didik</th>
		    <th>Id Jns Sms</th>
		    <th>Id Fungsi Lab</th>
		    <th>Id Kel Usaha</th>
		    <th>Id Blob</th>
		    <th>Id Wil</th>
		    <th>Id Jur</th>
		    <th>Id Induk Sms</th>
		    <th width="200px">Action</th>
                </tr>
            </thead>
	    
        </table>
        </div>
                    </div>
            </div>
            </div>
    </section>
</div>
        <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/datatables/jquery.dataTables.js') ?>"></script>
        <script src="<?php echo base_url('assets/datatables/dataTables.bootstrap.js') ?>"></script>
        <script type="text/javascript">
            $(document).ready(function() {
                $.fn.dataTableExt.oApi.fnPagingInfo = function(oSettings)
                {
                    return {
                        "iStart": oSettings._iDisplayStart,
                        "iEnd": oSettings.fnDisplayEnd(),
                        "iLength": oSettings._iDisplayLength,
                        "iTotal": oSettings.fnRecordsTotal(),
                        "iFilteredTotal": oSettings.fnRecordsDisplay(),
                        "iPage": Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength),
                        "iTotalPages": Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength)
                    };
                };

                var t = $("#mytable").dataTable({
                    initComplete: function() {
                        var api = this.api();
                        $('#mytable_filter input')
                                .off('.DT')
                                .on('keyup.DT', function(e) {
                                    if (e.keyCode == 13) {
                                        api.search(this.value).draw();
                            }
                        });
                    },
                    oLanguage: {
                        sProcessing: "loading..."
                    },
                    processing: true,
                    serverSide: true,
                    ajax: {"url": "sms/json", "type": "POST"},
                    columns: [
                        {
                            "data": "id_sms",
                            "orderable": false
                        },{"data": "nm_lemb"},{"data": "smt_mulai"},{"data": "kode_prodi"},{"data": "nm_prodi_english"},{"data": "jln"},{"data": "rt"},{"data": "rw"},{"data": "nm_dsn"},{"data": "ds_kel"},{"data": "kode_pos"},{"data": "lintang"},{"data": "bujur"},{"data": "no_tel"},{"data": "no_fax"},{"data": "email"},{"data": "website"},{"data": "singkatan"},{"data": "tgl_berdiri"},{"data": "sk_selenggara"},{"data": "tgl_sk_selenggara"},{"data": "tmt_sk_selenggara"},{"data": "tst_sk_selenggara"},{"data": "kpst_pd"},{"data": "sks_lulus"},{"data": "gelar_lulusan"},{"data": "stat_prodi"},{"data": "polesei_nilai"},{"data": "a_kependidikan"},{"data": "sistem_ajar"},{"data": "luas_lab"},{"data": "kapasitas_prak_satu_shift"},{"data": "jml_mhs_pengguna"},{"data": "jml_jam_penggunaan"},{"data": "jml_prodi_pengguna"},{"data": "jml_modul_prak_sendiri"},{"data": "jml_modul_prak_lain"},{"data": "fungsi_selain_prak"},{"data": "penggunaan_lab"},{"data": "id_sp"},{"data": "id_jenj_didik"},{"data": "id_jns_sms"},{"data": "id_fungsi_lab"},{"data": "id_kel_usaha"},{"data": "id_blob"},{"data": "id_wil"},{"data": "id_jur"},{"data": "id_induk_sms"},
                        {
                            "data" : "action",
                            "orderable": false,
                            "className" : "text-center"
                        }
                    ],
                    order: [[0, 'desc']],
                    rowCallback: function(row, data, iDisplayIndex) {
                        var info = this.fnPagingInfo();
                        var page = info.iPage;
                        var length = info.iLength;
                        var index = page * length + (iDisplayIndex + 1);
                        $('td:eq(0)', row).html(index);
                    }
                });
            });
        </script>