<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Sms List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Nm Lemb</th>
		<th>Smt Mulai</th>
		<th>Kode Prodi</th>
		<th>Nm Prodi English</th>
		<th>Jln</th>
		<th>Rt</th>
		<th>Rw</th>
		<th>Nm Dsn</th>
		<th>Ds Kel</th>
		<th>Kode Pos</th>
		<th>Lintang</th>
		<th>Bujur</th>
		<th>No Tel</th>
		<th>No Fax</th>
		<th>Email</th>
		<th>Website</th>
		<th>Singkatan</th>
		<th>Tgl Berdiri</th>
		<th>Sk Selenggara</th>
		<th>Tgl Sk Selenggara</th>
		<th>Tmt Sk Selenggara</th>
		<th>Tst Sk Selenggara</th>
		<th>Kpst Pd</th>
		<th>Sks Lulus</th>
		<th>Gelar Lulusan</th>
		<th>Stat Prodi</th>
		<th>Polesei Nilai</th>
		<th>A Kependidikan</th>
		<th>Sistem Ajar</th>
		<th>Luas Lab</th>
		<th>Kapasitas Prak Satu Shift</th>
		<th>Jml Mhs Pengguna</th>
		<th>Jml Jam Penggunaan</th>
		<th>Jml Prodi Pengguna</th>
		<th>Jml Modul Prak Sendiri</th>
		<th>Jml Modul Prak Lain</th>
		<th>Fungsi Selain Prak</th>
		<th>Penggunaan Lab</th>
		<th>Id Sp</th>
		<th>Id Jenj Didik</th>
		<th>Id Jns Sms</th>
		<th>Id Fungsi Lab</th>
		<th>Id Kel Usaha</th>
		<th>Id Blob</th>
		<th>Id Wil</th>
		<th>Id Jur</th>
		<th>Id Induk Sms</th>
		
            </tr><?php
            foreach ($sms_data as $sms)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $sms->nm_lemb ?></td>
		      <td><?php echo $sms->smt_mulai ?></td>
		      <td><?php echo $sms->kode_prodi ?></td>
		      <td><?php echo $sms->nm_prodi_english ?></td>
		      <td><?php echo $sms->jln ?></td>
		      <td><?php echo $sms->rt ?></td>
		      <td><?php echo $sms->rw ?></td>
		      <td><?php echo $sms->nm_dsn ?></td>
		      <td><?php echo $sms->ds_kel ?></td>
		      <td><?php echo $sms->kode_pos ?></td>
		      <td><?php echo $sms->lintang ?></td>
		      <td><?php echo $sms->bujur ?></td>
		      <td><?php echo $sms->no_tel ?></td>
		      <td><?php echo $sms->no_fax ?></td>
		      <td><?php echo $sms->email ?></td>
		      <td><?php echo $sms->website ?></td>
		      <td><?php echo $sms->singkatan ?></td>
		      <td><?php echo $sms->tgl_berdiri ?></td>
		      <td><?php echo $sms->sk_selenggara ?></td>
		      <td><?php echo $sms->tgl_sk_selenggara ?></td>
		      <td><?php echo $sms->tmt_sk_selenggara ?></td>
		      <td><?php echo $sms->tst_sk_selenggara ?></td>
		      <td><?php echo $sms->kpst_pd ?></td>
		      <td><?php echo $sms->sks_lulus ?></td>
		      <td><?php echo $sms->gelar_lulusan ?></td>
		      <td><?php echo $sms->stat_prodi ?></td>
		      <td><?php echo $sms->polesei_nilai ?></td>
		      <td><?php echo $sms->a_kependidikan ?></td>
		      <td><?php echo $sms->sistem_ajar ?></td>
		      <td><?php echo $sms->luas_lab ?></td>
		      <td><?php echo $sms->kapasitas_prak_satu_shift ?></td>
		      <td><?php echo $sms->jml_mhs_pengguna ?></td>
		      <td><?php echo $sms->jml_jam_penggunaan ?></td>
		      <td><?php echo $sms->jml_prodi_pengguna ?></td>
		      <td><?php echo $sms->jml_modul_prak_sendiri ?></td>
		      <td><?php echo $sms->jml_modul_prak_lain ?></td>
		      <td><?php echo $sms->fungsi_selain_prak ?></td>
		      <td><?php echo $sms->penggunaan_lab ?></td>
		      <td><?php echo $sms->id_sp ?></td>
		      <td><?php echo $sms->id_jenj_didik ?></td>
		      <td><?php echo $sms->id_jns_sms ?></td>
		      <td><?php echo $sms->id_fungsi_lab ?></td>
		      <td><?php echo $sms->id_kel_usaha ?></td>
		      <td><?php echo $sms->id_blob ?></td>
		      <td><?php echo $sms->id_wil ?></td>
		      <td><?php echo $sms->id_jur ?></td>
		      <td><?php echo $sms->id_induk_sms ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>