<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Jabfung Read</h2>
        <table class="table">
	    <tr><td>Id Kel Prof</td><td><?php echo $id_kel_prof; ?></td></tr>
	    <tr><td>Nm Jabfung</td><td><?php echo $nm_jabfung; ?></td></tr>
	    <tr><td>Angka Kredit</td><td><?php echo $angka_kredit; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('jabfung') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>