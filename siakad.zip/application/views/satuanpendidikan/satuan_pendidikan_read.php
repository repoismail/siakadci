<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Satuan_pendidikan Read</h2>
        <table class="table">
	    <tr><td>Nm Lemb</td><td><?php echo $nm_lemb; ?></td></tr>
	    <tr><td>Nss</td><td><?php echo $nss; ?></td></tr>
	    <tr><td>Npsn</td><td><?php echo $npsn; ?></td></tr>
	    <tr><td>Nm Singkat</td><td><?php echo $nm_singkat; ?></td></tr>
	    <tr><td>Jln</td><td><?php echo $jln; ?></td></tr>
	    <tr><td>Rt</td><td><?php echo $rt; ?></td></tr>
	    <tr><td>Rw</td><td><?php echo $rw; ?></td></tr>
	    <tr><td>Nm Dsn</td><td><?php echo $nm_dsn; ?></td></tr>
	    <tr><td>Ds Kel</td><td><?php echo $ds_kel; ?></td></tr>
	    <tr><td>Kode Pos</td><td><?php echo $kode_pos; ?></td></tr>
	    <tr><td>Lintang</td><td><?php echo $lintang; ?></td></tr>
	    <tr><td>Bujur</td><td><?php echo $bujur; ?></td></tr>
	    <tr><td>No Tel</td><td><?php echo $no_tel; ?></td></tr>
	    <tr><td>No Fax</td><td><?php echo $no_fax; ?></td></tr>
	    <tr><td>Email</td><td><?php echo $email; ?></td></tr>
	    <tr><td>Website</td><td><?php echo $website; ?></td></tr>
	    <tr><td>Stat Sp</td><td><?php echo $stat_sp; ?></td></tr>
	    <tr><td>Sk Pendirian Sp</td><td><?php echo $sk_pendirian_sp; ?></td></tr>
	    <tr><td>Tgl Sk Pendirian Sp</td><td><?php echo $tgl_sk_pendirian_sp; ?></td></tr>
	    <tr><td>Tgl Berdiri</td><td><?php echo $tgl_berdiri; ?></td></tr>
	    <tr><td>Sk Izin Operasi</td><td><?php echo $sk_izin_operasi; ?></td></tr>
	    <tr><td>Tgl Sk Izin Operasi</td><td><?php echo $tgl_sk_izin_operasi; ?></td></tr>
	    <tr><td>No Rek</td><td><?php echo $no_rek; ?></td></tr>
	    <tr><td>Nm Bank</td><td><?php echo $nm_bank; ?></td></tr>
	    <tr><td>Unit Cabang</td><td><?php echo $unit_cabang; ?></td></tr>
	    <tr><td>Nm Rek</td><td><?php echo $nm_rek; ?></td></tr>
	    <tr><td>A Mbs</td><td><?php echo $a_mbs; ?></td></tr>
	    <tr><td>Luas Tanah Milik</td><td><?php echo $luas_tanah_milik; ?></td></tr>
	    <tr><td>Luas Tanah Bukan Milik</td><td><?php echo $luas_tanah_bukan_milik; ?></td></tr>
	    <tr><td>A Lptk</td><td><?php echo $a_lptk; ?></td></tr>
	    <tr><td>Kode Reg</td><td><?php echo $kode_reg; ?></td></tr>
	    <tr><td>Npwp</td><td><?php echo $npwp; ?></td></tr>
	    <tr><td>Nm Wp</td><td><?php echo $nm_wp; ?></td></tr>
	    <tr><td>Flag</td><td><?php echo $flag; ?></td></tr>
	    <tr><td>Id Pembina</td><td><?php echo $id_pembina; ?></td></tr>
	    <tr><td>Id Blob</td><td><?php echo $id_blob; ?></td></tr>
	    <tr><td>Id Stat Milik</td><td><?php echo $id_stat_milik; ?></td></tr>
	    <tr><td>Id Wil</td><td><?php echo $id_wil; ?></td></tr>
	    <tr><td>Id Kk</td><td><?php echo $id_kk; ?></td></tr>
	    <tr><td>Id Bp</td><td><?php echo $id_bp; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('satuanpendidikan') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>