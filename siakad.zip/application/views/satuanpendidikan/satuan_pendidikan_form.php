<div class="content-wrapper">
    
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">INPUT DATA SATUAN_PENDIDIKAN</h3>
            </div>
            <form action="<?php echo $action; ?>" method="post">
            
<table class='table table-bordered>'        

	    <tr><td width='200'>Nm Lemb <?php echo form_error('nm_lemb') ?></td><td><input type="text" class="form-control" name="nm_lemb" id="nm_lemb" placeholder="Nm Lemb" value="<?php echo $nm_lemb; ?>" /></td></tr>
	    <tr><td width='200'>Nss <?php echo form_error('nss') ?></td><td><input type="text" class="form-control" name="nss" id="nss" placeholder="Nss" value="<?php echo $nss; ?>" /></td></tr>
	    <tr><td width='200'>Npsn <?php echo form_error('npsn') ?></td><td><input type="text" class="form-control" name="npsn" id="npsn" placeholder="Npsn" value="<?php echo $npsn; ?>" /></td></tr>
	    <tr><td width='200'>Nm Singkat <?php echo form_error('nm_singkat') ?></td><td><input type="text" class="form-control" name="nm_singkat" id="nm_singkat" placeholder="Nm Singkat" value="<?php echo $nm_singkat; ?>" /></td></tr>
	    <tr><td width='200'>Jln <?php echo form_error('jln') ?></td><td><input type="text" class="form-control" name="jln" id="jln" placeholder="Jln" value="<?php echo $jln; ?>" /></td></tr>
	    <tr><td width='200'>Rt <?php echo form_error('rt') ?></td><td><input type="text" class="form-control" name="rt" id="rt" placeholder="Rt" value="<?php echo $rt; ?>" /></td></tr>
	    <tr><td width='200'>Rw <?php echo form_error('rw') ?></td><td><input type="text" class="form-control" name="rw" id="rw" placeholder="Rw" value="<?php echo $rw; ?>" /></td></tr>
	    <tr><td width='200'>Nm Dsn <?php echo form_error('nm_dsn') ?></td><td><input type="text" class="form-control" name="nm_dsn" id="nm_dsn" placeholder="Nm Dsn" value="<?php echo $nm_dsn; ?>" /></td></tr>
	    <tr><td width='200'>Ds Kel <?php echo form_error('ds_kel') ?></td><td><input type="text" class="form-control" name="ds_kel" id="ds_kel" placeholder="Ds Kel" value="<?php echo $ds_kel; ?>" /></td></tr>
	    <tr><td width='200'>Kode Pos <?php echo form_error('kode_pos') ?></td><td><input type="text" class="form-control" name="kode_pos" id="kode_pos" placeholder="Kode Pos" value="<?php echo $kode_pos; ?>" /></td></tr>
	    <tr><td width='200'>Lintang <?php echo form_error('lintang') ?></td><td><input type="text" class="form-control" name="lintang" id="lintang" placeholder="Lintang" value="<?php echo $lintang; ?>" /></td></tr>
	    <tr><td width='200'>Bujur <?php echo form_error('bujur') ?></td><td><input type="text" class="form-control" name="bujur" id="bujur" placeholder="Bujur" value="<?php echo $bujur; ?>" /></td></tr>
	    <tr><td width='200'>No Tel <?php echo form_error('no_tel') ?></td><td><input type="text" class="form-control" name="no_tel" id="no_tel" placeholder="No Tel" value="<?php echo $no_tel; ?>" /></td></tr>
	    <tr><td width='200'>No Fax <?php echo form_error('no_fax') ?></td><td><input type="text" class="form-control" name="no_fax" id="no_fax" placeholder="No Fax" value="<?php echo $no_fax; ?>" /></td></tr>
	    <tr><td width='200'>Email <?php echo form_error('email') ?></td><td><input type="text" class="form-control" name="email" id="email" placeholder="Email" value="<?php echo $email; ?>" /></td></tr>
	    <tr><td width='200'>Website <?php echo form_error('website') ?></td><td><input type="text" class="form-control" name="website" id="website" placeholder="Website" value="<?php echo $website; ?>" /></td></tr>
	    <tr><td width='200'>Stat Sp <?php echo form_error('stat_sp') ?></td><td><input type="text" class="form-control" name="stat_sp" id="stat_sp" placeholder="Stat Sp" value="<?php echo $stat_sp; ?>" /></td></tr>
	    <tr><td width='200'>Sk Pendirian Sp <?php echo form_error('sk_pendirian_sp') ?></td><td><input type="text" class="form-control" name="sk_pendirian_sp" id="sk_pendirian_sp" placeholder="Sk Pendirian Sp" value="<?php echo $sk_pendirian_sp; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Sk Pendirian Sp <?php echo form_error('tgl_sk_pendirian_sp') ?></td><td><input type="date" class="form-control" name="tgl_sk_pendirian_sp" id="tgl_sk_pendirian_sp" placeholder="Tgl Sk Pendirian Sp" value="<?php echo $tgl_sk_pendirian_sp; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Berdiri <?php echo form_error('tgl_berdiri') ?></td><td><input type="date" class="form-control" name="tgl_berdiri" id="tgl_berdiri" placeholder="Tgl Berdiri" value="<?php echo $tgl_berdiri; ?>" /></td></tr>
	    <tr><td width='200'>Sk Izin Operasi <?php echo form_error('sk_izin_operasi') ?></td><td><input type="text" class="form-control" name="sk_izin_operasi" id="sk_izin_operasi" placeholder="Sk Izin Operasi" value="<?php echo $sk_izin_operasi; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Sk Izin Operasi <?php echo form_error('tgl_sk_izin_operasi') ?></td><td><input type="date" class="form-control" name="tgl_sk_izin_operasi" id="tgl_sk_izin_operasi" placeholder="Tgl Sk Izin Operasi" value="<?php echo $tgl_sk_izin_operasi; ?>" /></td></tr>
	    <tr><td width='200'>No Rek <?php echo form_error('no_rek') ?></td><td><input type="text" class="form-control" name="no_rek" id="no_rek" placeholder="No Rek" value="<?php echo $no_rek; ?>" /></td></tr>
	    <tr><td width='200'>Nm Bank <?php echo form_error('nm_bank') ?></td><td><input type="text" class="form-control" name="nm_bank" id="nm_bank" placeholder="Nm Bank" value="<?php echo $nm_bank; ?>" /></td></tr>
	    <tr><td width='200'>Unit Cabang <?php echo form_error('unit_cabang') ?></td><td><input type="text" class="form-control" name="unit_cabang" id="unit_cabang" placeholder="Unit Cabang" value="<?php echo $unit_cabang; ?>" /></td></tr>
	    <tr><td width='200'>Nm Rek <?php echo form_error('nm_rek') ?></td><td><input type="text" class="form-control" name="nm_rek" id="nm_rek" placeholder="Nm Rek" value="<?php echo $nm_rek; ?>" /></td></tr>
	    <tr><td width='200'>A Mbs <?php echo form_error('a_mbs') ?></td><td><input type="text" class="form-control" name="a_mbs" id="a_mbs" placeholder="A Mbs" value="<?php echo $a_mbs; ?>" /></td></tr>
	    <tr><td width='200'>Luas Tanah Milik <?php echo form_error('luas_tanah_milik') ?></td><td><input type="text" class="form-control" name="luas_tanah_milik" id="luas_tanah_milik" placeholder="Luas Tanah Milik" value="<?php echo $luas_tanah_milik; ?>" /></td></tr>
	    <tr><td width='200'>Luas Tanah Bukan Milik <?php echo form_error('luas_tanah_bukan_milik') ?></td><td><input type="text" class="form-control" name="luas_tanah_bukan_milik" id="luas_tanah_bukan_milik" placeholder="Luas Tanah Bukan Milik" value="<?php echo $luas_tanah_bukan_milik; ?>" /></td></tr>
	    <tr><td width='200'>A Lptk <?php echo form_error('a_lptk') ?></td><td><input type="text" class="form-control" name="a_lptk" id="a_lptk" placeholder="A Lptk" value="<?php echo $a_lptk; ?>" /></td></tr>
	    <tr><td width='200'>Kode Reg <?php echo form_error('kode_reg') ?></td><td><input type="text" class="form-control" name="kode_reg" id="kode_reg" placeholder="Kode Reg" value="<?php echo $kode_reg; ?>" /></td></tr>
	    <tr><td width='200'>Npwp <?php echo form_error('npwp') ?></td><td><input type="text" class="form-control" name="npwp" id="npwp" placeholder="Npwp" value="<?php echo $npwp; ?>" /></td></tr>
	    <tr><td width='200'>Nm Wp <?php echo form_error('nm_wp') ?></td><td><input type="text" class="form-control" name="nm_wp" id="nm_wp" placeholder="Nm Wp" value="<?php echo $nm_wp; ?>" /></td></tr>
	    <tr><td width='200'>Flag <?php echo form_error('flag') ?></td><td><input type="text" class="form-control" name="flag" id="flag" placeholder="Flag" value="<?php echo $flag; ?>" /></td></tr>
	    <tr><td width='200'>Id Pembina <?php echo form_error('id_pembina') ?></td><td><input type="text" class="form-control" name="id_pembina" id="id_pembina" placeholder="Id Pembina" value="<?php echo $id_pembina; ?>" /></td></tr>
	    <tr><td width='200'>Id Blob <?php echo form_error('id_blob') ?></td><td><input type="text" class="form-control" name="id_blob" id="id_blob" placeholder="Id Blob" value="<?php echo $id_blob; ?>" /></td></tr>
	    <tr><td width='200'>Id Stat Milik <?php echo form_error('id_stat_milik') ?></td><td><input type="text" class="form-control" name="id_stat_milik" id="id_stat_milik" placeholder="Id Stat Milik" value="<?php echo $id_stat_milik; ?>" /></td></tr>
	    <tr><td width='200'>Id Wil <?php echo form_error('id_wil') ?></td><td><input type="text" class="form-control" name="id_wil" id="id_wil" placeholder="Id Wil" value="<?php echo $id_wil; ?>" /></td></tr>
	    <tr><td width='200'>Id Kk <?php echo form_error('id_kk') ?></td><td><input type="text" class="form-control" name="id_kk" id="id_kk" placeholder="Id Kk" value="<?php echo $id_kk; ?>" /></td></tr>
	    <tr><td width='200'>Id Bp <?php echo form_error('id_bp') ?></td><td><input type="text" class="form-control" name="id_bp" id="id_bp" placeholder="Id Bp" value="<?php echo $id_bp; ?>" /></td></tr>
	    <tr><td></td><td><input type="hidden" name="id_sp" value="<?php echo $id_sp; ?>" /> 
	    <button type="submit" class="btn btn-danger"><i class="fa fa-floppy-o"></i> <?php echo $button ?></button> 
	    <a href="<?php echo site_url('satuanpendidikan') ?>" class="btn btn-info"><i class="fa fa-sign-out"></i> Kembali</a></td></tr>
	</table></form>        </div>
</div>
</div>