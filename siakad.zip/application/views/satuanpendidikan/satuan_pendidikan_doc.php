<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Satuan_pendidikan List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Nm Lemb</th>
		<th>Nss</th>
		<th>Npsn</th>
		<th>Nm Singkat</th>
		<th>Jln</th>
		<th>Rt</th>
		<th>Rw</th>
		<th>Nm Dsn</th>
		<th>Ds Kel</th>
		<th>Kode Pos</th>
		<th>Lintang</th>
		<th>Bujur</th>
		<th>No Tel</th>
		<th>No Fax</th>
		<th>Email</th>
		<th>Website</th>
		<th>Stat Sp</th>
		<th>Sk Pendirian Sp</th>
		<th>Tgl Sk Pendirian Sp</th>
		<th>Tgl Berdiri</th>
		<th>Sk Izin Operasi</th>
		<th>Tgl Sk Izin Operasi</th>
		<th>No Rek</th>
		<th>Nm Bank</th>
		<th>Unit Cabang</th>
		<th>Nm Rek</th>
		<th>A Mbs</th>
		<th>Luas Tanah Milik</th>
		<th>Luas Tanah Bukan Milik</th>
		<th>A Lptk</th>
		<th>Kode Reg</th>
		<th>Npwp</th>
		<th>Nm Wp</th>
		<th>Flag</th>
		<th>Id Pembina</th>
		<th>Id Blob</th>
		<th>Id Stat Milik</th>
		<th>Id Wil</th>
		<th>Id Kk</th>
		<th>Id Bp</th>
		
            </tr><?php
            foreach ($satuanpendidikan_data as $satuanpendidikan)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $satuanpendidikan->nm_lemb ?></td>
		      <td><?php echo $satuanpendidikan->nss ?></td>
		      <td><?php echo $satuanpendidikan->npsn ?></td>
		      <td><?php echo $satuanpendidikan->nm_singkat ?></td>
		      <td><?php echo $satuanpendidikan->jln ?></td>
		      <td><?php echo $satuanpendidikan->rt ?></td>
		      <td><?php echo $satuanpendidikan->rw ?></td>
		      <td><?php echo $satuanpendidikan->nm_dsn ?></td>
		      <td><?php echo $satuanpendidikan->ds_kel ?></td>
		      <td><?php echo $satuanpendidikan->kode_pos ?></td>
		      <td><?php echo $satuanpendidikan->lintang ?></td>
		      <td><?php echo $satuanpendidikan->bujur ?></td>
		      <td><?php echo $satuanpendidikan->no_tel ?></td>
		      <td><?php echo $satuanpendidikan->no_fax ?></td>
		      <td><?php echo $satuanpendidikan->email ?></td>
		      <td><?php echo $satuanpendidikan->website ?></td>
		      <td><?php echo $satuanpendidikan->stat_sp ?></td>
		      <td><?php echo $satuanpendidikan->sk_pendirian_sp ?></td>
		      <td><?php echo $satuanpendidikan->tgl_sk_pendirian_sp ?></td>
		      <td><?php echo $satuanpendidikan->tgl_berdiri ?></td>
		      <td><?php echo $satuanpendidikan->sk_izin_operasi ?></td>
		      <td><?php echo $satuanpendidikan->tgl_sk_izin_operasi ?></td>
		      <td><?php echo $satuanpendidikan->no_rek ?></td>
		      <td><?php echo $satuanpendidikan->nm_bank ?></td>
		      <td><?php echo $satuanpendidikan->unit_cabang ?></td>
		      <td><?php echo $satuanpendidikan->nm_rek ?></td>
		      <td><?php echo $satuanpendidikan->a_mbs ?></td>
		      <td><?php echo $satuanpendidikan->luas_tanah_milik ?></td>
		      <td><?php echo $satuanpendidikan->luas_tanah_bukan_milik ?></td>
		      <td><?php echo $satuanpendidikan->a_lptk ?></td>
		      <td><?php echo $satuanpendidikan->kode_reg ?></td>
		      <td><?php echo $satuanpendidikan->npwp ?></td>
		      <td><?php echo $satuanpendidikan->nm_wp ?></td>
		      <td><?php echo $satuanpendidikan->flag ?></td>
		      <td><?php echo $satuanpendidikan->id_pembina ?></td>
		      <td><?php echo $satuanpendidikan->id_blob ?></td>
		      <td><?php echo $satuanpendidikan->id_stat_milik ?></td>
		      <td><?php echo $satuanpendidikan->id_wil ?></td>
		      <td><?php echo $satuanpendidikan->id_kk ?></td>
		      <td><?php echo $satuanpendidikan->id_bp ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>