<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Dosen List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Nm Sdm</th>
		<th>Jk</th>
		<th>Tmpt Lahir</th>
		<th>Tgl Lahir</th>
		<th>Nm Ibu Kandung</th>
		<th>Stat Kawin</th>
		<th>Nik</th>
		<th>Nip</th>
		<th>Niy Nigk</th>
		<th>Nuptk</th>
		<th>Nidn</th>
		<th>Nsdmi</th>
		<th>Jln</th>
		<th>Rt</th>
		<th>Rw</th>
		<th>Nm Dsn</th>
		<th>Ds Kel</th>
		<th>Kode Pos</th>
		<th>No Tel Rmh</th>
		<th>No Hp</th>
		<th>Email</th>
		<th>Tmt Pns</th>
		<th>Nm Suami Istri</th>
		<th>Nip Suami Istri</th>
		<th>Sk Cpns</th>
		<th>Tgl Sk Cpns</th>
		<th>Sk Angkat</th>
		<th>Tmt Sk Angkat</th>
		<th>Npwp</th>
		<th>Nm Wp</th>
		<th>Stat Data</th>
		<th>A Lisensi Kepsek</th>
		<th>A Braille</th>
		<th>A Bhs Isyarat</th>
		<th>Jml Sekolah Binaan</th>
		<th>A Diklat Awas</th>
		<th>Akta Ijin Ajar</th>
		<th>Nira</th>
		<th>Kewarganegaraan</th>
		<th>Id Jns Sdm</th>
		<th>Id Wil</th>
		<th>Id Stat Aktif</th>
		<th>Id Blob</th>
		<th>Id Agama</th>
		<th>Id Keahlian Lab</th>
		<th>Id Pekerjaan Suami Istri</th>
		<th>Id Sumber Gaji</th>
		<th>Id Lemb Angkat</th>
		<th>Id Pangkat Gol</th>
		<th>Mampu Handle Kk</th>
		<th>Id Bid Pengawas</th>
		
            </tr><?php
            foreach ($dosen_data as $dosen)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $dosen->nm_sdm ?></td>
		      <td><?php echo $dosen->jk ?></td>
		      <td><?php echo $dosen->tmpt_lahir ?></td>
		      <td><?php echo $dosen->tgl_lahir ?></td>
		      <td><?php echo $dosen->nm_ibu_kandung ?></td>
		      <td><?php echo $dosen->stat_kawin ?></td>
		      <td><?php echo $dosen->nik ?></td>
		      <td><?php echo $dosen->nip ?></td>
		      <td><?php echo $dosen->niy_nigk ?></td>
		      <td><?php echo $dosen->nuptk ?></td>
		      <td><?php echo $dosen->nidn ?></td>
		      <td><?php echo $dosen->nsdmi ?></td>
		      <td><?php echo $dosen->jln ?></td>
		      <td><?php echo $dosen->rt ?></td>
		      <td><?php echo $dosen->rw ?></td>
		      <td><?php echo $dosen->nm_dsn ?></td>
		      <td><?php echo $dosen->ds_kel ?></td>
		      <td><?php echo $dosen->kode_pos ?></td>
		      <td><?php echo $dosen->no_tel_rmh ?></td>
		      <td><?php echo $dosen->no_hp ?></td>
		      <td><?php echo $dosen->email ?></td>
		      <td><?php echo $dosen->tmt_pns ?></td>
		      <td><?php echo $dosen->nm_suami_istri ?></td>
		      <td><?php echo $dosen->nip_suami_istri ?></td>
		      <td><?php echo $dosen->sk_cpns ?></td>
		      <td><?php echo $dosen->tgl_sk_cpns ?></td>
		      <td><?php echo $dosen->sk_angkat ?></td>
		      <td><?php echo $dosen->tmt_sk_angkat ?></td>
		      <td><?php echo $dosen->npwp ?></td>
		      <td><?php echo $dosen->nm_wp ?></td>
		      <td><?php echo $dosen->stat_data ?></td>
		      <td><?php echo $dosen->a_lisensi_kepsek ?></td>
		      <td><?php echo $dosen->a_braille ?></td>
		      <td><?php echo $dosen->a_bhs_isyarat ?></td>
		      <td><?php echo $dosen->jml_sekolah_binaan ?></td>
		      <td><?php echo $dosen->a_diklat_awas ?></td>
		      <td><?php echo $dosen->akta_ijin_ajar ?></td>
		      <td><?php echo $dosen->nira ?></td>
		      <td><?php echo $dosen->kewarganegaraan ?></td>
		      <td><?php echo $dosen->id_jns_sdm ?></td>
		      <td><?php echo $dosen->id_wil ?></td>
		      <td><?php echo $dosen->id_stat_aktif ?></td>
		      <td><?php echo $dosen->id_blob ?></td>
		      <td><?php echo $dosen->id_agama ?></td>
		      <td><?php echo $dosen->id_keahlian_lab ?></td>
		      <td><?php echo $dosen->id_pekerjaan_suami_istri ?></td>
		      <td><?php echo $dosen->id_sumber_gaji ?></td>
		      <td><?php echo $dosen->id_lemb_angkat ?></td>
		      <td><?php echo $dosen->id_pangkat_gol ?></td>
		      <td><?php echo $dosen->mampu_handle_kk ?></td>
		      <td><?php echo $dosen->id_bid_pengawas ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>