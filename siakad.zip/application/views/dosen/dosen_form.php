<div class="content-wrapper">
    
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">INPUT DATA DOSEN</h3>
            </div>
            <form action="<?php echo $action; ?>" method="post">
            
<table class='table table-bordered>'        

	    <tr><td width='200'>Nm Sdm <?php echo form_error('nm_sdm') ?></td><td><input type="text" class="form-control" name="nm_sdm" id="nm_sdm" placeholder="Nm Sdm" value="<?php echo $nm_sdm; ?>" /></td></tr>
	    <tr><td width='200'>Jk <?php echo form_error('jk') ?></td><td><input type="text" class="form-control" name="jk" id="jk" placeholder="Jk" value="<?php echo $jk; ?>" /></td></tr>
	    <tr><td width='200'>Tmpt Lahir <?php echo form_error('tmpt_lahir') ?></td><td><input type="text" class="form-control" name="tmpt_lahir" id="tmpt_lahir" placeholder="Tmpt Lahir" value="<?php echo $tmpt_lahir; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Lahir <?php echo form_error('tgl_lahir') ?></td><td><input type="date" class="form-control" name="tgl_lahir" id="tgl_lahir" placeholder="Tgl Lahir" value="<?php echo $tgl_lahir; ?>" /></td></tr>
	    <tr><td width='200'>Nm Ibu Kandung <?php echo form_error('nm_ibu_kandung') ?></td><td><input type="text" class="form-control" name="nm_ibu_kandung" id="nm_ibu_kandung" placeholder="Nm Ibu Kandung" value="<?php echo $nm_ibu_kandung; ?>" /></td></tr>
	    <tr><td width='200'>Stat Kawin <?php echo form_error('stat_kawin') ?></td><td><input type="text" class="form-control" name="stat_kawin" id="stat_kawin" placeholder="Stat Kawin" value="<?php echo $stat_kawin; ?>" /></td></tr>
	    <tr><td width='200'>Nik <?php echo form_error('nik') ?></td><td><input type="text" class="form-control" name="nik" id="nik" placeholder="Nik" value="<?php echo $nik; ?>" /></td></tr>
	    <tr><td width='200'>Nip <?php echo form_error('nip') ?></td><td><input type="text" class="form-control" name="nip" id="nip" placeholder="Nip" value="<?php echo $nip; ?>" /></td></tr>
	    <tr><td width='200'>Niy Nigk <?php echo form_error('niy_nigk') ?></td><td><input type="text" class="form-control" name="niy_nigk" id="niy_nigk" placeholder="Niy Nigk" value="<?php echo $niy_nigk; ?>" /></td></tr>
	    <tr><td width='200'>Nuptk <?php echo form_error('nuptk') ?></td><td><input type="text" class="form-control" name="nuptk" id="nuptk" placeholder="Nuptk" value="<?php echo $nuptk; ?>" /></td></tr>
	    <tr><td width='200'>Nidn <?php echo form_error('nidn') ?></td><td><input type="text" class="form-control" name="nidn" id="nidn" placeholder="Nidn" value="<?php echo $nidn; ?>" /></td></tr>
	    <tr><td width='200'>Nsdmi <?php echo form_error('nsdmi') ?></td><td><input type="text" class="form-control" name="nsdmi" id="nsdmi" placeholder="Nsdmi" value="<?php echo $nsdmi; ?>" /></td></tr>
	    <tr><td width='200'>Jln <?php echo form_error('jln') ?></td><td><input type="text" class="form-control" name="jln" id="jln" placeholder="Jln" value="<?php echo $jln; ?>" /></td></tr>
	    <tr><td width='200'>Rt <?php echo form_error('rt') ?></td><td><input type="text" class="form-control" name="rt" id="rt" placeholder="Rt" value="<?php echo $rt; ?>" /></td></tr>
	    <tr><td width='200'>Rw <?php echo form_error('rw') ?></td><td><input type="text" class="form-control" name="rw" id="rw" placeholder="Rw" value="<?php echo $rw; ?>" /></td></tr>
	    <tr><td width='200'>Nm Dsn <?php echo form_error('nm_dsn') ?></td><td><input type="text" class="form-control" name="nm_dsn" id="nm_dsn" placeholder="Nm Dsn" value="<?php echo $nm_dsn; ?>" /></td></tr>
	    <tr><td width='200'>Ds Kel <?php echo form_error('ds_kel') ?></td><td><input type="text" class="form-control" name="ds_kel" id="ds_kel" placeholder="Ds Kel" value="<?php echo $ds_kel; ?>" /></td></tr>
	    <tr><td width='200'>Kode Pos <?php echo form_error('kode_pos') ?></td><td><input type="text" class="form-control" name="kode_pos" id="kode_pos" placeholder="Kode Pos" value="<?php echo $kode_pos; ?>" /></td></tr>
	    <tr><td width='200'>No Tel Rmh <?php echo form_error('no_tel_rmh') ?></td><td><input type="text" class="form-control" name="no_tel_rmh" id="no_tel_rmh" placeholder="No Tel Rmh" value="<?php echo $no_tel_rmh; ?>" /></td></tr>
	    <tr><td width='200'>No Hp <?php echo form_error('no_hp') ?></td><td><input type="text" class="form-control" name="no_hp" id="no_hp" placeholder="No Hp" value="<?php echo $no_hp; ?>" /></td></tr>
	    <tr><td width='200'>Email <?php echo form_error('email') ?></td><td><input type="text" class="form-control" name="email" id="email" placeholder="Email" value="<?php echo $email; ?>" /></td></tr>
	    <tr><td width='200'>Tmt Pns <?php echo form_error('tmt_pns') ?></td><td><input type="date" class="form-control" name="tmt_pns" id="tmt_pns" placeholder="Tmt Pns" value="<?php echo $tmt_pns; ?>" /></td></tr>
	    <tr><td width='200'>Nm Suami Istri <?php echo form_error('nm_suami_istri') ?></td><td><input type="text" class="form-control" name="nm_suami_istri" id="nm_suami_istri" placeholder="Nm Suami Istri" value="<?php echo $nm_suami_istri; ?>" /></td></tr>
	    <tr><td width='200'>Nip Suami Istri <?php echo form_error('nip_suami_istri') ?></td><td><input type="text" class="form-control" name="nip_suami_istri" id="nip_suami_istri" placeholder="Nip Suami Istri" value="<?php echo $nip_suami_istri; ?>" /></td></tr>
	    <tr><td width='200'>Sk Cpns <?php echo form_error('sk_cpns') ?></td><td><input type="text" class="form-control" name="sk_cpns" id="sk_cpns" placeholder="Sk Cpns" value="<?php echo $sk_cpns; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Sk Cpns <?php echo form_error('tgl_sk_cpns') ?></td><td><input type="date" class="form-control" name="tgl_sk_cpns" id="tgl_sk_cpns" placeholder="Tgl Sk Cpns" value="<?php echo $tgl_sk_cpns; ?>" /></td></tr>
	    <tr><td width='200'>Sk Angkat <?php echo form_error('sk_angkat') ?></td><td><input type="text" class="form-control" name="sk_angkat" id="sk_angkat" placeholder="Sk Angkat" value="<?php echo $sk_angkat; ?>" /></td></tr>
	    <tr><td width='200'>Tmt Sk Angkat <?php echo form_error('tmt_sk_angkat') ?></td><td><input type="date" class="form-control" name="tmt_sk_angkat" id="tmt_sk_angkat" placeholder="Tmt Sk Angkat" value="<?php echo $tmt_sk_angkat; ?>" /></td></tr>
	    <tr><td width='200'>Npwp <?php echo form_error('npwp') ?></td><td><input type="text" class="form-control" name="npwp" id="npwp" placeholder="Npwp" value="<?php echo $npwp; ?>" /></td></tr>
	    <tr><td width='200'>Nm Wp <?php echo form_error('nm_wp') ?></td><td><input type="text" class="form-control" name="nm_wp" id="nm_wp" placeholder="Nm Wp" value="<?php echo $nm_wp; ?>" /></td></tr>
	    <tr><td width='200'>Stat Data <?php echo form_error('stat_data') ?></td><td><input type="text" class="form-control" name="stat_data" id="stat_data" placeholder="Stat Data" value="<?php echo $stat_data; ?>" /></td></tr>
	    <tr><td width='200'>A Lisensi Kepsek <?php echo form_error('a_lisensi_kepsek') ?></td><td><input type="text" class="form-control" name="a_lisensi_kepsek" id="a_lisensi_kepsek" placeholder="A Lisensi Kepsek" value="<?php echo $a_lisensi_kepsek; ?>" /></td></tr>
	    <tr><td width='200'>A Braille <?php echo form_error('a_braille') ?></td><td><input type="text" class="form-control" name="a_braille" id="a_braille" placeholder="A Braille" value="<?php echo $a_braille; ?>" /></td></tr>
	    <tr><td width='200'>A Bhs Isyarat <?php echo form_error('a_bhs_isyarat') ?></td><td><input type="text" class="form-control" name="a_bhs_isyarat" id="a_bhs_isyarat" placeholder="A Bhs Isyarat" value="<?php echo $a_bhs_isyarat; ?>" /></td></tr>
	    <tr><td width='200'>Jml Sekolah Binaan <?php echo form_error('jml_sekolah_binaan') ?></td><td><input type="text" class="form-control" name="jml_sekolah_binaan" id="jml_sekolah_binaan" placeholder="Jml Sekolah Binaan" value="<?php echo $jml_sekolah_binaan; ?>" /></td></tr>
	    <tr><td width='200'>A Diklat Awas <?php echo form_error('a_diklat_awas') ?></td><td><input type="text" class="form-control" name="a_diklat_awas" id="a_diklat_awas" placeholder="A Diklat Awas" value="<?php echo $a_diklat_awas; ?>" /></td></tr>
	    <tr><td width='200'>Akta Ijin Ajar <?php echo form_error('akta_ijin_ajar') ?></td><td><input type="text" class="form-control" name="akta_ijin_ajar" id="akta_ijin_ajar" placeholder="Akta Ijin Ajar" value="<?php echo $akta_ijin_ajar; ?>" /></td></tr>
	    <tr><td width='200'>Nira <?php echo form_error('nira') ?></td><td><input type="text" class="form-control" name="nira" id="nira" placeholder="Nira" value="<?php echo $nira; ?>" /></td></tr>
	    <tr><td width='200'>Kewarganegaraan <?php echo form_error('kewarganegaraan') ?></td><td><input type="text" class="form-control" name="kewarganegaraan" id="kewarganegaraan" placeholder="Kewarganegaraan" value="<?php echo $kewarganegaraan; ?>" /></td></tr>
	    <tr><td width='200'>Id Jns Sdm <?php echo form_error('id_jns_sdm') ?></td><td><input type="text" class="form-control" name="id_jns_sdm" id="id_jns_sdm" placeholder="Id Jns Sdm" value="<?php echo $id_jns_sdm; ?>" /></td></tr>
	    <tr><td width='200'>Id Wil <?php echo form_error('id_wil') ?></td><td><input type="text" class="form-control" name="id_wil" id="id_wil" placeholder="Id Wil" value="<?php echo $id_wil; ?>" /></td></tr>
	    <tr><td width='200'>Id Stat Aktif <?php echo form_error('id_stat_aktif') ?></td><td><input type="text" class="form-control" name="id_stat_aktif" id="id_stat_aktif" placeholder="Id Stat Aktif" value="<?php echo $id_stat_aktif; ?>" /></td></tr>
	    <tr><td width='200'>Id Blob <?php echo form_error('id_blob') ?></td><td><input type="text" class="form-control" name="id_blob" id="id_blob" placeholder="Id Blob" value="<?php echo $id_blob; ?>" /></td></tr>
	    <tr><td width='200'>Id Agama <?php echo form_error('id_agama') ?></td><td><input type="text" class="form-control" name="id_agama" id="id_agama" placeholder="Id Agama" value="<?php echo $id_agama; ?>" /></td></tr>
	    <tr><td width='200'>Id Keahlian Lab <?php echo form_error('id_keahlian_lab') ?></td><td><input type="text" class="form-control" name="id_keahlian_lab" id="id_keahlian_lab" placeholder="Id Keahlian Lab" value="<?php echo $id_keahlian_lab; ?>" /></td></tr>
	    <tr><td width='200'>Id Pekerjaan Suami Istri <?php echo form_error('id_pekerjaan_suami_istri') ?></td><td><input type="text" class="form-control" name="id_pekerjaan_suami_istri" id="id_pekerjaan_suami_istri" placeholder="Id Pekerjaan Suami Istri" value="<?php echo $id_pekerjaan_suami_istri; ?>" /></td></tr>
	    <tr><td width='200'>Id Sumber Gaji <?php echo form_error('id_sumber_gaji') ?></td><td><input type="text" class="form-control" name="id_sumber_gaji" id="id_sumber_gaji" placeholder="Id Sumber Gaji" value="<?php echo $id_sumber_gaji; ?>" /></td></tr>
	    <tr><td width='200'>Id Lemb Angkat <?php echo form_error('id_lemb_angkat') ?></td><td><input type="text" class="form-control" name="id_lemb_angkat" id="id_lemb_angkat" placeholder="Id Lemb Angkat" value="<?php echo $id_lemb_angkat; ?>" /></td></tr>
	    <tr><td width='200'>Id Pangkat Gol <?php echo form_error('id_pangkat_gol') ?></td><td><input type="text" class="form-control" name="id_pangkat_gol" id="id_pangkat_gol" placeholder="Id Pangkat Gol" value="<?php echo $id_pangkat_gol; ?>" /></td></tr>
	    <tr><td width='200'>Mampu Handle Kk <?php echo form_error('mampu_handle_kk') ?></td><td><input type="text" class="form-control" name="mampu_handle_kk" id="mampu_handle_kk" placeholder="Mampu Handle Kk" value="<?php echo $mampu_handle_kk; ?>" /></td></tr>
	    <tr><td width='200'>Id Bid Pengawas <?php echo form_error('id_bid_pengawas') ?></td><td><input type="text" class="form-control" name="id_bid_pengawas" id="id_bid_pengawas" placeholder="Id Bid Pengawas" value="<?php echo $id_bid_pengawas; ?>" /></td></tr>
	    <tr><td></td><td><input type="hidden" name="id_sdm" value="<?php echo $id_sdm; ?>" /> 
	    <button type="submit" class="btn btn-danger"><i class="fa fa-floppy-o"></i> <?php echo $button ?></button> 
	    <a href="<?php echo site_url('dosen') ?>" class="btn btn-info"><i class="fa fa-sign-out"></i> Kembali</a></td></tr>
	</table></form>        </div>
</div>
</div>