<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Dosen Read</h2>
        <table class="table">
	    <tr><td>Nm Sdm</td><td><?php echo $nm_sdm; ?></td></tr>
	    <tr><td>Jk</td><td><?php echo $jk; ?></td></tr>
	    <tr><td>Tmpt Lahir</td><td><?php echo $tmpt_lahir; ?></td></tr>
	    <tr><td>Tgl Lahir</td><td><?php echo $tgl_lahir; ?></td></tr>
	    <tr><td>Nm Ibu Kandung</td><td><?php echo $nm_ibu_kandung; ?></td></tr>
	    <tr><td>Stat Kawin</td><td><?php echo $stat_kawin; ?></td></tr>
	    <tr><td>Nik</td><td><?php echo $nik; ?></td></tr>
	    <tr><td>Nip</td><td><?php echo $nip; ?></td></tr>
	    <tr><td>Niy Nigk</td><td><?php echo $niy_nigk; ?></td></tr>
	    <tr><td>Nuptk</td><td><?php echo $nuptk; ?></td></tr>
	    <tr><td>Nidn</td><td><?php echo $nidn; ?></td></tr>
	    <tr><td>Nsdmi</td><td><?php echo $nsdmi; ?></td></tr>
	    <tr><td>Jln</td><td><?php echo $jln; ?></td></tr>
	    <tr><td>Rt</td><td><?php echo $rt; ?></td></tr>
	    <tr><td>Rw</td><td><?php echo $rw; ?></td></tr>
	    <tr><td>Nm Dsn</td><td><?php echo $nm_dsn; ?></td></tr>
	    <tr><td>Ds Kel</td><td><?php echo $ds_kel; ?></td></tr>
	    <tr><td>Kode Pos</td><td><?php echo $kode_pos; ?></td></tr>
	    <tr><td>No Tel Rmh</td><td><?php echo $no_tel_rmh; ?></td></tr>
	    <tr><td>No Hp</td><td><?php echo $no_hp; ?></td></tr>
	    <tr><td>Email</td><td><?php echo $email; ?></td></tr>
	    <tr><td>Tmt Pns</td><td><?php echo $tmt_pns; ?></td></tr>
	    <tr><td>Nm Suami Istri</td><td><?php echo $nm_suami_istri; ?></td></tr>
	    <tr><td>Nip Suami Istri</td><td><?php echo $nip_suami_istri; ?></td></tr>
	    <tr><td>Sk Cpns</td><td><?php echo $sk_cpns; ?></td></tr>
	    <tr><td>Tgl Sk Cpns</td><td><?php echo $tgl_sk_cpns; ?></td></tr>
	    <tr><td>Sk Angkat</td><td><?php echo $sk_angkat; ?></td></tr>
	    <tr><td>Tmt Sk Angkat</td><td><?php echo $tmt_sk_angkat; ?></td></tr>
	    <tr><td>Npwp</td><td><?php echo $npwp; ?></td></tr>
	    <tr><td>Nm Wp</td><td><?php echo $nm_wp; ?></td></tr>
	    <tr><td>Stat Data</td><td><?php echo $stat_data; ?></td></tr>
	    <tr><td>A Lisensi Kepsek</td><td><?php echo $a_lisensi_kepsek; ?></td></tr>
	    <tr><td>A Braille</td><td><?php echo $a_braille; ?></td></tr>
	    <tr><td>A Bhs Isyarat</td><td><?php echo $a_bhs_isyarat; ?></td></tr>
	    <tr><td>Jml Sekolah Binaan</td><td><?php echo $jml_sekolah_binaan; ?></td></tr>
	    <tr><td>A Diklat Awas</td><td><?php echo $a_diklat_awas; ?></td></tr>
	    <tr><td>Akta Ijin Ajar</td><td><?php echo $akta_ijin_ajar; ?></td></tr>
	    <tr><td>Nira</td><td><?php echo $nira; ?></td></tr>
	    <tr><td>Kewarganegaraan</td><td><?php echo $kewarganegaraan; ?></td></tr>
	    <tr><td>Id Jns Sdm</td><td><?php echo $id_jns_sdm; ?></td></tr>
	    <tr><td>Id Wil</td><td><?php echo $id_wil; ?></td></tr>
	    <tr><td>Id Stat Aktif</td><td><?php echo $id_stat_aktif; ?></td></tr>
	    <tr><td>Id Blob</td><td><?php echo $id_blob; ?></td></tr>
	    <tr><td>Id Agama</td><td><?php echo $id_agama; ?></td></tr>
	    <tr><td>Id Keahlian Lab</td><td><?php echo $id_keahlian_lab; ?></td></tr>
	    <tr><td>Id Pekerjaan Suami Istri</td><td><?php echo $id_pekerjaan_suami_istri; ?></td></tr>
	    <tr><td>Id Sumber Gaji</td><td><?php echo $id_sumber_gaji; ?></td></tr>
	    <tr><td>Id Lemb Angkat</td><td><?php echo $id_lemb_angkat; ?></td></tr>
	    <tr><td>Id Pangkat Gol</td><td><?php echo $id_pangkat_gol; ?></td></tr>
	    <tr><td>Mampu Handle Kk</td><td><?php echo $mampu_handle_kk; ?></td></tr>
	    <tr><td>Id Bid Pengawas</td><td><?php echo $id_bid_pengawas; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('dosen') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>