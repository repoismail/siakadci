<div class="content-wrapper">
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box box-warning box-solid">
    
                    <div class="box-header">
                        <h3 class="box-title">KELOLA DATA DOSEN</h3>
                    </div>
        
        <div class="box-body">
        <div style="padding-bottom: 10px;"'>
        <?php echo anchor(site_url('dosen/create'), '<i class="fa fa-wpforms" aria-hidden="true"></i> Tambah Data', 'class="btn btn-danger btn-sm"'); ?>
		<?php echo anchor(site_url('dosen/excel'), '<i class="fa fa-file-excel-o" aria-hidden="true"></i> Export Ms Excel', 'class="btn btn-success btn-sm"'); ?>
		<?php echo anchor(site_url('dosen/word'), '<i class="fa fa-file-word-o" aria-hidden="true"></i> Export Ms Word', 'class="btn btn-primary btn-sm"'); ?></div>
        <table class="table table-bordered table-striped" id="mytable">
            <thead>
                <tr>
                    <th width="30px">No</th>
		    <th>Nm Sdm</th>
		    <th>Jk</th>
		    <th>Tmpt Lahir</th>
		    <th>Tgl Lahir</th>
		    <th>Nm Ibu Kandung</th>
		    <th>Stat Kawin</th>
		    <th>Nik</th>
		    <th>Nip</th>
		    <th>Niy Nigk</th>
		    <th>Nuptk</th>
		    <th>Nidn</th>
		    <th>Nsdmi</th>
		    <th>Jln</th>
		    <th>Rt</th>
		    <th>Rw</th>
		    <th>Nm Dsn</th>
		    <th>Ds Kel</th>
		    <th>Kode Pos</th>
		    <th>No Tel Rmh</th>
		    <th>No Hp</th>
		    <th>Email</th>
		    <th>Tmt Pns</th>
		    <th>Nm Suami Istri</th>
		    <th>Nip Suami Istri</th>
		    <th>Sk Cpns</th>
		    <th>Tgl Sk Cpns</th>
		    <th>Sk Angkat</th>
		    <th>Tmt Sk Angkat</th>
		    <th>Npwp</th>
		    <th>Nm Wp</th>
		    <th>Stat Data</th>
		    <th>A Lisensi Kepsek</th>
		    <th>A Braille</th>
		    <th>A Bhs Isyarat</th>
		    <th>Jml Sekolah Binaan</th>
		    <th>A Diklat Awas</th>
		    <th>Akta Ijin Ajar</th>
		    <th>Nira</th>
		    <th>Kewarganegaraan</th>
		    <th>Id Jns Sdm</th>
		    <th>Id Wil</th>
		    <th>Id Stat Aktif</th>
		    <th>Id Blob</th>
		    <th>Id Agama</th>
		    <th>Id Keahlian Lab</th>
		    <th>Id Pekerjaan Suami Istri</th>
		    <th>Id Sumber Gaji</th>
		    <th>Id Lemb Angkat</th>
		    <th>Id Pangkat Gol</th>
		    <th>Mampu Handle Kk</th>
		    <th>Id Bid Pengawas</th>
		    <th width="200px">Action</th>
                </tr>
            </thead>
	    
        </table>
        </div>
                    </div>
            </div>
            </div>
    </section>
</div>
        <script src="<?php echo base_url('assets/js/jquery-1.11.2.min.js') ?>"></script>
        <script src="<?php echo base_url('assets/datatables/jquery.dataTables.js') ?>"></script>
        <script src="<?php echo base_url('assets/datatables/dataTables.bootstrap.js') ?>"></script>
        <script type="text/javascript">
            $(document).ready(function() {
                $.fn.dataTableExt.oApi.fnPagingInfo = function(oSettings)
                {
                    return {
                        "iStart": oSettings._iDisplayStart,
                        "iEnd": oSettings.fnDisplayEnd(),
                        "iLength": oSettings._iDisplayLength,
                        "iTotal": oSettings.fnRecordsTotal(),
                        "iFilteredTotal": oSettings.fnRecordsDisplay(),
                        "iPage": Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength),
                        "iTotalPages": Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength)
                    };
                };

                var t = $("#mytable").dataTable({
                    initComplete: function() {
                        var api = this.api();
                        $('#mytable_filter input')
                                .off('.DT')
                                .on('keyup.DT', function(e) {
                                    if (e.keyCode == 13) {
                                        api.search(this.value).draw();
                            }
                        });
                    },
                    oLanguage: {
                        sProcessing: "loading..."
                    },
                    processing: true,
                    serverSide: true,
                    ajax: {"url": "dosen/json", "type": "POST"},
                    columns: [
                        {
                            "data": "id_sdm",
                            "orderable": false
                        },{"data": "nm_sdm"},{"data": "jk"},{"data": "tmpt_lahir"},{"data": "tgl_lahir"},{"data": "nm_ibu_kandung"},{"data": "stat_kawin"},{"data": "nik"},{"data": "nip"},{"data": "niy_nigk"},{"data": "nuptk"},{"data": "nidn"},{"data": "nsdmi"},{"data": "jln"},{"data": "rt"},{"data": "rw"},{"data": "nm_dsn"},{"data": "ds_kel"},{"data": "kode_pos"},{"data": "no_tel_rmh"},{"data": "no_hp"},{"data": "email"},{"data": "tmt_pns"},{"data": "nm_suami_istri"},{"data": "nip_suami_istri"},{"data": "sk_cpns"},{"data": "tgl_sk_cpns"},{"data": "sk_angkat"},{"data": "tmt_sk_angkat"},{"data": "npwp"},{"data": "nm_wp"},{"data": "stat_data"},{"data": "a_lisensi_kepsek"},{"data": "a_braille"},{"data": "a_bhs_isyarat"},{"data": "jml_sekolah_binaan"},{"data": "a_diklat_awas"},{"data": "akta_ijin_ajar"},{"data": "nira"},{"data": "kewarganegaraan"},{"data": "id_jns_sdm"},{"data": "id_wil"},{"data": "id_stat_aktif"},{"data": "id_blob"},{"data": "id_agama"},{"data": "id_keahlian_lab"},{"data": "id_pekerjaan_suami_istri"},{"data": "id_sumber_gaji"},{"data": "id_lemb_angkat"},{"data": "id_pangkat_gol"},{"data": "mampu_handle_kk"},{"data": "id_bid_pengawas"},
                        {
                            "data" : "action",
                            "orderable": false,
                            "className" : "text-center"
                        }
                    ],
                    order: [[0, 'desc']],
                    rowCallback: function(row, data, iDisplayIndex) {
                        var info = this.fnPagingInfo();
                        var page = info.iPage;
                        var length = info.iLength;
                        var index = page * length + (iDisplayIndex + 1);
                        $('td:eq(0)', row).html(index);
                    }
                });
            });
        </script>