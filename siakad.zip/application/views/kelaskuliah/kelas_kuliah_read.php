<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Kelas_kuliah Read</h2>
        <table class="table">
	    <tr><td>Id Sms</td><td><?php echo $id_sms; ?></td></tr>
	    <tr><td>Id Smt</td><td><?php echo $id_smt; ?></td></tr>
	    <tr><td>Nm Kls</td><td><?php echo $nm_kls; ?></td></tr>
	    <tr><td>Sks Mk</td><td><?php echo $sks_mk; ?></td></tr>
	    <tr><td>Sks Tm</td><td><?php echo $sks_tm; ?></td></tr>
	    <tr><td>Sks Prak</td><td><?php echo $sks_prak; ?></td></tr>
	    <tr><td>Sks Prak Lap</td><td><?php echo $sks_prak_lap; ?></td></tr>
	    <tr><td>Sks Sim</td><td><?php echo $sks_sim; ?></td></tr>
	    <tr><td>Bahasan Case</td><td><?php echo $bahasan_case; ?></td></tr>
	    <tr><td>A Selenggara Pditt</td><td><?php echo $a_selenggara_pditt; ?></td></tr>
	    <tr><td>A Pengguna Pditt</td><td><?php echo $a_pengguna_pditt; ?></td></tr>
	    <tr><td>Kuota Pditt</td><td><?php echo $kuota_pditt; ?></td></tr>
	    <tr><td>Tgl Mulai Koas</td><td><?php echo $tgl_mulai_koas; ?></td></tr>
	    <tr><td>Tgl Selesai Koas</td><td><?php echo $tgl_selesai_koas; ?></td></tr>
	    <tr><td>Id Mou</td><td><?php echo $id_mou; ?></td></tr>
	    <tr><td>Id Mk</td><td><?php echo $id_mk; ?></td></tr>
	    <tr><td>Id Kls Pditt</td><td><?php echo $id_kls_pditt; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('kelaskuliah') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>