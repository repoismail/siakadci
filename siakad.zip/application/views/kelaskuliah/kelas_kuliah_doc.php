<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Kelas_kuliah List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Id Sms</th>
		<th>Id Smt</th>
		<th>Nm Kls</th>
		<th>Sks Mk</th>
		<th>Sks Tm</th>
		<th>Sks Prak</th>
		<th>Sks Prak Lap</th>
		<th>Sks Sim</th>
		<th>Bahasan Case</th>
		<th>A Selenggara Pditt</th>
		<th>A Pengguna Pditt</th>
		<th>Kuota Pditt</th>
		<th>Tgl Mulai Koas</th>
		<th>Tgl Selesai Koas</th>
		<th>Id Mou</th>
		<th>Id Mk</th>
		<th>Id Kls Pditt</th>
		
            </tr><?php
            foreach ($kelaskuliah_data as $kelaskuliah)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $kelaskuliah->id_sms ?></td>
		      <td><?php echo $kelaskuliah->id_smt ?></td>
		      <td><?php echo $kelaskuliah->nm_kls ?></td>
		      <td><?php echo $kelaskuliah->sks_mk ?></td>
		      <td><?php echo $kelaskuliah->sks_tm ?></td>
		      <td><?php echo $kelaskuliah->sks_prak ?></td>
		      <td><?php echo $kelaskuliah->sks_prak_lap ?></td>
		      <td><?php echo $kelaskuliah->sks_sim ?></td>
		      <td><?php echo $kelaskuliah->bahasan_case ?></td>
		      <td><?php echo $kelaskuliah->a_selenggara_pditt ?></td>
		      <td><?php echo $kelaskuliah->a_pengguna_pditt ?></td>
		      <td><?php echo $kelaskuliah->kuota_pditt ?></td>
		      <td><?php echo $kelaskuliah->tgl_mulai_koas ?></td>
		      <td><?php echo $kelaskuliah->tgl_selesai_koas ?></td>
		      <td><?php echo $kelaskuliah->id_mou ?></td>
		      <td><?php echo $kelaskuliah->id_mk ?></td>
		      <td><?php echo $kelaskuliah->id_kls_pditt ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>