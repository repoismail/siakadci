<div class="content-wrapper">
    
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">INPUT DATA KELAS_KULIAH</h3>
            </div>
            <form action="<?php echo $action; ?>" method="post">
            
<table class='table table-bordered>'        

	    <tr><td width='200'>Id Sms <?php echo form_error('id_sms') ?></td><td><input type="text" class="form-control" name="id_sms" id="id_sms" placeholder="Id Sms" value="<?php echo $id_sms; ?>" /></td></tr>
	    <tr><td width='200'>Id Smt <?php echo form_error('id_smt') ?></td><td><input type="text" class="form-control" name="id_smt" id="id_smt" placeholder="Id Smt" value="<?php echo $id_smt; ?>" /></td></tr>
	    <tr><td width='200'>Nm Kls <?php echo form_error('nm_kls') ?></td><td><input type="text" class="form-control" name="nm_kls" id="nm_kls" placeholder="Nm Kls" value="<?php echo $nm_kls; ?>" /></td></tr>
	    <tr><td width='200'>Sks Mk <?php echo form_error('sks_mk') ?></td><td><input type="text" class="form-control" name="sks_mk" id="sks_mk" placeholder="Sks Mk" value="<?php echo $sks_mk; ?>" /></td></tr>
	    <tr><td width='200'>Sks Tm <?php echo form_error('sks_tm') ?></td><td><input type="text" class="form-control" name="sks_tm" id="sks_tm" placeholder="Sks Tm" value="<?php echo $sks_tm; ?>" /></td></tr>
	    <tr><td width='200'>Sks Prak <?php echo form_error('sks_prak') ?></td><td><input type="text" class="form-control" name="sks_prak" id="sks_prak" placeholder="Sks Prak" value="<?php echo $sks_prak; ?>" /></td></tr>
	    <tr><td width='200'>Sks Prak Lap <?php echo form_error('sks_prak_lap') ?></td><td><input type="text" class="form-control" name="sks_prak_lap" id="sks_prak_lap" placeholder="Sks Prak Lap" value="<?php echo $sks_prak_lap; ?>" /></td></tr>
	    <tr><td width='200'>Sks Sim <?php echo form_error('sks_sim') ?></td><td><input type="text" class="form-control" name="sks_sim" id="sks_sim" placeholder="Sks Sim" value="<?php echo $sks_sim; ?>" /></td></tr>
	    <tr><td width='200'>Bahasan Case <?php echo form_error('bahasan_case') ?></td><td><input type="text" class="form-control" name="bahasan_case" id="bahasan_case" placeholder="Bahasan Case" value="<?php echo $bahasan_case; ?>" /></td></tr>
	    <tr><td width='200'>A Selenggara Pditt <?php echo form_error('a_selenggara_pditt') ?></td><td><input type="text" class="form-control" name="a_selenggara_pditt" id="a_selenggara_pditt" placeholder="A Selenggara Pditt" value="<?php echo $a_selenggara_pditt; ?>" /></td></tr>
	    <tr><td width='200'>A Pengguna Pditt <?php echo form_error('a_pengguna_pditt') ?></td><td><input type="text" class="form-control" name="a_pengguna_pditt" id="a_pengguna_pditt" placeholder="A Pengguna Pditt" value="<?php echo $a_pengguna_pditt; ?>" /></td></tr>
	    <tr><td width='200'>Kuota Pditt <?php echo form_error('kuota_pditt') ?></td><td><input type="text" class="form-control" name="kuota_pditt" id="kuota_pditt" placeholder="Kuota Pditt" value="<?php echo $kuota_pditt; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Mulai Koas <?php echo form_error('tgl_mulai_koas') ?></td><td><input type="date" class="form-control" name="tgl_mulai_koas" id="tgl_mulai_koas" placeholder="Tgl Mulai Koas" value="<?php echo $tgl_mulai_koas; ?>" /></td></tr>
	    <tr><td width='200'>Tgl Selesai Koas <?php echo form_error('tgl_selesai_koas') ?></td><td><input type="date" class="form-control" name="tgl_selesai_koas" id="tgl_selesai_koas" placeholder="Tgl Selesai Koas" value="<?php echo $tgl_selesai_koas; ?>" /></td></tr>
	    <tr><td width='200'>Id Mou <?php echo form_error('id_mou') ?></td><td><input type="text" class="form-control" name="id_mou" id="id_mou" placeholder="Id Mou" value="<?php echo $id_mou; ?>" /></td></tr>
	    <tr><td width='200'>Id Mk <?php echo form_error('id_mk') ?></td><td><input type="text" class="form-control" name="id_mk" id="id_mk" placeholder="Id Mk" value="<?php echo $id_mk; ?>" /></td></tr>
	    <tr><td width='200'>Id Kls Pditt <?php echo form_error('id_kls_pditt') ?></td><td><input type="text" class="form-control" name="id_kls_pditt" id="id_kls_pditt" placeholder="Id Kls Pditt" value="<?php echo $id_kls_pditt; ?>" /></td></tr>
	    <tr><td></td><td><input type="hidden" name="id_kls" value="<?php echo $id_kls; ?>" /> 
	    <button type="submit" class="btn btn-danger"><i class="fa fa-floppy-o"></i> <?php echo $button ?></button> 
	    <a href="<?php echo site_url('kelaskuliah') ?>" class="btn btn-info"><i class="fa fa-sign-out"></i> Kembali</a></td></tr>
	</table></form>        </div>
</div>
</div>