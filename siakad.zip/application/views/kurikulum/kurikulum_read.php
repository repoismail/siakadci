<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Kurikulum Read</h2>
        <table class="table">
	    <tr><td>Id Sms</td><td><?php echo $id_sms; ?></td></tr>
	    <tr><td>Id Jenj Didik</td><td><?php echo $id_jenj_didik; ?></td></tr>
	    <tr><td>Id Smt</td><td><?php echo $id_smt; ?></td></tr>
	    <tr><td>Nm Kurikulum Sp</td><td><?php echo $nm_kurikulum_sp; ?></td></tr>
	    <tr><td>Jml Sem Normal</td><td><?php echo $jml_sem_normal; ?></td></tr>
	    <tr><td>Jml Sks Lulus</td><td><?php echo $jml_sks_lulus; ?></td></tr>
	    <tr><td>Jml Sks Wajib</td><td><?php echo $jml_sks_wajib; ?></td></tr>
	    <tr><td>Jml Sks Pilihan</td><td><?php echo $jml_sks_pilihan; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('kurikulum') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>