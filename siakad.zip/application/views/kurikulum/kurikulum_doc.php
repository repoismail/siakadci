<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            .word-table {
                border:1px solid black !important; 
                border-collapse: collapse !important;
                width: 100%;
            }
            .word-table tr th, .word-table tr td{
                border:1px solid black !important; 
                padding: 5px 10px;
            }
        </style>
    </head>
    <body>
        <h2>Kurikulum List</h2>
        <table class="word-table" style="margin-bottom: 10px">
            <tr>
                <th>No</th>
		<th>Id Sms</th>
		<th>Id Jenj Didik</th>
		<th>Id Smt</th>
		<th>Nm Kurikulum Sp</th>
		<th>Jml Sem Normal</th>
		<th>Jml Sks Lulus</th>
		<th>Jml Sks Wajib</th>
		<th>Jml Sks Pilihan</th>
		
            </tr><?php
            foreach ($kurikulum_data as $kurikulum)
            {
                ?>
                <tr>
		      <td><?php echo ++$start ?></td>
		      <td><?php echo $kurikulum->id_sms ?></td>
		      <td><?php echo $kurikulum->id_jenj_didik ?></td>
		      <td><?php echo $kurikulum->id_smt ?></td>
		      <td><?php echo $kurikulum->nm_kurikulum_sp ?></td>
		      <td><?php echo $kurikulum->jml_sem_normal ?></td>
		      <td><?php echo $kurikulum->jml_sks_lulus ?></td>
		      <td><?php echo $kurikulum->jml_sks_wajib ?></td>
		      <td><?php echo $kurikulum->jml_sks_pilihan ?></td>	
                </tr>
                <?php
            }
            ?>
        </table>
    </body>
</html>