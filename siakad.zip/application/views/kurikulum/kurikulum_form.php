<div class="content-wrapper">
    
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">INPUT DATA KURIKULUM</h3>
            </div>
            <form action="<?php echo $action; ?>" method="post">
            
<table class='table table-bordered>'        

	    <tr><td width='200'>Id Sms <?php echo form_error('id_sms') ?></td><td><input type="text" class="form-control" name="id_sms" id="id_sms" placeholder="Id Sms" value="<?php echo $id_sms; ?>" /></td></tr>
	    <tr><td width='200'>Id Jenj Didik <?php echo form_error('id_jenj_didik') ?></td><td><input type="date" class="form-control" name="id_jenj_didik" id="id_jenj_didik" placeholder="Id Jenj Didik" value="<?php echo $id_jenj_didik; ?>" /></td></tr>
	    <tr><td width='200'>Id Smt <?php echo form_error('id_smt') ?></td><td><input type="text" class="form-control" name="id_smt" id="id_smt" placeholder="Id Smt" value="<?php echo $id_smt; ?>" /></td></tr>
	    <tr><td width='200'>Nm Kurikulum Sp <?php echo form_error('nm_kurikulum_sp') ?></td><td><input type="text" class="form-control" name="nm_kurikulum_sp" id="nm_kurikulum_sp" placeholder="Nm Kurikulum Sp" value="<?php echo $nm_kurikulum_sp; ?>" /></td></tr>
	    <tr><td width='200'>Jml Sem Normal <?php echo form_error('jml_sem_normal') ?></td><td><input type="text" class="form-control" name="jml_sem_normal" id="jml_sem_normal" placeholder="Jml Sem Normal" value="<?php echo $jml_sem_normal; ?>" /></td></tr>
	    <tr><td width='200'>Jml Sks Lulus <?php echo form_error('jml_sks_lulus') ?></td><td><input type="text" class="form-control" name="jml_sks_lulus" id="jml_sks_lulus" placeholder="Jml Sks Lulus" value="<?php echo $jml_sks_lulus; ?>" /></td></tr>
	    <tr><td width='200'>Jml Sks Wajib <?php echo form_error('jml_sks_wajib') ?></td><td><input type="text" class="form-control" name="jml_sks_wajib" id="jml_sks_wajib" placeholder="Jml Sks Wajib" value="<?php echo $jml_sks_wajib; ?>" /></td></tr>
	    <tr><td width='200'>Jml Sks Pilihan <?php echo form_error('jml_sks_pilihan') ?></td><td><input type="text" class="form-control" name="jml_sks_pilihan" id="jml_sks_pilihan" placeholder="Jml Sks Pilihan" value="<?php echo $jml_sks_pilihan; ?>" /></td></tr>
	    <tr><td></td><td><input type="hidden" name="id_kurikulum_sp" value="<?php echo $id_kurikulum_sp; ?>" /> 
	    <button type="submit" class="btn btn-danger"><i class="fa fa-floppy-o"></i> <?php echo $button ?></button> 
	    <a href="<?php echo site_url('kurikulum') ?>" class="btn btn-info"><i class="fa fa-sign-out"></i> Kembali</a></td></tr>
	</table></form>        </div>
</div>
</div>