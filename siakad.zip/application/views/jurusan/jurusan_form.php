<div class="content-wrapper">
    
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">INPUT DATA JURUSAN</h3>
            </div>
            <form action="<?php echo $action; ?>" method="post">
            
<table class='table table-bordered>'        

	    <tr><td width='200'>Nm Jur <?php echo form_error('nm_jur') ?></td><td><input type="text" class="form-control" name="nm_jur" id="nm_jur" placeholder="Nm Jur" value="<?php echo $nm_jur; ?>" /></td></tr>
	    <tr><td width='200'>Nm Intl Jur <?php echo form_error('nm_intl_jur') ?></td><td><input type="text" class="form-control" name="nm_intl_jur" id="nm_intl_jur" placeholder="Nm Intl Jur" value="<?php echo $nm_intl_jur; ?>" /></td></tr>
	    <tr><td width='200'>U Sma <?php echo form_error('u_sma') ?></td><td><input type="text" class="form-control" name="u_sma" id="u_sma" placeholder="U Sma" value="<?php echo $u_sma; ?>" /></td></tr>
	    <tr><td width='200'>U Smk <?php echo form_error('u_smk') ?></td><td><input type="text" class="form-control" name="u_smk" id="u_smk" placeholder="U Smk" value="<?php echo $u_smk; ?>" /></td></tr>
	    <tr><td width='200'>U Pt <?php echo form_error('u_pt') ?></td><td><input type="text" class="form-control" name="u_pt" id="u_pt" placeholder="U Pt" value="<?php echo $u_pt; ?>" /></td></tr>
	    <tr><td width='200'>U Slb <?php echo form_error('u_slb') ?></td><td><input type="text" class="form-control" name="u_slb" id="u_slb" placeholder="U Slb" value="<?php echo $u_slb; ?>" /></td></tr>
	    <tr><td width='200'>Id Kel Bidang <?php echo form_error('id_kel_bidang') ?></td><td><input type="text" class="form-control" name="id_kel_bidang" id="id_kel_bidang" placeholder="Id Kel Bidang" value="<?php echo $id_kel_bidang; ?>" /></td></tr>
	    <tr><td width='200'>Id Induk Jurusan <?php echo form_error('id_induk_jurusan') ?></td><td><input type="text" class="form-control" name="id_induk_jurusan" id="id_induk_jurusan" placeholder="Id Induk Jurusan" value="<?php echo $id_induk_jurusan; ?>" /></td></tr>
	    <tr><td width='200'>Id Jenj Didik <?php echo form_error('id_jenj_didik') ?></td><td><input type="text" class="form-control" name="id_jenj_didik" id="id_jenj_didik" placeholder="Id Jenj Didik" value="<?php echo $id_jenj_didik; ?>" /></td></tr>
	    <tr><td></td><td><input type="hidden" name="id_jur" value="<?php echo $id_jur; ?>" /> 
	    <button type="submit" class="btn btn-danger"><i class="fa fa-floppy-o"></i> <?php echo $button ?></button> 
	    <a href="<?php echo site_url('jurusan') ?>" class="btn btn-info"><i class="fa fa-sign-out"></i> Kembali</a></td></tr>
	</table></form>        </div>
</div>
</div>