<!doctype html>
<html>
    <head>
        <title>harviacode.com - codeigniter crud generator</title>
        <link rel="stylesheet" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css') ?>"/>
        <style>
            body{
                padding: 15px;
            }
        </style>
    </head>
    <body>
        <h2 style="margin-top:0px">Jurusan Read</h2>
        <table class="table">
	    <tr><td>Nm Jur</td><td><?php echo $nm_jur; ?></td></tr>
	    <tr><td>Nm Intl Jur</td><td><?php echo $nm_intl_jur; ?></td></tr>
	    <tr><td>U Sma</td><td><?php echo $u_sma; ?></td></tr>
	    <tr><td>U Smk</td><td><?php echo $u_smk; ?></td></tr>
	    <tr><td>U Pt</td><td><?php echo $u_pt; ?></td></tr>
	    <tr><td>U Slb</td><td><?php echo $u_slb; ?></td></tr>
	    <tr><td>Id Kel Bidang</td><td><?php echo $id_kel_bidang; ?></td></tr>
	    <tr><td>Id Induk Jurusan</td><td><?php echo $id_induk_jurusan; ?></td></tr>
	    <tr><td>Id Jenj Didik</td><td><?php echo $id_jenj_didik; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('jurusan') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </body>
</html>