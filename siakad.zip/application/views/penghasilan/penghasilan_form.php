<div class="content-wrapper">
    
    <section class="content">
        <div class="box box-warning box-solid">
            <div class="box-header with-border">
                <h3 class="box-title">INPUT DATA PENGHASILAN</h3>
            </div>
            <form action="<?php echo $action; ?>" method="post">
            
<table class='table table-bordered>'        

	    <tr><td width='200'>Nm Penghasilan <?php echo form_error('nm_penghasilan') ?></td><td><input type="text" class="form-control" name="nm_penghasilan" id="nm_penghasilan" placeholder="Nm Penghasilan" value="<?php echo $nm_penghasilan; ?>" /></td></tr>
	    <tr><td width='200'>Batas Bawah <?php echo form_error('batas_bawah') ?></td><td><input type="text" class="form-control" name="batas_bawah" id="batas_bawah" placeholder="Batas Bawah" value="<?php echo $batas_bawah; ?>" /></td></tr>
	    <tr><td width='200'>Batas Atas <?php echo form_error('batas_atas') ?></td><td><input type="text" class="form-control" name="batas_atas" id="batas_atas" placeholder="Batas Atas" value="<?php echo $batas_atas; ?>" /></td></tr>
	    <tr><td></td><td><input type="hidden" name="id_penghasilan" value="<?php echo $id_penghasilan; ?>" /> 
	    <button type="submit" class="btn btn-danger"><i class="fa fa-floppy-o"></i> <?php echo $button ?></button> 
	    <a href="<?php echo site_url('penghasilan') ?>" class="btn btn-info"><i class="fa fa-sign-out"></i> Kembali</a></td></tr>
	</table></form>        </div>
</div>
</div>