<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Kelaskuliah extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        is_login();
        $this->load->model('Kelas_kuliah_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->template->load('template','kelaskuliah/kelas_kuliah_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Kelas_kuliah_model->json();
    }

    public function read($id) 
    {
        $row = $this->Kelas_kuliah_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_kls' => $row->id_kls,
		'id_sms' => $row->id_sms,
		'id_smt' => $row->id_smt,
		'nm_kls' => $row->nm_kls,
		'sks_mk' => $row->sks_mk,
		'sks_tm' => $row->sks_tm,
		'sks_prak' => $row->sks_prak,
		'sks_prak_lap' => $row->sks_prak_lap,
		'sks_sim' => $row->sks_sim,
		'bahasan_case' => $row->bahasan_case,
		'a_selenggara_pditt' => $row->a_selenggara_pditt,
		'a_pengguna_pditt' => $row->a_pengguna_pditt,
		'kuota_pditt' => $row->kuota_pditt,
		'tgl_mulai_koas' => $row->tgl_mulai_koas,
		'tgl_selesai_koas' => $row->tgl_selesai_koas,
		'id_mou' => $row->id_mou,
		'id_mk' => $row->id_mk,
		'id_kls_pditt' => $row->id_kls_pditt,
	    );
            $this->template->load('template','kelaskuliah/kelas_kuliah_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('kelaskuliah'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('kelaskuliah/create_action'),
	    'id_kls' => set_value('id_kls'),
	    'id_sms' => set_value('id_sms'),
	    'id_smt' => set_value('id_smt'),
	    'nm_kls' => set_value('nm_kls'),
	    'sks_mk' => set_value('sks_mk'),
	    'sks_tm' => set_value('sks_tm'),
	    'sks_prak' => set_value('sks_prak'),
	    'sks_prak_lap' => set_value('sks_prak_lap'),
	    'sks_sim' => set_value('sks_sim'),
	    'bahasan_case' => set_value('bahasan_case'),
	    'a_selenggara_pditt' => set_value('a_selenggara_pditt'),
	    'a_pengguna_pditt' => set_value('a_pengguna_pditt'),
	    'kuota_pditt' => set_value('kuota_pditt'),
	    'tgl_mulai_koas' => set_value('tgl_mulai_koas'),
	    'tgl_selesai_koas' => set_value('tgl_selesai_koas'),
	    'id_mou' => set_value('id_mou'),
	    'id_mk' => set_value('id_mk'),
	    'id_kls_pditt' => set_value('id_kls_pditt'),
	);
        $this->template->load('template','kelaskuliah/kelas_kuliah_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'id_sms' => $this->input->post('id_sms',TRUE),
		'id_smt' => $this->input->post('id_smt',TRUE),
		'nm_kls' => $this->input->post('nm_kls',TRUE),
		'sks_mk' => $this->input->post('sks_mk',TRUE),
		'sks_tm' => $this->input->post('sks_tm',TRUE),
		'sks_prak' => $this->input->post('sks_prak',TRUE),
		'sks_prak_lap' => $this->input->post('sks_prak_lap',TRUE),
		'sks_sim' => $this->input->post('sks_sim',TRUE),
		'bahasan_case' => $this->input->post('bahasan_case',TRUE),
		'a_selenggara_pditt' => $this->input->post('a_selenggara_pditt',TRUE),
		'a_pengguna_pditt' => $this->input->post('a_pengguna_pditt',TRUE),
		'kuota_pditt' => $this->input->post('kuota_pditt',TRUE),
		'tgl_mulai_koas' => $this->input->post('tgl_mulai_koas',TRUE),
		'tgl_selesai_koas' => $this->input->post('tgl_selesai_koas',TRUE),
		'id_mou' => $this->input->post('id_mou',TRUE),
		'id_mk' => $this->input->post('id_mk',TRUE),
		'id_kls_pditt' => $this->input->post('id_kls_pditt',TRUE),
	    );

            $this->Kelas_kuliah_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success 2');
            redirect(site_url('kelaskuliah'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Kelas_kuliah_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('kelaskuliah/update_action'),
		'id_kls' => set_value('id_kls', $row->id_kls),
		'id_sms' => set_value('id_sms', $row->id_sms),
		'id_smt' => set_value('id_smt', $row->id_smt),
		'nm_kls' => set_value('nm_kls', $row->nm_kls),
		'sks_mk' => set_value('sks_mk', $row->sks_mk),
		'sks_tm' => set_value('sks_tm', $row->sks_tm),
		'sks_prak' => set_value('sks_prak', $row->sks_prak),
		'sks_prak_lap' => set_value('sks_prak_lap', $row->sks_prak_lap),
		'sks_sim' => set_value('sks_sim', $row->sks_sim),
		'bahasan_case' => set_value('bahasan_case', $row->bahasan_case),
		'a_selenggara_pditt' => set_value('a_selenggara_pditt', $row->a_selenggara_pditt),
		'a_pengguna_pditt' => set_value('a_pengguna_pditt', $row->a_pengguna_pditt),
		'kuota_pditt' => set_value('kuota_pditt', $row->kuota_pditt),
		'tgl_mulai_koas' => set_value('tgl_mulai_koas', $row->tgl_mulai_koas),
		'tgl_selesai_koas' => set_value('tgl_selesai_koas', $row->tgl_selesai_koas),
		'id_mou' => set_value('id_mou', $row->id_mou),
		'id_mk' => set_value('id_mk', $row->id_mk),
		'id_kls_pditt' => set_value('id_kls_pditt', $row->id_kls_pditt),
	    );
            $this->template->load('template','kelaskuliah/kelas_kuliah_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('kelaskuliah'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_kls', TRUE));
        } else {
            $data = array(
		'id_sms' => $this->input->post('id_sms',TRUE),
		'id_smt' => $this->input->post('id_smt',TRUE),
		'nm_kls' => $this->input->post('nm_kls',TRUE),
		'sks_mk' => $this->input->post('sks_mk',TRUE),
		'sks_tm' => $this->input->post('sks_tm',TRUE),
		'sks_prak' => $this->input->post('sks_prak',TRUE),
		'sks_prak_lap' => $this->input->post('sks_prak_lap',TRUE),
		'sks_sim' => $this->input->post('sks_sim',TRUE),
		'bahasan_case' => $this->input->post('bahasan_case',TRUE),
		'a_selenggara_pditt' => $this->input->post('a_selenggara_pditt',TRUE),
		'a_pengguna_pditt' => $this->input->post('a_pengguna_pditt',TRUE),
		'kuota_pditt' => $this->input->post('kuota_pditt',TRUE),
		'tgl_mulai_koas' => $this->input->post('tgl_mulai_koas',TRUE),
		'tgl_selesai_koas' => $this->input->post('tgl_selesai_koas',TRUE),
		'id_mou' => $this->input->post('id_mou',TRUE),
		'id_mk' => $this->input->post('id_mk',TRUE),
		'id_kls_pditt' => $this->input->post('id_kls_pditt',TRUE),
	    );

            $this->Kelas_kuliah_model->update($this->input->post('id_kls', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('kelaskuliah'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Kelas_kuliah_model->get_by_id($id);

        if ($row) {
            $this->Kelas_kuliah_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('kelaskuliah'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('kelaskuliah'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_sms', 'id sms', 'trim|required');
	$this->form_validation->set_rules('id_smt', 'id smt', 'trim|required');
	$this->form_validation->set_rules('nm_kls', 'nm kls', 'trim|required');
	$this->form_validation->set_rules('sks_mk', 'sks mk', 'trim|required|numeric');
	$this->form_validation->set_rules('sks_tm', 'sks tm', 'trim|required|numeric');
	$this->form_validation->set_rules('sks_prak', 'sks prak', 'trim|required|numeric');
	$this->form_validation->set_rules('sks_prak_lap', 'sks prak lap', 'trim|required|numeric');
	$this->form_validation->set_rules('sks_sim', 'sks sim', 'trim|required|numeric');
	$this->form_validation->set_rules('bahasan_case', 'bahasan case', 'trim|required');
	$this->form_validation->set_rules('a_selenggara_pditt', 'a selenggara pditt', 'trim|required|numeric');
	$this->form_validation->set_rules('a_pengguna_pditt', 'a pengguna pditt', 'trim|required|numeric');
	$this->form_validation->set_rules('kuota_pditt', 'kuota pditt', 'trim|required|numeric');
	$this->form_validation->set_rules('tgl_mulai_koas', 'tgl mulai koas', 'trim|required');
	$this->form_validation->set_rules('tgl_selesai_koas', 'tgl selesai koas', 'trim|required');
	$this->form_validation->set_rules('id_mou', 'id mou', 'trim|required');
	$this->form_validation->set_rules('id_mk', 'id mk', 'trim|required');
	$this->form_validation->set_rules('id_kls_pditt', 'id kls pditt', 'trim|required');

	$this->form_validation->set_rules('id_kls', 'id_kls', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "kelas_kuliah.xls";
        $judul = "kelas_kuliah";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Sms");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Smt");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Kls");
	xlsWriteLabel($tablehead, $kolomhead++, "Sks Mk");
	xlsWriteLabel($tablehead, $kolomhead++, "Sks Tm");
	xlsWriteLabel($tablehead, $kolomhead++, "Sks Prak");
	xlsWriteLabel($tablehead, $kolomhead++, "Sks Prak Lap");
	xlsWriteLabel($tablehead, $kolomhead++, "Sks Sim");
	xlsWriteLabel($tablehead, $kolomhead++, "Bahasan Case");
	xlsWriteLabel($tablehead, $kolomhead++, "A Selenggara Pditt");
	xlsWriteLabel($tablehead, $kolomhead++, "A Pengguna Pditt");
	xlsWriteLabel($tablehead, $kolomhead++, "Kuota Pditt");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Mulai Koas");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Selesai Koas");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Mou");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Mk");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Kls Pditt");

	foreach ($this->Kelas_kuliah_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_sms);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_smt);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_kls);
	    xlsWriteNumber($tablebody, $kolombody++, $data->sks_mk);
	    xlsWriteNumber($tablebody, $kolombody++, $data->sks_tm);
	    xlsWriteNumber($tablebody, $kolombody++, $data->sks_prak);
	    xlsWriteNumber($tablebody, $kolombody++, $data->sks_prak_lap);
	    xlsWriteNumber($tablebody, $kolombody++, $data->sks_sim);
	    xlsWriteLabel($tablebody, $kolombody++, $data->bahasan_case);
	    xlsWriteNumber($tablebody, $kolombody++, $data->a_selenggara_pditt);
	    xlsWriteNumber($tablebody, $kolombody++, $data->a_pengguna_pditt);
	    xlsWriteNumber($tablebody, $kolombody++, $data->kuota_pditt);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_mulai_koas);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_selesai_koas);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_mou);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_mk);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_kls_pditt);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=kelas_kuliah.doc");

        $data = array(
            'kelas_kuliah_data' => $this->Kelas_kuliah_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('kelaskuliah/kelas_kuliah_doc',$data);
    }

}

/* End of file Kelaskuliah.php */
/* Location: ./application/controllers/Kelaskuliah.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-22 23:51:38 */
/* http://harviacode.com */