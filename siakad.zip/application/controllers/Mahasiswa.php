<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Mahasiswa extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        is_login();
        $this->load->model('Mahasiswa_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->template->load('template','mahasiswa/mahasiswa_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Mahasiswa_model->json();
    }

    public function read($id) 
    {
        $row = $this->Mahasiswa_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_pd' => $row->id_pd,
		'nm_pd' => $row->nm_pd,
		'jk' => $row->jk,
		'jln' => $row->jln,
		'rt' => $row->rt,
		'rw' => $row->rw,
		'nm_dsn' => $row->nm_dsn,
		'ds_kel' => $row->ds_kel,
		'kode_pos' => $row->kode_pos,
		'nisn' => $row->nisn,
		'nik' => $row->nik,
		'tmpt_lahir' => $row->tmpt_lahir,
		'tgl_lahir' => $row->tgl_lahir,
		'nm_ayah' => $row->nm_ayah,
		'tgl_lahir_ayah' => $row->tgl_lahir_ayah,
		'nik_ayah' => $row->nik_ayah,
		'id_jenjang_pendidikan_ayah' => $row->id_jenjang_pendidikan_ayah,
		'id_pekerjaan_ayah' => $row->id_pekerjaan_ayah,
		'id_penghasilan_ayah' => $row->id_penghasilan_ayah,
		'id_kebutuhan_khusus_ayah' => $row->id_kebutuhan_khusus_ayah,
		'nm_ibu_kandung' => $row->nm_ibu_kandung,
		'tgl_lahir_ibu' => $row->tgl_lahir_ibu,
		'nik_ibu' => $row->nik_ibu,
		'id_jenjang_pendidikan_ibu' => $row->id_jenjang_pendidikan_ibu,
		'id_pekerjaan_ibu' => $row->id_pekerjaan_ibu,
		'id_penghasilan_ibu' => $row->id_penghasilan_ibu,
		'id_kebutuhan_khusus_ibu' => $row->id_kebutuhan_khusus_ibu,
		'nm_wali' => $row->nm_wali,
		'tgl_lahir_wali' => $row->tgl_lahir_wali,
		'id_jenjang_pendidikan_wali' => $row->id_jenjang_pendidikan_wali,
		'id_pekerjaan_wali' => $row->id_pekerjaan_wali,
		'id_penghasilan_wali' => $row->id_penghasilan_wali,
		'id_kk' => $row->id_kk,
		'no_tel_rmh' => $row->no_tel_rmh,
		'no_hp' => $row->no_hp,
		'email' => $row->email,
		'a_terima_kps' => $row->a_terima_kps,
		'no_kps' => $row->no_kps,
		'npwp' => $row->npwp,
		'id_wil' => $row->id_wil,
		'id_jns_tinggal' => $row->id_jns_tinggal,
		'id_agama' => $row->id_agama,
		'id_alat_transport' => $row->id_alat_transport,
		'kewarganegaraan' => $row->kewarganegaraan,
	    );
            $this->template->load('template','mahasiswa/mahasiswa_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('mahasiswa'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('mahasiswa/create_action'),
	    'id_pd' => set_value('id_pd'),
	    'nm_pd' => set_value('nm_pd'),
	    'jk' => set_value('jk'),
	    'jln' => set_value('jln'),
	    'rt' => set_value('rt'),
	    'rw' => set_value('rw'),
	    'nm_dsn' => set_value('nm_dsn'),
	    'ds_kel' => set_value('ds_kel'),
	    'kode_pos' => set_value('kode_pos'),
	    'nisn' => set_value('nisn'),
	    'nik' => set_value('nik'),
	    'tmpt_lahir' => set_value('tmpt_lahir'),
	    'tgl_lahir' => set_value('tgl_lahir'),
	    'nm_ayah' => set_value('nm_ayah'),
	    'tgl_lahir_ayah' => set_value('tgl_lahir_ayah'),
	    'nik_ayah' => set_value('nik_ayah'),
	    'id_jenjang_pendidikan_ayah' => set_value('id_jenjang_pendidikan_ayah'),
	    'id_pekerjaan_ayah' => set_value('id_pekerjaan_ayah'),
	    'id_penghasilan_ayah' => set_value('id_penghasilan_ayah'),
	    'id_kebutuhan_khusus_ayah' => set_value('id_kebutuhan_khusus_ayah'),
	    'nm_ibu_kandung' => set_value('nm_ibu_kandung'),
	    'tgl_lahir_ibu' => set_value('tgl_lahir_ibu'),
	    'nik_ibu' => set_value('nik_ibu'),
	    'id_jenjang_pendidikan_ibu' => set_value('id_jenjang_pendidikan_ibu'),
	    'id_pekerjaan_ibu' => set_value('id_pekerjaan_ibu'),
	    'id_penghasilan_ibu' => set_value('id_penghasilan_ibu'),
	    'id_kebutuhan_khusus_ibu' => set_value('id_kebutuhan_khusus_ibu'),
	    'nm_wali' => set_value('nm_wali'),
	    'tgl_lahir_wali' => set_value('tgl_lahir_wali'),
	    'id_jenjang_pendidikan_wali' => set_value('id_jenjang_pendidikan_wali'),
	    'id_pekerjaan_wali' => set_value('id_pekerjaan_wali'),
	    'id_penghasilan_wali' => set_value('id_penghasilan_wali'),
	    'id_kk' => set_value('id_kk'),
	    'no_tel_rmh' => set_value('no_tel_rmh'),
	    'no_hp' => set_value('no_hp'),
	    'email' => set_value('email'),
	    'a_terima_kps' => set_value('a_terima_kps'),
	    'no_kps' => set_value('no_kps'),
	    'npwp' => set_value('npwp'),
	    'id_wil' => set_value('id_wil'),
	    'id_jns_tinggal' => set_value('id_jns_tinggal'),
	    'id_agama' => set_value('id_agama'),
	    'id_alat_transport' => set_value('id_alat_transport'),
	    'kewarganegaraan' => set_value('kewarganegaraan'),
	);
        $this->template->load('template','mahasiswa/mahasiswa_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'nm_pd' => $this->input->post('nm_pd',TRUE),
		'jk' => $this->input->post('jk',TRUE),
		'jln' => $this->input->post('jln',TRUE),
		'rt' => $this->input->post('rt',TRUE),
		'rw' => $this->input->post('rw',TRUE),
		'nm_dsn' => $this->input->post('nm_dsn',TRUE),
		'ds_kel' => $this->input->post('ds_kel',TRUE),
		'kode_pos' => $this->input->post('kode_pos',TRUE),
		'nisn' => $this->input->post('nisn',TRUE),
		'nik' => $this->input->post('nik',TRUE),
		'tmpt_lahir' => $this->input->post('tmpt_lahir',TRUE),
		'tgl_lahir' => $this->input->post('tgl_lahir',TRUE),
		'nm_ayah' => $this->input->post('nm_ayah',TRUE),
		'tgl_lahir_ayah' => $this->input->post('tgl_lahir_ayah',TRUE),
		'nik_ayah' => $this->input->post('nik_ayah',TRUE),
		'id_jenjang_pendidikan_ayah' => $this->input->post('id_jenjang_pendidikan_ayah',TRUE),
		'id_pekerjaan_ayah' => $this->input->post('id_pekerjaan_ayah',TRUE),
		'id_penghasilan_ayah' => $this->input->post('id_penghasilan_ayah',TRUE),
		'id_kebutuhan_khusus_ayah' => $this->input->post('id_kebutuhan_khusus_ayah',TRUE),
		'nm_ibu_kandung' => $this->input->post('nm_ibu_kandung',TRUE),
		'tgl_lahir_ibu' => $this->input->post('tgl_lahir_ibu',TRUE),
		'nik_ibu' => $this->input->post('nik_ibu',TRUE),
		'id_jenjang_pendidikan_ibu' => $this->input->post('id_jenjang_pendidikan_ibu',TRUE),
		'id_pekerjaan_ibu' => $this->input->post('id_pekerjaan_ibu',TRUE),
		'id_penghasilan_ibu' => $this->input->post('id_penghasilan_ibu',TRUE),
		'id_kebutuhan_khusus_ibu' => $this->input->post('id_kebutuhan_khusus_ibu',TRUE),
		'nm_wali' => $this->input->post('nm_wali',TRUE),
		'tgl_lahir_wali' => $this->input->post('tgl_lahir_wali',TRUE),
		'id_jenjang_pendidikan_wali' => $this->input->post('id_jenjang_pendidikan_wali',TRUE),
		'id_pekerjaan_wali' => $this->input->post('id_pekerjaan_wali',TRUE),
		'id_penghasilan_wali' => $this->input->post('id_penghasilan_wali',TRUE),
		'id_kk' => $this->input->post('id_kk',TRUE),
		'no_tel_rmh' => $this->input->post('no_tel_rmh',TRUE),
		'no_hp' => $this->input->post('no_hp',TRUE),
		'email' => $this->input->post('email',TRUE),
		'a_terima_kps' => $this->input->post('a_terima_kps',TRUE),
		'no_kps' => $this->input->post('no_kps',TRUE),
		'npwp' => $this->input->post('npwp',TRUE),
		'id_wil' => $this->input->post('id_wil',TRUE),
		'id_jns_tinggal' => $this->input->post('id_jns_tinggal',TRUE),
		'id_agama' => $this->input->post('id_agama',TRUE),
		'id_alat_transport' => $this->input->post('id_alat_transport',TRUE),
		'kewarganegaraan' => $this->input->post('kewarganegaraan',TRUE),
	    );

            $this->Mahasiswa_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success 2');
            redirect(site_url('mahasiswa'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Mahasiswa_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('mahasiswa/update_action'),
		'id_pd' => set_value('id_pd', $row->id_pd),
		'nm_pd' => set_value('nm_pd', $row->nm_pd),
		'jk' => set_value('jk', $row->jk),
		'jln' => set_value('jln', $row->jln),
		'rt' => set_value('rt', $row->rt),
		'rw' => set_value('rw', $row->rw),
		'nm_dsn' => set_value('nm_dsn', $row->nm_dsn),
		'ds_kel' => set_value('ds_kel', $row->ds_kel),
		'kode_pos' => set_value('kode_pos', $row->kode_pos),
		'nisn' => set_value('nisn', $row->nisn),
		'nik' => set_value('nik', $row->nik),
		'tmpt_lahir' => set_value('tmpt_lahir', $row->tmpt_lahir),
		'tgl_lahir' => set_value('tgl_lahir', $row->tgl_lahir),
		'nm_ayah' => set_value('nm_ayah', $row->nm_ayah),
		'tgl_lahir_ayah' => set_value('tgl_lahir_ayah', $row->tgl_lahir_ayah),
		'nik_ayah' => set_value('nik_ayah', $row->nik_ayah),
		'id_jenjang_pendidikan_ayah' => set_value('id_jenjang_pendidikan_ayah', $row->id_jenjang_pendidikan_ayah),
		'id_pekerjaan_ayah' => set_value('id_pekerjaan_ayah', $row->id_pekerjaan_ayah),
		'id_penghasilan_ayah' => set_value('id_penghasilan_ayah', $row->id_penghasilan_ayah),
		'id_kebutuhan_khusus_ayah' => set_value('id_kebutuhan_khusus_ayah', $row->id_kebutuhan_khusus_ayah),
		'nm_ibu_kandung' => set_value('nm_ibu_kandung', $row->nm_ibu_kandung),
		'tgl_lahir_ibu' => set_value('tgl_lahir_ibu', $row->tgl_lahir_ibu),
		'nik_ibu' => set_value('nik_ibu', $row->nik_ibu),
		'id_jenjang_pendidikan_ibu' => set_value('id_jenjang_pendidikan_ibu', $row->id_jenjang_pendidikan_ibu),
		'id_pekerjaan_ibu' => set_value('id_pekerjaan_ibu', $row->id_pekerjaan_ibu),
		'id_penghasilan_ibu' => set_value('id_penghasilan_ibu', $row->id_penghasilan_ibu),
		'id_kebutuhan_khusus_ibu' => set_value('id_kebutuhan_khusus_ibu', $row->id_kebutuhan_khusus_ibu),
		'nm_wali' => set_value('nm_wali', $row->nm_wali),
		'tgl_lahir_wali' => set_value('tgl_lahir_wali', $row->tgl_lahir_wali),
		'id_jenjang_pendidikan_wali' => set_value('id_jenjang_pendidikan_wali', $row->id_jenjang_pendidikan_wali),
		'id_pekerjaan_wali' => set_value('id_pekerjaan_wali', $row->id_pekerjaan_wali),
		'id_penghasilan_wali' => set_value('id_penghasilan_wali', $row->id_penghasilan_wali),
		'id_kk' => set_value('id_kk', $row->id_kk),
		'no_tel_rmh' => set_value('no_tel_rmh', $row->no_tel_rmh),
		'no_hp' => set_value('no_hp', $row->no_hp),
		'email' => set_value('email', $row->email),
		'a_terima_kps' => set_value('a_terima_kps', $row->a_terima_kps),
		'no_kps' => set_value('no_kps', $row->no_kps),
		'npwp' => set_value('npwp', $row->npwp),
		'id_wil' => set_value('id_wil', $row->id_wil),
		'id_jns_tinggal' => set_value('id_jns_tinggal', $row->id_jns_tinggal),
		'id_agama' => set_value('id_agama', $row->id_agama),
		'id_alat_transport' => set_value('id_alat_transport', $row->id_alat_transport),
		'kewarganegaraan' => set_value('kewarganegaraan', $row->kewarganegaraan),
	    );
            $this->template->load('template','mahasiswa/mahasiswa_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('mahasiswa'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_pd', TRUE));
        } else {
            $data = array(
		'nm_pd' => $this->input->post('nm_pd',TRUE),
		'jk' => $this->input->post('jk',TRUE),
		'jln' => $this->input->post('jln',TRUE),
		'rt' => $this->input->post('rt',TRUE),
		'rw' => $this->input->post('rw',TRUE),
		'nm_dsn' => $this->input->post('nm_dsn',TRUE),
		'ds_kel' => $this->input->post('ds_kel',TRUE),
		'kode_pos' => $this->input->post('kode_pos',TRUE),
		'nisn' => $this->input->post('nisn',TRUE),
		'nik' => $this->input->post('nik',TRUE),
		'tmpt_lahir' => $this->input->post('tmpt_lahir',TRUE),
		'tgl_lahir' => $this->input->post('tgl_lahir',TRUE),
		'nm_ayah' => $this->input->post('nm_ayah',TRUE),
		'tgl_lahir_ayah' => $this->input->post('tgl_lahir_ayah',TRUE),
		'nik_ayah' => $this->input->post('nik_ayah',TRUE),
		'id_jenjang_pendidikan_ayah' => $this->input->post('id_jenjang_pendidikan_ayah',TRUE),
		'id_pekerjaan_ayah' => $this->input->post('id_pekerjaan_ayah',TRUE),
		'id_penghasilan_ayah' => $this->input->post('id_penghasilan_ayah',TRUE),
		'id_kebutuhan_khusus_ayah' => $this->input->post('id_kebutuhan_khusus_ayah',TRUE),
		'nm_ibu_kandung' => $this->input->post('nm_ibu_kandung',TRUE),
		'tgl_lahir_ibu' => $this->input->post('tgl_lahir_ibu',TRUE),
		'nik_ibu' => $this->input->post('nik_ibu',TRUE),
		'id_jenjang_pendidikan_ibu' => $this->input->post('id_jenjang_pendidikan_ibu',TRUE),
		'id_pekerjaan_ibu' => $this->input->post('id_pekerjaan_ibu',TRUE),
		'id_penghasilan_ibu' => $this->input->post('id_penghasilan_ibu',TRUE),
		'id_kebutuhan_khusus_ibu' => $this->input->post('id_kebutuhan_khusus_ibu',TRUE),
		'nm_wali' => $this->input->post('nm_wali',TRUE),
		'tgl_lahir_wali' => $this->input->post('tgl_lahir_wali',TRUE),
		'id_jenjang_pendidikan_wali' => $this->input->post('id_jenjang_pendidikan_wali',TRUE),
		'id_pekerjaan_wali' => $this->input->post('id_pekerjaan_wali',TRUE),
		'id_penghasilan_wali' => $this->input->post('id_penghasilan_wali',TRUE),
		'id_kk' => $this->input->post('id_kk',TRUE),
		'no_tel_rmh' => $this->input->post('no_tel_rmh',TRUE),
		'no_hp' => $this->input->post('no_hp',TRUE),
		'email' => $this->input->post('email',TRUE),
		'a_terima_kps' => $this->input->post('a_terima_kps',TRUE),
		'no_kps' => $this->input->post('no_kps',TRUE),
		'npwp' => $this->input->post('npwp',TRUE),
		'id_wil' => $this->input->post('id_wil',TRUE),
		'id_jns_tinggal' => $this->input->post('id_jns_tinggal',TRUE),
		'id_agama' => $this->input->post('id_agama',TRUE),
		'id_alat_transport' => $this->input->post('id_alat_transport',TRUE),
		'kewarganegaraan' => $this->input->post('kewarganegaraan',TRUE),
	    );

            $this->Mahasiswa_model->update($this->input->post('id_pd', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('mahasiswa'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Mahasiswa_model->get_by_id($id);

        if ($row) {
            $this->Mahasiswa_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('mahasiswa'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('mahasiswa'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('nm_pd', 'nm pd', 'trim|required');
	$this->form_validation->set_rules('jk', 'jk', 'trim|required');
	$this->form_validation->set_rules('jln', 'jln', 'trim|required');
	$this->form_validation->set_rules('rt', 'rt', 'trim|required|numeric');
	$this->form_validation->set_rules('rw', 'rw', 'trim|required|numeric');
	$this->form_validation->set_rules('nm_dsn', 'nm dsn', 'trim|required');
	$this->form_validation->set_rules('ds_kel', 'ds kel', 'trim|required');
	$this->form_validation->set_rules('kode_pos', 'kode pos', 'trim|required');
	$this->form_validation->set_rules('nisn', 'nisn', 'trim|required');
	$this->form_validation->set_rules('nik', 'nik', 'trim|required');
	$this->form_validation->set_rules('tmpt_lahir', 'tmpt lahir', 'trim|required');
	$this->form_validation->set_rules('tgl_lahir', 'tgl lahir', 'trim|required');
	$this->form_validation->set_rules('nm_ayah', 'nm ayah', 'trim|required');
	$this->form_validation->set_rules('tgl_lahir_ayah', 'tgl lahir ayah', 'trim|required');
	$this->form_validation->set_rules('nik_ayah', 'nik ayah', 'trim|required');
	$this->form_validation->set_rules('id_jenjang_pendidikan_ayah', 'id jenjang pendidikan ayah', 'trim|required|numeric');
	$this->form_validation->set_rules('id_pekerjaan_ayah', 'id pekerjaan ayah', 'trim|required');
	$this->form_validation->set_rules('id_penghasilan_ayah', 'id penghasilan ayah', 'trim|required');
	$this->form_validation->set_rules('id_kebutuhan_khusus_ayah', 'id kebutuhan khusus ayah', 'trim|required');
	$this->form_validation->set_rules('nm_ibu_kandung', 'nm ibu kandung', 'trim|required');
	$this->form_validation->set_rules('tgl_lahir_ibu', 'tgl lahir ibu', 'trim|required');
	$this->form_validation->set_rules('nik_ibu', 'nik ibu', 'trim|required');
	$this->form_validation->set_rules('id_jenjang_pendidikan_ibu', 'id jenjang pendidikan ibu', 'trim|required|numeric');
	$this->form_validation->set_rules('id_pekerjaan_ibu', 'id pekerjaan ibu', 'trim|required');
	$this->form_validation->set_rules('id_penghasilan_ibu', 'id penghasilan ibu', 'trim|required');
	$this->form_validation->set_rules('id_kebutuhan_khusus_ibu', 'id kebutuhan khusus ibu', 'trim|required');
	$this->form_validation->set_rules('nm_wali', 'nm wali', 'trim|required');
	$this->form_validation->set_rules('tgl_lahir_wali', 'tgl lahir wali', 'trim|required');
	$this->form_validation->set_rules('id_jenjang_pendidikan_wali', 'id jenjang pendidikan wali', 'trim|required|numeric');
	$this->form_validation->set_rules('id_pekerjaan_wali', 'id pekerjaan wali', 'trim|required');
	$this->form_validation->set_rules('id_penghasilan_wali', 'id penghasilan wali', 'trim|required');
	$this->form_validation->set_rules('id_kk', 'id kk', 'trim|required');
	$this->form_validation->set_rules('no_tel_rmh', 'no tel rmh', 'trim|required');
	$this->form_validation->set_rules('no_hp', 'no hp', 'trim|required');
	$this->form_validation->set_rules('email', 'email', 'trim|required');
	$this->form_validation->set_rules('a_terima_kps', 'a terima kps', 'trim|required|numeric');
	$this->form_validation->set_rules('no_kps', 'no kps', 'trim|required');
	$this->form_validation->set_rules('npwp', 'npwp', 'trim|required');
	$this->form_validation->set_rules('id_wil', 'id wil', 'trim|required');
	$this->form_validation->set_rules('id_jns_tinggal', 'id jns tinggal', 'trim|required|numeric');
	$this->form_validation->set_rules('id_agama', 'id agama', 'trim|required');
	$this->form_validation->set_rules('id_alat_transport', 'id alat transport', 'trim|required|numeric');
	$this->form_validation->set_rules('kewarganegaraan', 'kewarganegaraan', 'trim|required');

	$this->form_validation->set_rules('id_pd', 'id_pd', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "mahasiswa.xls";
        $judul = "mahasiswa";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Pd");
	xlsWriteLabel($tablehead, $kolomhead++, "Jk");
	xlsWriteLabel($tablehead, $kolomhead++, "Jln");
	xlsWriteLabel($tablehead, $kolomhead++, "Rt");
	xlsWriteLabel($tablehead, $kolomhead++, "Rw");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Dsn");
	xlsWriteLabel($tablehead, $kolomhead++, "Ds Kel");
	xlsWriteLabel($tablehead, $kolomhead++, "Kode Pos");
	xlsWriteLabel($tablehead, $kolomhead++, "Nisn");
	xlsWriteLabel($tablehead, $kolomhead++, "Nik");
	xlsWriteLabel($tablehead, $kolomhead++, "Tmpt Lahir");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Lahir");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Ayah");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Lahir Ayah");
	xlsWriteLabel($tablehead, $kolomhead++, "Nik Ayah");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Jenjang Pendidikan Ayah");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Pekerjaan Ayah");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Penghasilan Ayah");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Kebutuhan Khusus Ayah");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Ibu Kandung");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Lahir Ibu");
	xlsWriteLabel($tablehead, $kolomhead++, "Nik Ibu");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Jenjang Pendidikan Ibu");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Pekerjaan Ibu");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Penghasilan Ibu");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Kebutuhan Khusus Ibu");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Wali");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Lahir Wali");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Jenjang Pendidikan Wali");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Pekerjaan Wali");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Penghasilan Wali");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Kk");
	xlsWriteLabel($tablehead, $kolomhead++, "No Tel Rmh");
	xlsWriteLabel($tablehead, $kolomhead++, "No Hp");
	xlsWriteLabel($tablehead, $kolomhead++, "Email");
	xlsWriteLabel($tablehead, $kolomhead++, "A Terima Kps");
	xlsWriteLabel($tablehead, $kolomhead++, "No Kps");
	xlsWriteLabel($tablehead, $kolomhead++, "Npwp");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Wil");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Jns Tinggal");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Agama");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Alat Transport");
	xlsWriteLabel($tablehead, $kolomhead++, "Kewarganegaraan");

	foreach ($this->Mahasiswa_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_pd);
	    xlsWriteLabel($tablebody, $kolombody++, $data->jk);
	    xlsWriteLabel($tablebody, $kolombody++, $data->jln);
	    xlsWriteNumber($tablebody, $kolombody++, $data->rt);
	    xlsWriteNumber($tablebody, $kolombody++, $data->rw);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_dsn);
	    xlsWriteLabel($tablebody, $kolombody++, $data->ds_kel);
	    xlsWriteLabel($tablebody, $kolombody++, $data->kode_pos);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nisn);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nik);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tmpt_lahir);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_lahir);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_ayah);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_lahir_ayah);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nik_ayah);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_jenjang_pendidikan_ayah);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_pekerjaan_ayah);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_penghasilan_ayah);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_kebutuhan_khusus_ayah);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_ibu_kandung);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_lahir_ibu);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nik_ibu);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_jenjang_pendidikan_ibu);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_pekerjaan_ibu);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_penghasilan_ibu);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_kebutuhan_khusus_ibu);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_wali);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_lahir_wali);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_jenjang_pendidikan_wali);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_pekerjaan_wali);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_penghasilan_wali);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_kk);
	    xlsWriteLabel($tablebody, $kolombody++, $data->no_tel_rmh);
	    xlsWriteLabel($tablebody, $kolombody++, $data->no_hp);
	    xlsWriteLabel($tablebody, $kolombody++, $data->email);
	    xlsWriteNumber($tablebody, $kolombody++, $data->a_terima_kps);
	    xlsWriteLabel($tablebody, $kolombody++, $data->no_kps);
	    xlsWriteLabel($tablebody, $kolombody++, $data->npwp);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_wil);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_jns_tinggal);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_agama);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_alat_transport);
	    xlsWriteLabel($tablebody, $kolombody++, $data->kewarganegaraan);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=mahasiswa.doc");

        $data = array(
            'mahasiswa_data' => $this->Mahasiswa_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('mahasiswa/mahasiswa_doc',$data);
    }

}

/* End of file Mahasiswa.php */
/* Location: ./application/controllers/Mahasiswa.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-22 23:46:11 */
/* http://harviacode.com */