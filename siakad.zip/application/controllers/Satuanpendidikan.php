<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Satuanpendidikan extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        is_login();
        $this->load->model('Satuan_pendidikan_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->template->load('template','satuanpendidikan/satuan_pendidikan_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Satuan_pendidikan_model->json();
    }

    public function read($id) 
    {
        $row = $this->Satuan_pendidikan_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_sp' => $row->id_sp,
		'nm_lemb' => $row->nm_lemb,
		'nss' => $row->nss,
		'npsn' => $row->npsn,
		'nm_singkat' => $row->nm_singkat,
		'jln' => $row->jln,
		'rt' => $row->rt,
		'rw' => $row->rw,
		'nm_dsn' => $row->nm_dsn,
		'ds_kel' => $row->ds_kel,
		'kode_pos' => $row->kode_pos,
		'lintang' => $row->lintang,
		'bujur' => $row->bujur,
		'no_tel' => $row->no_tel,
		'no_fax' => $row->no_fax,
		'email' => $row->email,
		'website' => $row->website,
		'stat_sp' => $row->stat_sp,
		'sk_pendirian_sp' => $row->sk_pendirian_sp,
		'tgl_sk_pendirian_sp' => $row->tgl_sk_pendirian_sp,
		'tgl_berdiri' => $row->tgl_berdiri,
		'sk_izin_operasi' => $row->sk_izin_operasi,
		'tgl_sk_izin_operasi' => $row->tgl_sk_izin_operasi,
		'no_rek' => $row->no_rek,
		'nm_bank' => $row->nm_bank,
		'unit_cabang' => $row->unit_cabang,
		'nm_rek' => $row->nm_rek,
		'a_mbs' => $row->a_mbs,
		'luas_tanah_milik' => $row->luas_tanah_milik,
		'luas_tanah_bukan_milik' => $row->luas_tanah_bukan_milik,
		'a_lptk' => $row->a_lptk,
		'kode_reg' => $row->kode_reg,
		'npwp' => $row->npwp,
		'nm_wp' => $row->nm_wp,
		'flag' => $row->flag,
		'id_pembina' => $row->id_pembina,
		'id_blob' => $row->id_blob,
		'id_stat_milik' => $row->id_stat_milik,
		'id_wil' => $row->id_wil,
		'id_kk' => $row->id_kk,
		'id_bp' => $row->id_bp,
	    );
            $this->template->load('template','satuanpendidikan/satuan_pendidikan_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('satuanpendidikan'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('satuanpendidikan/create_action'),
	    'id_sp' => set_value('id_sp'),
	    'nm_lemb' => set_value('nm_lemb'),
	    'nss' => set_value('nss'),
	    'npsn' => set_value('npsn'),
	    'nm_singkat' => set_value('nm_singkat'),
	    'jln' => set_value('jln'),
	    'rt' => set_value('rt'),
	    'rw' => set_value('rw'),
	    'nm_dsn' => set_value('nm_dsn'),
	    'ds_kel' => set_value('ds_kel'),
	    'kode_pos' => set_value('kode_pos'),
	    'lintang' => set_value('lintang'),
	    'bujur' => set_value('bujur'),
	    'no_tel' => set_value('no_tel'),
	    'no_fax' => set_value('no_fax'),
	    'email' => set_value('email'),
	    'website' => set_value('website'),
	    'stat_sp' => set_value('stat_sp'),
	    'sk_pendirian_sp' => set_value('sk_pendirian_sp'),
	    'tgl_sk_pendirian_sp' => set_value('tgl_sk_pendirian_sp'),
	    'tgl_berdiri' => set_value('tgl_berdiri'),
	    'sk_izin_operasi' => set_value('sk_izin_operasi'),
	    'tgl_sk_izin_operasi' => set_value('tgl_sk_izin_operasi'),
	    'no_rek' => set_value('no_rek'),
	    'nm_bank' => set_value('nm_bank'),
	    'unit_cabang' => set_value('unit_cabang'),
	    'nm_rek' => set_value('nm_rek'),
	    'a_mbs' => set_value('a_mbs'),
	    'luas_tanah_milik' => set_value('luas_tanah_milik'),
	    'luas_tanah_bukan_milik' => set_value('luas_tanah_bukan_milik'),
	    'a_lptk' => set_value('a_lptk'),
	    'kode_reg' => set_value('kode_reg'),
	    'npwp' => set_value('npwp'),
	    'nm_wp' => set_value('nm_wp'),
	    'flag' => set_value('flag'),
	    'id_pembina' => set_value('id_pembina'),
	    'id_blob' => set_value('id_blob'),
	    'id_stat_milik' => set_value('id_stat_milik'),
	    'id_wil' => set_value('id_wil'),
	    'id_kk' => set_value('id_kk'),
	    'id_bp' => set_value('id_bp'),
	);
        $this->template->load('template','satuanpendidikan/satuan_pendidikan_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'nm_lemb' => $this->input->post('nm_lemb',TRUE),
		'nss' => $this->input->post('nss',TRUE),
		'npsn' => $this->input->post('npsn',TRUE),
		'nm_singkat' => $this->input->post('nm_singkat',TRUE),
		'jln' => $this->input->post('jln',TRUE),
		'rt' => $this->input->post('rt',TRUE),
		'rw' => $this->input->post('rw',TRUE),
		'nm_dsn' => $this->input->post('nm_dsn',TRUE),
		'ds_kel' => $this->input->post('ds_kel',TRUE),
		'kode_pos' => $this->input->post('kode_pos',TRUE),
		'lintang' => $this->input->post('lintang',TRUE),
		'bujur' => $this->input->post('bujur',TRUE),
		'no_tel' => $this->input->post('no_tel',TRUE),
		'no_fax' => $this->input->post('no_fax',TRUE),
		'email' => $this->input->post('email',TRUE),
		'website' => $this->input->post('website',TRUE),
		'stat_sp' => $this->input->post('stat_sp',TRUE),
		'sk_pendirian_sp' => $this->input->post('sk_pendirian_sp',TRUE),
		'tgl_sk_pendirian_sp' => $this->input->post('tgl_sk_pendirian_sp',TRUE),
		'tgl_berdiri' => $this->input->post('tgl_berdiri',TRUE),
		'sk_izin_operasi' => $this->input->post('sk_izin_operasi',TRUE),
		'tgl_sk_izin_operasi' => $this->input->post('tgl_sk_izin_operasi',TRUE),
		'no_rek' => $this->input->post('no_rek',TRUE),
		'nm_bank' => $this->input->post('nm_bank',TRUE),
		'unit_cabang' => $this->input->post('unit_cabang',TRUE),
		'nm_rek' => $this->input->post('nm_rek',TRUE),
		'a_mbs' => $this->input->post('a_mbs',TRUE),
		'luas_tanah_milik' => $this->input->post('luas_tanah_milik',TRUE),
		'luas_tanah_bukan_milik' => $this->input->post('luas_tanah_bukan_milik',TRUE),
		'a_lptk' => $this->input->post('a_lptk',TRUE),
		'kode_reg' => $this->input->post('kode_reg',TRUE),
		'npwp' => $this->input->post('npwp',TRUE),
		'nm_wp' => $this->input->post('nm_wp',TRUE),
		'flag' => $this->input->post('flag',TRUE),
		'id_pembina' => $this->input->post('id_pembina',TRUE),
		'id_blob' => $this->input->post('id_blob',TRUE),
		'id_stat_milik' => $this->input->post('id_stat_milik',TRUE),
		'id_wil' => $this->input->post('id_wil',TRUE),
		'id_kk' => $this->input->post('id_kk',TRUE),
		'id_bp' => $this->input->post('id_bp',TRUE),
	    );

            $this->Satuan_pendidikan_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success 2');
            redirect(site_url('satuanpendidikan'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Satuan_pendidikan_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('satuanpendidikan/update_action'),
		'id_sp' => set_value('id_sp', $row->id_sp),
		'nm_lemb' => set_value('nm_lemb', $row->nm_lemb),
		'nss' => set_value('nss', $row->nss),
		'npsn' => set_value('npsn', $row->npsn),
		'nm_singkat' => set_value('nm_singkat', $row->nm_singkat),
		'jln' => set_value('jln', $row->jln),
		'rt' => set_value('rt', $row->rt),
		'rw' => set_value('rw', $row->rw),
		'nm_dsn' => set_value('nm_dsn', $row->nm_dsn),
		'ds_kel' => set_value('ds_kel', $row->ds_kel),
		'kode_pos' => set_value('kode_pos', $row->kode_pos),
		'lintang' => set_value('lintang', $row->lintang),
		'bujur' => set_value('bujur', $row->bujur),
		'no_tel' => set_value('no_tel', $row->no_tel),
		'no_fax' => set_value('no_fax', $row->no_fax),
		'email' => set_value('email', $row->email),
		'website' => set_value('website', $row->website),
		'stat_sp' => set_value('stat_sp', $row->stat_sp),
		'sk_pendirian_sp' => set_value('sk_pendirian_sp', $row->sk_pendirian_sp),
		'tgl_sk_pendirian_sp' => set_value('tgl_sk_pendirian_sp', $row->tgl_sk_pendirian_sp),
		'tgl_berdiri' => set_value('tgl_berdiri', $row->tgl_berdiri),
		'sk_izin_operasi' => set_value('sk_izin_operasi', $row->sk_izin_operasi),
		'tgl_sk_izin_operasi' => set_value('tgl_sk_izin_operasi', $row->tgl_sk_izin_operasi),
		'no_rek' => set_value('no_rek', $row->no_rek),
		'nm_bank' => set_value('nm_bank', $row->nm_bank),
		'unit_cabang' => set_value('unit_cabang', $row->unit_cabang),
		'nm_rek' => set_value('nm_rek', $row->nm_rek),
		'a_mbs' => set_value('a_mbs', $row->a_mbs),
		'luas_tanah_milik' => set_value('luas_tanah_milik', $row->luas_tanah_milik),
		'luas_tanah_bukan_milik' => set_value('luas_tanah_bukan_milik', $row->luas_tanah_bukan_milik),
		'a_lptk' => set_value('a_lptk', $row->a_lptk),
		'kode_reg' => set_value('kode_reg', $row->kode_reg),
		'npwp' => set_value('npwp', $row->npwp),
		'nm_wp' => set_value('nm_wp', $row->nm_wp),
		'flag' => set_value('flag', $row->flag),
		'id_pembina' => set_value('id_pembina', $row->id_pembina),
		'id_blob' => set_value('id_blob', $row->id_blob),
		'id_stat_milik' => set_value('id_stat_milik', $row->id_stat_milik),
		'id_wil' => set_value('id_wil', $row->id_wil),
		'id_kk' => set_value('id_kk', $row->id_kk),
		'id_bp' => set_value('id_bp', $row->id_bp),
	    );
            $this->template->load('template','satuanpendidikan/satuan_pendidikan_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('satuanpendidikan'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_sp', TRUE));
        } else {
            $data = array(
		'nm_lemb' => $this->input->post('nm_lemb',TRUE),
		'nss' => $this->input->post('nss',TRUE),
		'npsn' => $this->input->post('npsn',TRUE),
		'nm_singkat' => $this->input->post('nm_singkat',TRUE),
		'jln' => $this->input->post('jln',TRUE),
		'rt' => $this->input->post('rt',TRUE),
		'rw' => $this->input->post('rw',TRUE),
		'nm_dsn' => $this->input->post('nm_dsn',TRUE),
		'ds_kel' => $this->input->post('ds_kel',TRUE),
		'kode_pos' => $this->input->post('kode_pos',TRUE),
		'lintang' => $this->input->post('lintang',TRUE),
		'bujur' => $this->input->post('bujur',TRUE),
		'no_tel' => $this->input->post('no_tel',TRUE),
		'no_fax' => $this->input->post('no_fax',TRUE),
		'email' => $this->input->post('email',TRUE),
		'website' => $this->input->post('website',TRUE),
		'stat_sp' => $this->input->post('stat_sp',TRUE),
		'sk_pendirian_sp' => $this->input->post('sk_pendirian_sp',TRUE),
		'tgl_sk_pendirian_sp' => $this->input->post('tgl_sk_pendirian_sp',TRUE),
		'tgl_berdiri' => $this->input->post('tgl_berdiri',TRUE),
		'sk_izin_operasi' => $this->input->post('sk_izin_operasi',TRUE),
		'tgl_sk_izin_operasi' => $this->input->post('tgl_sk_izin_operasi',TRUE),
		'no_rek' => $this->input->post('no_rek',TRUE),
		'nm_bank' => $this->input->post('nm_bank',TRUE),
		'unit_cabang' => $this->input->post('unit_cabang',TRUE),
		'nm_rek' => $this->input->post('nm_rek',TRUE),
		'a_mbs' => $this->input->post('a_mbs',TRUE),
		'luas_tanah_milik' => $this->input->post('luas_tanah_milik',TRUE),
		'luas_tanah_bukan_milik' => $this->input->post('luas_tanah_bukan_milik',TRUE),
		'a_lptk' => $this->input->post('a_lptk',TRUE),
		'kode_reg' => $this->input->post('kode_reg',TRUE),
		'npwp' => $this->input->post('npwp',TRUE),
		'nm_wp' => $this->input->post('nm_wp',TRUE),
		'flag' => $this->input->post('flag',TRUE),
		'id_pembina' => $this->input->post('id_pembina',TRUE),
		'id_blob' => $this->input->post('id_blob',TRUE),
		'id_stat_milik' => $this->input->post('id_stat_milik',TRUE),
		'id_wil' => $this->input->post('id_wil',TRUE),
		'id_kk' => $this->input->post('id_kk',TRUE),
		'id_bp' => $this->input->post('id_bp',TRUE),
	    );

            $this->Satuan_pendidikan_model->update($this->input->post('id_sp', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('satuanpendidikan'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Satuan_pendidikan_model->get_by_id($id);

        if ($row) {
            $this->Satuan_pendidikan_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('satuanpendidikan'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('satuanpendidikan'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('nm_lemb', 'nm lemb', 'trim|required');
	$this->form_validation->set_rules('nss', 'nss', 'trim|required');
	$this->form_validation->set_rules('npsn', 'npsn', 'trim|required');
	$this->form_validation->set_rules('nm_singkat', 'nm singkat', 'trim|required');
	$this->form_validation->set_rules('jln', 'jln', 'trim|required');
	$this->form_validation->set_rules('rt', 'rt', 'trim|required|numeric');
	$this->form_validation->set_rules('rw', 'rw', 'trim|required|numeric');
	$this->form_validation->set_rules('nm_dsn', 'nm dsn', 'trim|required');
	$this->form_validation->set_rules('ds_kel', 'ds kel', 'trim|required');
	$this->form_validation->set_rules('kode_pos', 'kode pos', 'trim|required');
	$this->form_validation->set_rules('lintang', 'lintang', 'trim|required|numeric');
	$this->form_validation->set_rules('bujur', 'bujur', 'trim|required|numeric');
	$this->form_validation->set_rules('no_tel', 'no tel', 'trim|required');
	$this->form_validation->set_rules('no_fax', 'no fax', 'trim|required');
	$this->form_validation->set_rules('email', 'email', 'trim|required');
	$this->form_validation->set_rules('website', 'website', 'trim|required');
	$this->form_validation->set_rules('stat_sp', 'stat sp', 'trim|required');
	$this->form_validation->set_rules('sk_pendirian_sp', 'sk pendirian sp', 'trim|required');
	$this->form_validation->set_rules('tgl_sk_pendirian_sp', 'tgl sk pendirian sp', 'trim|required');
	$this->form_validation->set_rules('tgl_berdiri', 'tgl berdiri', 'trim|required');
	$this->form_validation->set_rules('sk_izin_operasi', 'sk izin operasi', 'trim|required');
	$this->form_validation->set_rules('tgl_sk_izin_operasi', 'tgl sk izin operasi', 'trim|required');
	$this->form_validation->set_rules('no_rek', 'no rek', 'trim|required');
	$this->form_validation->set_rules('nm_bank', 'nm bank', 'trim|required');
	$this->form_validation->set_rules('unit_cabang', 'unit cabang', 'trim|required');
	$this->form_validation->set_rules('nm_rek', 'nm rek', 'trim|required');
	$this->form_validation->set_rules('a_mbs', 'a mbs', 'trim|required|numeric');
	$this->form_validation->set_rules('luas_tanah_milik', 'luas tanah milik', 'trim|required|numeric');
	$this->form_validation->set_rules('luas_tanah_bukan_milik', 'luas tanah bukan milik', 'trim|required|numeric');
	$this->form_validation->set_rules('a_lptk', 'a lptk', 'trim|required|numeric');
	$this->form_validation->set_rules('kode_reg', 'kode reg', 'trim|required');
	$this->form_validation->set_rules('npwp', 'npwp', 'trim|required');
	$this->form_validation->set_rules('nm_wp', 'nm wp', 'trim|required');
	$this->form_validation->set_rules('flag', 'flag', 'trim|required');
	$this->form_validation->set_rules('id_pembina', 'id pembina', 'trim|required');
	$this->form_validation->set_rules('id_blob', 'id blob', 'trim|required');
	$this->form_validation->set_rules('id_stat_milik', 'id stat milik', 'trim|required|numeric');
	$this->form_validation->set_rules('id_wil', 'id wil', 'trim|required');
	$this->form_validation->set_rules('id_kk', 'id kk', 'trim|required');
	$this->form_validation->set_rules('id_bp', 'id bp', 'trim|required');

	$this->form_validation->set_rules('id_sp', 'id_sp', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "satuan_pendidikan.xls";
        $judul = "satuan_pendidikan";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Lemb");
	xlsWriteLabel($tablehead, $kolomhead++, "Nss");
	xlsWriteLabel($tablehead, $kolomhead++, "Npsn");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Singkat");
	xlsWriteLabel($tablehead, $kolomhead++, "Jln");
	xlsWriteLabel($tablehead, $kolomhead++, "Rt");
	xlsWriteLabel($tablehead, $kolomhead++, "Rw");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Dsn");
	xlsWriteLabel($tablehead, $kolomhead++, "Ds Kel");
	xlsWriteLabel($tablehead, $kolomhead++, "Kode Pos");
	xlsWriteLabel($tablehead, $kolomhead++, "Lintang");
	xlsWriteLabel($tablehead, $kolomhead++, "Bujur");
	xlsWriteLabel($tablehead, $kolomhead++, "No Tel");
	xlsWriteLabel($tablehead, $kolomhead++, "No Fax");
	xlsWriteLabel($tablehead, $kolomhead++, "Email");
	xlsWriteLabel($tablehead, $kolomhead++, "Website");
	xlsWriteLabel($tablehead, $kolomhead++, "Stat Sp");
	xlsWriteLabel($tablehead, $kolomhead++, "Sk Pendirian Sp");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Sk Pendirian Sp");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Berdiri");
	xlsWriteLabel($tablehead, $kolomhead++, "Sk Izin Operasi");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Sk Izin Operasi");
	xlsWriteLabel($tablehead, $kolomhead++, "No Rek");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Bank");
	xlsWriteLabel($tablehead, $kolomhead++, "Unit Cabang");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Rek");
	xlsWriteLabel($tablehead, $kolomhead++, "A Mbs");
	xlsWriteLabel($tablehead, $kolomhead++, "Luas Tanah Milik");
	xlsWriteLabel($tablehead, $kolomhead++, "Luas Tanah Bukan Milik");
	xlsWriteLabel($tablehead, $kolomhead++, "A Lptk");
	xlsWriteLabel($tablehead, $kolomhead++, "Kode Reg");
	xlsWriteLabel($tablehead, $kolomhead++, "Npwp");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Wp");
	xlsWriteLabel($tablehead, $kolomhead++, "Flag");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Pembina");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Blob");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Stat Milik");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Wil");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Kk");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Bp");

	foreach ($this->Satuan_pendidikan_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_lemb);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nss);
	    xlsWriteLabel($tablebody, $kolombody++, $data->npsn);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_singkat);
	    xlsWriteLabel($tablebody, $kolombody++, $data->jln);
	    xlsWriteNumber($tablebody, $kolombody++, $data->rt);
	    xlsWriteNumber($tablebody, $kolombody++, $data->rw);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_dsn);
	    xlsWriteLabel($tablebody, $kolombody++, $data->ds_kel);
	    xlsWriteLabel($tablebody, $kolombody++, $data->kode_pos);
	    xlsWriteNumber($tablebody, $kolombody++, $data->lintang);
	    xlsWriteNumber($tablebody, $kolombody++, $data->bujur);
	    xlsWriteLabel($tablebody, $kolombody++, $data->no_tel);
	    xlsWriteLabel($tablebody, $kolombody++, $data->no_fax);
	    xlsWriteLabel($tablebody, $kolombody++, $data->email);
	    xlsWriteLabel($tablebody, $kolombody++, $data->website);
	    xlsWriteLabel($tablebody, $kolombody++, $data->stat_sp);
	    xlsWriteLabel($tablebody, $kolombody++, $data->sk_pendirian_sp);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_sk_pendirian_sp);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_berdiri);
	    xlsWriteLabel($tablebody, $kolombody++, $data->sk_izin_operasi);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_sk_izin_operasi);
	    xlsWriteLabel($tablebody, $kolombody++, $data->no_rek);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_bank);
	    xlsWriteLabel($tablebody, $kolombody++, $data->unit_cabang);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_rek);
	    xlsWriteNumber($tablebody, $kolombody++, $data->a_mbs);
	    xlsWriteNumber($tablebody, $kolombody++, $data->luas_tanah_milik);
	    xlsWriteNumber($tablebody, $kolombody++, $data->luas_tanah_bukan_milik);
	    xlsWriteNumber($tablebody, $kolombody++, $data->a_lptk);
	    xlsWriteLabel($tablebody, $kolombody++, $data->kode_reg);
	    xlsWriteLabel($tablebody, $kolombody++, $data->npwp);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_wp);
	    xlsWriteLabel($tablebody, $kolombody++, $data->flag);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_pembina);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_blob);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_stat_milik);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_wil);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_kk);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_bp);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=satuan_pendidikan.doc");

        $data = array(
            'satuan_pendidikan_data' => $this->Satuan_pendidikan_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('satuanpendidikan/satuan_pendidikan_doc',$data);
    }

}

/* End of file Satuanpendidikan.php */
/* Location: ./application/controllers/Satuanpendidikan.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-22 23:58:03 */
/* http://harviacode.com */