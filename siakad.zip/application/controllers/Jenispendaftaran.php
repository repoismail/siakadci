<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Jenispendaftaran extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        is_login();
        $this->load->model('Jenis_pendaftaran_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->template->load('template','jenispendaftaran/jenis_pendaftaran_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Jenis_pendaftaran_model->json();
    }

    public function read($id) 
    {
        $row = $this->Jenis_pendaftaran_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_jns_daftar' => $row->id_jns_daftar,
		'nm_jns_daftar' => $row->nm_jns_daftar,
		'u_daftar_sekolah' => $row->u_daftar_sekolah,
		'u_daftar_rombel' => $row->u_daftar_rombel,
	    );
            $this->template->load('template','jenispendaftaran/jenis_pendaftaran_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('jenispendaftaran'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('jenispendaftaran/create_action'),
	    'id_jns_daftar' => set_value('id_jns_daftar'),
	    'nm_jns_daftar' => set_value('nm_jns_daftar'),
	    'u_daftar_sekolah' => set_value('u_daftar_sekolah'),
	    'u_daftar_rombel' => set_value('u_daftar_rombel'),
	);
        $this->template->load('template','jenispendaftaran/jenis_pendaftaran_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'nm_jns_daftar' => $this->input->post('nm_jns_daftar',TRUE),
		'u_daftar_sekolah' => $this->input->post('u_daftar_sekolah',TRUE),
		'u_daftar_rombel' => $this->input->post('u_daftar_rombel',TRUE),
	    );

            $this->Jenis_pendaftaran_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success 2');
            redirect(site_url('jenispendaftaran'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Jenis_pendaftaran_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('jenispendaftaran/update_action'),
		'id_jns_daftar' => set_value('id_jns_daftar', $row->id_jns_daftar),
		'nm_jns_daftar' => set_value('nm_jns_daftar', $row->nm_jns_daftar),
		'u_daftar_sekolah' => set_value('u_daftar_sekolah', $row->u_daftar_sekolah),
		'u_daftar_rombel' => set_value('u_daftar_rombel', $row->u_daftar_rombel),
	    );
            $this->template->load('template','jenispendaftaran/jenis_pendaftaran_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('jenispendaftaran'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_jns_daftar', TRUE));
        } else {
            $data = array(
		'nm_jns_daftar' => $this->input->post('nm_jns_daftar',TRUE),
		'u_daftar_sekolah' => $this->input->post('u_daftar_sekolah',TRUE),
		'u_daftar_rombel' => $this->input->post('u_daftar_rombel',TRUE),
	    );

            $this->Jenis_pendaftaran_model->update($this->input->post('id_jns_daftar', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('jenispendaftaran'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Jenis_pendaftaran_model->get_by_id($id);

        if ($row) {
            $this->Jenis_pendaftaran_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('jenispendaftaran'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('jenispendaftaran'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('nm_jns_daftar', 'nm jns daftar', 'trim|required');
	$this->form_validation->set_rules('u_daftar_sekolah', 'u daftar sekolah', 'trim|required');
	$this->form_validation->set_rules('u_daftar_rombel', 'u daftar rombel', 'trim|required');

	$this->form_validation->set_rules('id_jns_daftar', 'id_jns_daftar', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "jenis_pendaftaran.xls";
        $judul = "jenis_pendaftaran";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Jns Daftar");
	xlsWriteLabel($tablehead, $kolomhead++, "U Daftar Sekolah");
	xlsWriteLabel($tablehead, $kolomhead++, "U Daftar Rombel");

	foreach ($this->Jenis_pendaftaran_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_jns_daftar);
	    xlsWriteNumber($tablebody, $kolombody++, $data->u_daftar_sekolah);
	    xlsWriteNumber($tablebody, $kolombody++, $data->u_daftar_rombel);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=jenis_pendaftaran.doc");

        $data = array(
            'jenis_pendaftaran_data' => $this->Jenis_pendaftaran_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('jenispendaftaran/jenis_pendaftaran_doc',$data);
    }

}

/* End of file Jenispendaftaran.php */
/* Location: ./application/controllers/Jenispendaftaran.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-22 23:49:39 */
/* http://harviacode.com */