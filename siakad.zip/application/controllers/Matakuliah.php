<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Matakuliah extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        is_login();
        $this->load->model('Mata_kuliah_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->template->load('template','matakuliah/mata_kuliah_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Mata_kuliah_model->json();
    }

    public function read($id) 
    {
        $row = $this->Mata_kuliah_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_mk' => $row->id_mk,
		'id_sms' => $row->id_sms,
		'id_jenj_didik' => $row->id_jenj_didik,
		'kode_mk' => $row->kode_mk,
		'nm_mk' => $row->nm_mk,
		'jns_mk' => $row->jns_mk,
		'kel_mk' => $row->kel_mk,
		'sks_mk' => $row->sks_mk,
		'sks_tm' => $row->sks_tm,
		'sks_prak' => $row->sks_prak,
		'sks_prak_lap' => $row->sks_prak_lap,
		'sks_sim' => $row->sks_sim,
		'metode_pelaksanaan_kuliah' => $row->metode_pelaksanaan_kuliah,
		'a_sap' => $row->a_sap,
		'a_silabus' => $row->a_silabus,
		'a_bahan_ajar' => $row->a_bahan_ajar,
		'acara_prak' => $row->acara_prak,
		'a_diktat' => $row->a_diktat,
		'tgl_mulai_efektif' => $row->tgl_mulai_efektif,
		'tgl_akhir_efektif' => $row->tgl_akhir_efektif,
	    );
            $this->template->load('template','matakuliah/mata_kuliah_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('matakuliah'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('matakuliah/create_action'),
	    'id_mk' => set_value('id_mk'),
	    'id_sms' => set_value('id_sms'),
	    'id_jenj_didik' => set_value('id_jenj_didik'),
	    'kode_mk' => set_value('kode_mk'),
	    'nm_mk' => set_value('nm_mk'),
	    'jns_mk' => set_value('jns_mk'),
	    'kel_mk' => set_value('kel_mk'),
	    'sks_mk' => set_value('sks_mk'),
	    'sks_tm' => set_value('sks_tm'),
	    'sks_prak' => set_value('sks_prak'),
	    'sks_prak_lap' => set_value('sks_prak_lap'),
	    'sks_sim' => set_value('sks_sim'),
	    'metode_pelaksanaan_kuliah' => set_value('metode_pelaksanaan_kuliah'),
	    'a_sap' => set_value('a_sap'),
	    'a_silabus' => set_value('a_silabus'),
	    'a_bahan_ajar' => set_value('a_bahan_ajar'),
	    'acara_prak' => set_value('acara_prak'),
	    'a_diktat' => set_value('a_diktat'),
	    'tgl_mulai_efektif' => set_value('tgl_mulai_efektif'),
	    'tgl_akhir_efektif' => set_value('tgl_akhir_efektif'),
	);
        $this->template->load('template','matakuliah/mata_kuliah_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'id_sms' => $this->input->post('id_sms',TRUE),
		'id_jenj_didik' => $this->input->post('id_jenj_didik',TRUE),
		'kode_mk' => $this->input->post('kode_mk',TRUE),
		'nm_mk' => $this->input->post('nm_mk',TRUE),
		'jns_mk' => $this->input->post('jns_mk',TRUE),
		'kel_mk' => $this->input->post('kel_mk',TRUE),
		'sks_mk' => $this->input->post('sks_mk',TRUE),
		'sks_tm' => $this->input->post('sks_tm',TRUE),
		'sks_prak' => $this->input->post('sks_prak',TRUE),
		'sks_prak_lap' => $this->input->post('sks_prak_lap',TRUE),
		'sks_sim' => $this->input->post('sks_sim',TRUE),
		'metode_pelaksanaan_kuliah' => $this->input->post('metode_pelaksanaan_kuliah',TRUE),
		'a_sap' => $this->input->post('a_sap',TRUE),
		'a_silabus' => $this->input->post('a_silabus',TRUE),
		'a_bahan_ajar' => $this->input->post('a_bahan_ajar',TRUE),
		'acara_prak' => $this->input->post('acara_prak',TRUE),
		'a_diktat' => $this->input->post('a_diktat',TRUE),
		'tgl_mulai_efektif' => $this->input->post('tgl_mulai_efektif',TRUE),
		'tgl_akhir_efektif' => $this->input->post('tgl_akhir_efektif',TRUE),
	    );

            $this->Mata_kuliah_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success 2');
            redirect(site_url('matakuliah'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Mata_kuliah_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('matakuliah/update_action'),
		'id_mk' => set_value('id_mk', $row->id_mk),
		'id_sms' => set_value('id_sms', $row->id_sms),
		'id_jenj_didik' => set_value('id_jenj_didik', $row->id_jenj_didik),
		'kode_mk' => set_value('kode_mk', $row->kode_mk),
		'nm_mk' => set_value('nm_mk', $row->nm_mk),
		'jns_mk' => set_value('jns_mk', $row->jns_mk),
		'kel_mk' => set_value('kel_mk', $row->kel_mk),
		'sks_mk' => set_value('sks_mk', $row->sks_mk),
		'sks_tm' => set_value('sks_tm', $row->sks_tm),
		'sks_prak' => set_value('sks_prak', $row->sks_prak),
		'sks_prak_lap' => set_value('sks_prak_lap', $row->sks_prak_lap),
		'sks_sim' => set_value('sks_sim', $row->sks_sim),
		'metode_pelaksanaan_kuliah' => set_value('metode_pelaksanaan_kuliah', $row->metode_pelaksanaan_kuliah),
		'a_sap' => set_value('a_sap', $row->a_sap),
		'a_silabus' => set_value('a_silabus', $row->a_silabus),
		'a_bahan_ajar' => set_value('a_bahan_ajar', $row->a_bahan_ajar),
		'acara_prak' => set_value('acara_prak', $row->acara_prak),
		'a_diktat' => set_value('a_diktat', $row->a_diktat),
		'tgl_mulai_efektif' => set_value('tgl_mulai_efektif', $row->tgl_mulai_efektif),
		'tgl_akhir_efektif' => set_value('tgl_akhir_efektif', $row->tgl_akhir_efektif),
	    );
            $this->template->load('template','matakuliah/mata_kuliah_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('matakuliah'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_mk', TRUE));
        } else {
            $data = array(
		'id_sms' => $this->input->post('id_sms',TRUE),
		'id_jenj_didik' => $this->input->post('id_jenj_didik',TRUE),
		'kode_mk' => $this->input->post('kode_mk',TRUE),
		'nm_mk' => $this->input->post('nm_mk',TRUE),
		'jns_mk' => $this->input->post('jns_mk',TRUE),
		'kel_mk' => $this->input->post('kel_mk',TRUE),
		'sks_mk' => $this->input->post('sks_mk',TRUE),
		'sks_tm' => $this->input->post('sks_tm',TRUE),
		'sks_prak' => $this->input->post('sks_prak',TRUE),
		'sks_prak_lap' => $this->input->post('sks_prak_lap',TRUE),
		'sks_sim' => $this->input->post('sks_sim',TRUE),
		'metode_pelaksanaan_kuliah' => $this->input->post('metode_pelaksanaan_kuliah',TRUE),
		'a_sap' => $this->input->post('a_sap',TRUE),
		'a_silabus' => $this->input->post('a_silabus',TRUE),
		'a_bahan_ajar' => $this->input->post('a_bahan_ajar',TRUE),
		'acara_prak' => $this->input->post('acara_prak',TRUE),
		'a_diktat' => $this->input->post('a_diktat',TRUE),
		'tgl_mulai_efektif' => $this->input->post('tgl_mulai_efektif',TRUE),
		'tgl_akhir_efektif' => $this->input->post('tgl_akhir_efektif',TRUE),
	    );

            $this->Mata_kuliah_model->update($this->input->post('id_mk', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('matakuliah'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Mata_kuliah_model->get_by_id($id);

        if ($row) {
            $this->Mata_kuliah_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('matakuliah'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('matakuliah'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_sms', 'id sms', 'trim|required');
	$this->form_validation->set_rules('id_jenj_didik', 'id jenj didik', 'trim|required|numeric');
	$this->form_validation->set_rules('kode_mk', 'kode mk', 'trim|required');
	$this->form_validation->set_rules('nm_mk', 'nm mk', 'trim|required');
	$this->form_validation->set_rules('jns_mk', 'jns mk', 'trim|required');
	$this->form_validation->set_rules('kel_mk', 'kel mk', 'trim|required');
	$this->form_validation->set_rules('sks_mk', 'sks mk', 'trim|required|numeric');
	$this->form_validation->set_rules('sks_tm', 'sks tm', 'trim|required|numeric');
	$this->form_validation->set_rules('sks_prak', 'sks prak', 'trim|required|numeric');
	$this->form_validation->set_rules('sks_prak_lap', 'sks prak lap', 'trim|required|numeric');
	$this->form_validation->set_rules('sks_sim', 'sks sim', 'trim|required|numeric');
	$this->form_validation->set_rules('metode_pelaksanaan_kuliah', 'metode pelaksanaan kuliah', 'trim|required');
	$this->form_validation->set_rules('a_sap', 'a sap', 'trim|required|numeric');
	$this->form_validation->set_rules('a_silabus', 'a silabus', 'trim|required|numeric');
	$this->form_validation->set_rules('a_bahan_ajar', 'a bahan ajar', 'trim|required|numeric');
	$this->form_validation->set_rules('acara_prak', 'acara prak', 'trim|required|numeric');
	$this->form_validation->set_rules('a_diktat', 'a diktat', 'trim|required|numeric');
	$this->form_validation->set_rules('tgl_mulai_efektif', 'tgl mulai efektif', 'trim|required');
	$this->form_validation->set_rules('tgl_akhir_efektif', 'tgl akhir efektif', 'trim|required');

	$this->form_validation->set_rules('id_mk', 'id_mk', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "mata_kuliah.xls";
        $judul = "mata_kuliah";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Sms");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Jenj Didik");
	xlsWriteLabel($tablehead, $kolomhead++, "Kode Mk");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Mk");
	xlsWriteLabel($tablehead, $kolomhead++, "Jns Mk");
	xlsWriteLabel($tablehead, $kolomhead++, "Kel Mk");
	xlsWriteLabel($tablehead, $kolomhead++, "Sks Mk");
	xlsWriteLabel($tablehead, $kolomhead++, "Sks Tm");
	xlsWriteLabel($tablehead, $kolomhead++, "Sks Prak");
	xlsWriteLabel($tablehead, $kolomhead++, "Sks Prak Lap");
	xlsWriteLabel($tablehead, $kolomhead++, "Sks Sim");
	xlsWriteLabel($tablehead, $kolomhead++, "Metode Pelaksanaan Kuliah");
	xlsWriteLabel($tablehead, $kolomhead++, "A Sap");
	xlsWriteLabel($tablehead, $kolomhead++, "A Silabus");
	xlsWriteLabel($tablehead, $kolomhead++, "A Bahan Ajar");
	xlsWriteLabel($tablehead, $kolomhead++, "Acara Prak");
	xlsWriteLabel($tablehead, $kolomhead++, "A Diktat");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Mulai Efektif");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Akhir Efektif");

	foreach ($this->Mata_kuliah_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_sms);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_jenj_didik);
	    xlsWriteLabel($tablebody, $kolombody++, $data->kode_mk);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_mk);
	    xlsWriteLabel($tablebody, $kolombody++, $data->jns_mk);
	    xlsWriteLabel($tablebody, $kolombody++, $data->kel_mk);
	    xlsWriteNumber($tablebody, $kolombody++, $data->sks_mk);
	    xlsWriteNumber($tablebody, $kolombody++, $data->sks_tm);
	    xlsWriteNumber($tablebody, $kolombody++, $data->sks_prak);
	    xlsWriteNumber($tablebody, $kolombody++, $data->sks_prak_lap);
	    xlsWriteNumber($tablebody, $kolombody++, $data->sks_sim);
	    xlsWriteLabel($tablebody, $kolombody++, $data->metode_pelaksanaan_kuliah);
	    xlsWriteNumber($tablebody, $kolombody++, $data->a_sap);
	    xlsWriteNumber($tablebody, $kolombody++, $data->a_silabus);
	    xlsWriteNumber($tablebody, $kolombody++, $data->a_bahan_ajar);
	    xlsWriteNumber($tablebody, $kolombody++, $data->acara_prak);
	    xlsWriteNumber($tablebody, $kolombody++, $data->a_diktat);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_mulai_efektif);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_akhir_efektif);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=mata_kuliah.doc");

        $data = array(
            'mata_kuliah_data' => $this->Mata_kuliah_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('matakuliah/mata_kuliah_doc',$data);
    }

}

/* End of file Matakuliah.php */
/* Location: ./application/controllers/Matakuliah.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-23 00:02:12 */
/* http://harviacode.com */