<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Dosen extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        is_login();
        $this->load->model('Dosen_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->template->load('template','dosen/dosen_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Dosen_model->json();
    }

    public function read($id) 
    {
        $row = $this->Dosen_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_sdm' => $row->id_sdm,
		'nm_sdm' => $row->nm_sdm,
		'jk' => $row->jk,
		'tmpt_lahir' => $row->tmpt_lahir,
		'tgl_lahir' => $row->tgl_lahir,
		'nm_ibu_kandung' => $row->nm_ibu_kandung,
		'stat_kawin' => $row->stat_kawin,
		'nik' => $row->nik,
		'nip' => $row->nip,
		'niy_nigk' => $row->niy_nigk,
		'nuptk' => $row->nuptk,
		'nidn' => $row->nidn,
		'nsdmi' => $row->nsdmi,
		'jln' => $row->jln,
		'rt' => $row->rt,
		'rw' => $row->rw,
		'nm_dsn' => $row->nm_dsn,
		'ds_kel' => $row->ds_kel,
		'kode_pos' => $row->kode_pos,
		'no_tel_rmh' => $row->no_tel_rmh,
		'no_hp' => $row->no_hp,
		'email' => $row->email,
		'tmt_pns' => $row->tmt_pns,
		'nm_suami_istri' => $row->nm_suami_istri,
		'nip_suami_istri' => $row->nip_suami_istri,
		'sk_cpns' => $row->sk_cpns,
		'tgl_sk_cpns' => $row->tgl_sk_cpns,
		'sk_angkat' => $row->sk_angkat,
		'tmt_sk_angkat' => $row->tmt_sk_angkat,
		'npwp' => $row->npwp,
		'nm_wp' => $row->nm_wp,
		'stat_data' => $row->stat_data,
		'a_lisensi_kepsek' => $row->a_lisensi_kepsek,
		'a_braille' => $row->a_braille,
		'a_bhs_isyarat' => $row->a_bhs_isyarat,
		'jml_sekolah_binaan' => $row->jml_sekolah_binaan,
		'a_diklat_awas' => $row->a_diklat_awas,
		'akta_ijin_ajar' => $row->akta_ijin_ajar,
		'nira' => $row->nira,
		'kewarganegaraan' => $row->kewarganegaraan,
		'id_jns_sdm' => $row->id_jns_sdm,
		'id_wil' => $row->id_wil,
		'id_stat_aktif' => $row->id_stat_aktif,
		'id_blob' => $row->id_blob,
		'id_agama' => $row->id_agama,
		'id_keahlian_lab' => $row->id_keahlian_lab,
		'id_pekerjaan_suami_istri' => $row->id_pekerjaan_suami_istri,
		'id_sumber_gaji' => $row->id_sumber_gaji,
		'id_lemb_angkat' => $row->id_lemb_angkat,
		'id_pangkat_gol' => $row->id_pangkat_gol,
		'mampu_handle_kk' => $row->mampu_handle_kk,
		'id_bid_pengawas' => $row->id_bid_pengawas,
	    );
            $this->template->load('template','dosen/dosen_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('dosen'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('dosen/create_action'),
	    'id_sdm' => set_value('id_sdm'),
	    'nm_sdm' => set_value('nm_sdm'),
	    'jk' => set_value('jk'),
	    'tmpt_lahir' => set_value('tmpt_lahir'),
	    'tgl_lahir' => set_value('tgl_lahir'),
	    'nm_ibu_kandung' => set_value('nm_ibu_kandung'),
	    'stat_kawin' => set_value('stat_kawin'),
	    'nik' => set_value('nik'),
	    'nip' => set_value('nip'),
	    'niy_nigk' => set_value('niy_nigk'),
	    'nuptk' => set_value('nuptk'),
	    'nidn' => set_value('nidn'),
	    'nsdmi' => set_value('nsdmi'),
	    'jln' => set_value('jln'),
	    'rt' => set_value('rt'),
	    'rw' => set_value('rw'),
	    'nm_dsn' => set_value('nm_dsn'),
	    'ds_kel' => set_value('ds_kel'),
	    'kode_pos' => set_value('kode_pos'),
	    'no_tel_rmh' => set_value('no_tel_rmh'),
	    'no_hp' => set_value('no_hp'),
	    'email' => set_value('email'),
	    'tmt_pns' => set_value('tmt_pns'),
	    'nm_suami_istri' => set_value('nm_suami_istri'),
	    'nip_suami_istri' => set_value('nip_suami_istri'),
	    'sk_cpns' => set_value('sk_cpns'),
	    'tgl_sk_cpns' => set_value('tgl_sk_cpns'),
	    'sk_angkat' => set_value('sk_angkat'),
	    'tmt_sk_angkat' => set_value('tmt_sk_angkat'),
	    'npwp' => set_value('npwp'),
	    'nm_wp' => set_value('nm_wp'),
	    'stat_data' => set_value('stat_data'),
	    'a_lisensi_kepsek' => set_value('a_lisensi_kepsek'),
	    'a_braille' => set_value('a_braille'),
	    'a_bhs_isyarat' => set_value('a_bhs_isyarat'),
	    'jml_sekolah_binaan' => set_value('jml_sekolah_binaan'),
	    'a_diklat_awas' => set_value('a_diklat_awas'),
	    'akta_ijin_ajar' => set_value('akta_ijin_ajar'),
	    'nira' => set_value('nira'),
	    'kewarganegaraan' => set_value('kewarganegaraan'),
	    'id_jns_sdm' => set_value('id_jns_sdm'),
	    'id_wil' => set_value('id_wil'),
	    'id_stat_aktif' => set_value('id_stat_aktif'),
	    'id_blob' => set_value('id_blob'),
	    'id_agama' => set_value('id_agama'),
	    'id_keahlian_lab' => set_value('id_keahlian_lab'),
	    'id_pekerjaan_suami_istri' => set_value('id_pekerjaan_suami_istri'),
	    'id_sumber_gaji' => set_value('id_sumber_gaji'),
	    'id_lemb_angkat' => set_value('id_lemb_angkat'),
	    'id_pangkat_gol' => set_value('id_pangkat_gol'),
	    'mampu_handle_kk' => set_value('mampu_handle_kk'),
	    'id_bid_pengawas' => set_value('id_bid_pengawas'),
	);
        $this->template->load('template','dosen/dosen_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'nm_sdm' => $this->input->post('nm_sdm',TRUE),
		'jk' => $this->input->post('jk',TRUE),
		'tmpt_lahir' => $this->input->post('tmpt_lahir',TRUE),
		'tgl_lahir' => $this->input->post('tgl_lahir',TRUE),
		'nm_ibu_kandung' => $this->input->post('nm_ibu_kandung',TRUE),
		'stat_kawin' => $this->input->post('stat_kawin',TRUE),
		'nik' => $this->input->post('nik',TRUE),
		'nip' => $this->input->post('nip',TRUE),
		'niy_nigk' => $this->input->post('niy_nigk',TRUE),
		'nuptk' => $this->input->post('nuptk',TRUE),
		'nidn' => $this->input->post('nidn',TRUE),
		'nsdmi' => $this->input->post('nsdmi',TRUE),
		'jln' => $this->input->post('jln',TRUE),
		'rt' => $this->input->post('rt',TRUE),
		'rw' => $this->input->post('rw',TRUE),
		'nm_dsn' => $this->input->post('nm_dsn',TRUE),
		'ds_kel' => $this->input->post('ds_kel',TRUE),
		'kode_pos' => $this->input->post('kode_pos',TRUE),
		'no_tel_rmh' => $this->input->post('no_tel_rmh',TRUE),
		'no_hp' => $this->input->post('no_hp',TRUE),
		'email' => $this->input->post('email',TRUE),
		'tmt_pns' => $this->input->post('tmt_pns',TRUE),
		'nm_suami_istri' => $this->input->post('nm_suami_istri',TRUE),
		'nip_suami_istri' => $this->input->post('nip_suami_istri',TRUE),
		'sk_cpns' => $this->input->post('sk_cpns',TRUE),
		'tgl_sk_cpns' => $this->input->post('tgl_sk_cpns',TRUE),
		'sk_angkat' => $this->input->post('sk_angkat',TRUE),
		'tmt_sk_angkat' => $this->input->post('tmt_sk_angkat',TRUE),
		'npwp' => $this->input->post('npwp',TRUE),
		'nm_wp' => $this->input->post('nm_wp',TRUE),
		'stat_data' => $this->input->post('stat_data',TRUE),
		'a_lisensi_kepsek' => $this->input->post('a_lisensi_kepsek',TRUE),
		'a_braille' => $this->input->post('a_braille',TRUE),
		'a_bhs_isyarat' => $this->input->post('a_bhs_isyarat',TRUE),
		'jml_sekolah_binaan' => $this->input->post('jml_sekolah_binaan',TRUE),
		'a_diklat_awas' => $this->input->post('a_diklat_awas',TRUE),
		'akta_ijin_ajar' => $this->input->post('akta_ijin_ajar',TRUE),
		'nira' => $this->input->post('nira',TRUE),
		'kewarganegaraan' => $this->input->post('kewarganegaraan',TRUE),
		'id_jns_sdm' => $this->input->post('id_jns_sdm',TRUE),
		'id_wil' => $this->input->post('id_wil',TRUE),
		'id_stat_aktif' => $this->input->post('id_stat_aktif',TRUE),
		'id_blob' => $this->input->post('id_blob',TRUE),
		'id_agama' => $this->input->post('id_agama',TRUE),
		'id_keahlian_lab' => $this->input->post('id_keahlian_lab',TRUE),
		'id_pekerjaan_suami_istri' => $this->input->post('id_pekerjaan_suami_istri',TRUE),
		'id_sumber_gaji' => $this->input->post('id_sumber_gaji',TRUE),
		'id_lemb_angkat' => $this->input->post('id_lemb_angkat',TRUE),
		'id_pangkat_gol' => $this->input->post('id_pangkat_gol',TRUE),
		'mampu_handle_kk' => $this->input->post('mampu_handle_kk',TRUE),
		'id_bid_pengawas' => $this->input->post('id_bid_pengawas',TRUE),
	    );

            $this->Dosen_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success 2');
            redirect(site_url('dosen'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Dosen_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('dosen/update_action'),
		'id_sdm' => set_value('id_sdm', $row->id_sdm),
		'nm_sdm' => set_value('nm_sdm', $row->nm_sdm),
		'jk' => set_value('jk', $row->jk),
		'tmpt_lahir' => set_value('tmpt_lahir', $row->tmpt_lahir),
		'tgl_lahir' => set_value('tgl_lahir', $row->tgl_lahir),
		'nm_ibu_kandung' => set_value('nm_ibu_kandung', $row->nm_ibu_kandung),
		'stat_kawin' => set_value('stat_kawin', $row->stat_kawin),
		'nik' => set_value('nik', $row->nik),
		'nip' => set_value('nip', $row->nip),
		'niy_nigk' => set_value('niy_nigk', $row->niy_nigk),
		'nuptk' => set_value('nuptk', $row->nuptk),
		'nidn' => set_value('nidn', $row->nidn),
		'nsdmi' => set_value('nsdmi', $row->nsdmi),
		'jln' => set_value('jln', $row->jln),
		'rt' => set_value('rt', $row->rt),
		'rw' => set_value('rw', $row->rw),
		'nm_dsn' => set_value('nm_dsn', $row->nm_dsn),
		'ds_kel' => set_value('ds_kel', $row->ds_kel),
		'kode_pos' => set_value('kode_pos', $row->kode_pos),
		'no_tel_rmh' => set_value('no_tel_rmh', $row->no_tel_rmh),
		'no_hp' => set_value('no_hp', $row->no_hp),
		'email' => set_value('email', $row->email),
		'tmt_pns' => set_value('tmt_pns', $row->tmt_pns),
		'nm_suami_istri' => set_value('nm_suami_istri', $row->nm_suami_istri),
		'nip_suami_istri' => set_value('nip_suami_istri', $row->nip_suami_istri),
		'sk_cpns' => set_value('sk_cpns', $row->sk_cpns),
		'tgl_sk_cpns' => set_value('tgl_sk_cpns', $row->tgl_sk_cpns),
		'sk_angkat' => set_value('sk_angkat', $row->sk_angkat),
		'tmt_sk_angkat' => set_value('tmt_sk_angkat', $row->tmt_sk_angkat),
		'npwp' => set_value('npwp', $row->npwp),
		'nm_wp' => set_value('nm_wp', $row->nm_wp),
		'stat_data' => set_value('stat_data', $row->stat_data),
		'a_lisensi_kepsek' => set_value('a_lisensi_kepsek', $row->a_lisensi_kepsek),
		'a_braille' => set_value('a_braille', $row->a_braille),
		'a_bhs_isyarat' => set_value('a_bhs_isyarat', $row->a_bhs_isyarat),
		'jml_sekolah_binaan' => set_value('jml_sekolah_binaan', $row->jml_sekolah_binaan),
		'a_diklat_awas' => set_value('a_diklat_awas', $row->a_diklat_awas),
		'akta_ijin_ajar' => set_value('akta_ijin_ajar', $row->akta_ijin_ajar),
		'nira' => set_value('nira', $row->nira),
		'kewarganegaraan' => set_value('kewarganegaraan', $row->kewarganegaraan),
		'id_jns_sdm' => set_value('id_jns_sdm', $row->id_jns_sdm),
		'id_wil' => set_value('id_wil', $row->id_wil),
		'id_stat_aktif' => set_value('id_stat_aktif', $row->id_stat_aktif),
		'id_blob' => set_value('id_blob', $row->id_blob),
		'id_agama' => set_value('id_agama', $row->id_agama),
		'id_keahlian_lab' => set_value('id_keahlian_lab', $row->id_keahlian_lab),
		'id_pekerjaan_suami_istri' => set_value('id_pekerjaan_suami_istri', $row->id_pekerjaan_suami_istri),
		'id_sumber_gaji' => set_value('id_sumber_gaji', $row->id_sumber_gaji),
		'id_lemb_angkat' => set_value('id_lemb_angkat', $row->id_lemb_angkat),
		'id_pangkat_gol' => set_value('id_pangkat_gol', $row->id_pangkat_gol),
		'mampu_handle_kk' => set_value('mampu_handle_kk', $row->mampu_handle_kk),
		'id_bid_pengawas' => set_value('id_bid_pengawas', $row->id_bid_pengawas),
	    );
            $this->template->load('template','dosen/dosen_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('dosen'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_sdm', TRUE));
        } else {
            $data = array(
		'nm_sdm' => $this->input->post('nm_sdm',TRUE),
		'jk' => $this->input->post('jk',TRUE),
		'tmpt_lahir' => $this->input->post('tmpt_lahir',TRUE),
		'tgl_lahir' => $this->input->post('tgl_lahir',TRUE),
		'nm_ibu_kandung' => $this->input->post('nm_ibu_kandung',TRUE),
		'stat_kawin' => $this->input->post('stat_kawin',TRUE),
		'nik' => $this->input->post('nik',TRUE),
		'nip' => $this->input->post('nip',TRUE),
		'niy_nigk' => $this->input->post('niy_nigk',TRUE),
		'nuptk' => $this->input->post('nuptk',TRUE),
		'nidn' => $this->input->post('nidn',TRUE),
		'nsdmi' => $this->input->post('nsdmi',TRUE),
		'jln' => $this->input->post('jln',TRUE),
		'rt' => $this->input->post('rt',TRUE),
		'rw' => $this->input->post('rw',TRUE),
		'nm_dsn' => $this->input->post('nm_dsn',TRUE),
		'ds_kel' => $this->input->post('ds_kel',TRUE),
		'kode_pos' => $this->input->post('kode_pos',TRUE),
		'no_tel_rmh' => $this->input->post('no_tel_rmh',TRUE),
		'no_hp' => $this->input->post('no_hp',TRUE),
		'email' => $this->input->post('email',TRUE),
		'tmt_pns' => $this->input->post('tmt_pns',TRUE),
		'nm_suami_istri' => $this->input->post('nm_suami_istri',TRUE),
		'nip_suami_istri' => $this->input->post('nip_suami_istri',TRUE),
		'sk_cpns' => $this->input->post('sk_cpns',TRUE),
		'tgl_sk_cpns' => $this->input->post('tgl_sk_cpns',TRUE),
		'sk_angkat' => $this->input->post('sk_angkat',TRUE),
		'tmt_sk_angkat' => $this->input->post('tmt_sk_angkat',TRUE),
		'npwp' => $this->input->post('npwp',TRUE),
		'nm_wp' => $this->input->post('nm_wp',TRUE),
		'stat_data' => $this->input->post('stat_data',TRUE),
		'a_lisensi_kepsek' => $this->input->post('a_lisensi_kepsek',TRUE),
		'a_braille' => $this->input->post('a_braille',TRUE),
		'a_bhs_isyarat' => $this->input->post('a_bhs_isyarat',TRUE),
		'jml_sekolah_binaan' => $this->input->post('jml_sekolah_binaan',TRUE),
		'a_diklat_awas' => $this->input->post('a_diklat_awas',TRUE),
		'akta_ijin_ajar' => $this->input->post('akta_ijin_ajar',TRUE),
		'nira' => $this->input->post('nira',TRUE),
		'kewarganegaraan' => $this->input->post('kewarganegaraan',TRUE),
		'id_jns_sdm' => $this->input->post('id_jns_sdm',TRUE),
		'id_wil' => $this->input->post('id_wil',TRUE),
		'id_stat_aktif' => $this->input->post('id_stat_aktif',TRUE),
		'id_blob' => $this->input->post('id_blob',TRUE),
		'id_agama' => $this->input->post('id_agama',TRUE),
		'id_keahlian_lab' => $this->input->post('id_keahlian_lab',TRUE),
		'id_pekerjaan_suami_istri' => $this->input->post('id_pekerjaan_suami_istri',TRUE),
		'id_sumber_gaji' => $this->input->post('id_sumber_gaji',TRUE),
		'id_lemb_angkat' => $this->input->post('id_lemb_angkat',TRUE),
		'id_pangkat_gol' => $this->input->post('id_pangkat_gol',TRUE),
		'mampu_handle_kk' => $this->input->post('mampu_handle_kk',TRUE),
		'id_bid_pengawas' => $this->input->post('id_bid_pengawas',TRUE),
	    );

            $this->Dosen_model->update($this->input->post('id_sdm', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('dosen'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Dosen_model->get_by_id($id);

        if ($row) {
            $this->Dosen_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('dosen'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('dosen'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('nm_sdm', 'nm sdm', 'trim|required');
	$this->form_validation->set_rules('jk', 'jk', 'trim|required');
	$this->form_validation->set_rules('tmpt_lahir', 'tmpt lahir', 'trim|required');
	$this->form_validation->set_rules('tgl_lahir', 'tgl lahir', 'trim|required');
	$this->form_validation->set_rules('nm_ibu_kandung', 'nm ibu kandung', 'trim|required');
	$this->form_validation->set_rules('stat_kawin', 'stat kawin', 'trim|required|numeric');
	$this->form_validation->set_rules('nik', 'nik', 'trim|required');
	$this->form_validation->set_rules('nip', 'nip', 'trim|required');
	$this->form_validation->set_rules('niy_nigk', 'niy nigk', 'trim|required');
	$this->form_validation->set_rules('nuptk', 'nuptk', 'trim|required');
	$this->form_validation->set_rules('nidn', 'nidn', 'trim|required');
	$this->form_validation->set_rules('nsdmi', 'nsdmi', 'trim|required');
	$this->form_validation->set_rules('jln', 'jln', 'trim|required');
	$this->form_validation->set_rules('rt', 'rt', 'trim|required|numeric');
	$this->form_validation->set_rules('rw', 'rw', 'trim|required|numeric');
	$this->form_validation->set_rules('nm_dsn', 'nm dsn', 'trim|required');
	$this->form_validation->set_rules('ds_kel', 'ds kel', 'trim|required');
	$this->form_validation->set_rules('kode_pos', 'kode pos', 'trim|required');
	$this->form_validation->set_rules('no_tel_rmh', 'no tel rmh', 'trim|required');
	$this->form_validation->set_rules('no_hp', 'no hp', 'trim|required');
	$this->form_validation->set_rules('email', 'email', 'trim|required');
	$this->form_validation->set_rules('tmt_pns', 'tmt pns', 'trim|required');
	$this->form_validation->set_rules('nm_suami_istri', 'nm suami istri', 'trim|required');
	$this->form_validation->set_rules('nip_suami_istri', 'nip suami istri', 'trim|required');
	$this->form_validation->set_rules('sk_cpns', 'sk cpns', 'trim|required');
	$this->form_validation->set_rules('tgl_sk_cpns', 'tgl sk cpns', 'trim|required');
	$this->form_validation->set_rules('sk_angkat', 'sk angkat', 'trim|required');
	$this->form_validation->set_rules('tmt_sk_angkat', 'tmt sk angkat', 'trim|required');
	$this->form_validation->set_rules('npwp', 'npwp', 'trim|required');
	$this->form_validation->set_rules('nm_wp', 'nm wp', 'trim|required');
	$this->form_validation->set_rules('stat_data', 'stat data', 'trim|required');
	$this->form_validation->set_rules('a_lisensi_kepsek', 'a lisensi kepsek', 'trim|required|numeric');
	$this->form_validation->set_rules('a_braille', 'a braille', 'trim|required|numeric');
	$this->form_validation->set_rules('a_bhs_isyarat', 'a bhs isyarat', 'trim|required|numeric');
	$this->form_validation->set_rules('jml_sekolah_binaan', 'jml sekolah binaan', 'trim|required');
	$this->form_validation->set_rules('a_diklat_awas', 'a diklat awas', 'trim|required|numeric');
	$this->form_validation->set_rules('akta_ijin_ajar', 'akta ijin ajar', 'trim|required');
	$this->form_validation->set_rules('nira', 'nira', 'trim|required');
	$this->form_validation->set_rules('kewarganegaraan', 'kewarganegaraan', 'trim|required');
	$this->form_validation->set_rules('id_jns_sdm', 'id jns sdm', 'trim|required|numeric');
	$this->form_validation->set_rules('id_wil', 'id wil', 'trim|required');
	$this->form_validation->set_rules('id_stat_aktif', 'id stat aktif', 'trim|required|numeric');
	$this->form_validation->set_rules('id_blob', 'id blob', 'trim|required');
	$this->form_validation->set_rules('id_agama', 'id agama', 'trim|required');
	$this->form_validation->set_rules('id_keahlian_lab', 'id keahlian lab', 'trim|required');
	$this->form_validation->set_rules('id_pekerjaan_suami_istri', 'id pekerjaan suami istri', 'trim|required');
	$this->form_validation->set_rules('id_sumber_gaji', 'id sumber gaji', 'trim|required|numeric');
	$this->form_validation->set_rules('id_lemb_angkat', 'id lemb angkat', 'trim|required|numeric');
	$this->form_validation->set_rules('id_pangkat_gol', 'id pangkat gol', 'trim|required|numeric');
	$this->form_validation->set_rules('mampu_handle_kk', 'mampu handle kk', 'trim|required');
	$this->form_validation->set_rules('id_bid_pengawas', 'id bid pengawas', 'trim|required');

	$this->form_validation->set_rules('id_sdm', 'id_sdm', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "dosen.xls";
        $judul = "dosen";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Sdm");
	xlsWriteLabel($tablehead, $kolomhead++, "Jk");
	xlsWriteLabel($tablehead, $kolomhead++, "Tmpt Lahir");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Lahir");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Ibu Kandung");
	xlsWriteLabel($tablehead, $kolomhead++, "Stat Kawin");
	xlsWriteLabel($tablehead, $kolomhead++, "Nik");
	xlsWriteLabel($tablehead, $kolomhead++, "Nip");
	xlsWriteLabel($tablehead, $kolomhead++, "Niy Nigk");
	xlsWriteLabel($tablehead, $kolomhead++, "Nuptk");
	xlsWriteLabel($tablehead, $kolomhead++, "Nidn");
	xlsWriteLabel($tablehead, $kolomhead++, "Nsdmi");
	xlsWriteLabel($tablehead, $kolomhead++, "Jln");
	xlsWriteLabel($tablehead, $kolomhead++, "Rt");
	xlsWriteLabel($tablehead, $kolomhead++, "Rw");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Dsn");
	xlsWriteLabel($tablehead, $kolomhead++, "Ds Kel");
	xlsWriteLabel($tablehead, $kolomhead++, "Kode Pos");
	xlsWriteLabel($tablehead, $kolomhead++, "No Tel Rmh");
	xlsWriteLabel($tablehead, $kolomhead++, "No Hp");
	xlsWriteLabel($tablehead, $kolomhead++, "Email");
	xlsWriteLabel($tablehead, $kolomhead++, "Tmt Pns");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Suami Istri");
	xlsWriteLabel($tablehead, $kolomhead++, "Nip Suami Istri");
	xlsWriteLabel($tablehead, $kolomhead++, "Sk Cpns");
	xlsWriteLabel($tablehead, $kolomhead++, "Tgl Sk Cpns");
	xlsWriteLabel($tablehead, $kolomhead++, "Sk Angkat");
	xlsWriteLabel($tablehead, $kolomhead++, "Tmt Sk Angkat");
	xlsWriteLabel($tablehead, $kolomhead++, "Npwp");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Wp");
	xlsWriteLabel($tablehead, $kolomhead++, "Stat Data");
	xlsWriteLabel($tablehead, $kolomhead++, "A Lisensi Kepsek");
	xlsWriteLabel($tablehead, $kolomhead++, "A Braille");
	xlsWriteLabel($tablehead, $kolomhead++, "A Bhs Isyarat");
	xlsWriteLabel($tablehead, $kolomhead++, "Jml Sekolah Binaan");
	xlsWriteLabel($tablehead, $kolomhead++, "A Diklat Awas");
	xlsWriteLabel($tablehead, $kolomhead++, "Akta Ijin Ajar");
	xlsWriteLabel($tablehead, $kolomhead++, "Nira");
	xlsWriteLabel($tablehead, $kolomhead++, "Kewarganegaraan");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Jns Sdm");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Wil");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Stat Aktif");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Blob");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Agama");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Keahlian Lab");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Pekerjaan Suami Istri");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Sumber Gaji");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Lemb Angkat");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Pangkat Gol");
	xlsWriteLabel($tablehead, $kolomhead++, "Mampu Handle Kk");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Bid Pengawas");

	foreach ($this->Dosen_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_sdm);
	    xlsWriteLabel($tablebody, $kolombody++, $data->jk);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tmpt_lahir);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_lahir);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_ibu_kandung);
	    xlsWriteNumber($tablebody, $kolombody++, $data->stat_kawin);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nik);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nip);
	    xlsWriteLabel($tablebody, $kolombody++, $data->niy_nigk);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nuptk);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nidn);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nsdmi);
	    xlsWriteLabel($tablebody, $kolombody++, $data->jln);
	    xlsWriteNumber($tablebody, $kolombody++, $data->rt);
	    xlsWriteNumber($tablebody, $kolombody++, $data->rw);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_dsn);
	    xlsWriteLabel($tablebody, $kolombody++, $data->ds_kel);
	    xlsWriteLabel($tablebody, $kolombody++, $data->kode_pos);
	    xlsWriteLabel($tablebody, $kolombody++, $data->no_tel_rmh);
	    xlsWriteLabel($tablebody, $kolombody++, $data->no_hp);
	    xlsWriteLabel($tablebody, $kolombody++, $data->email);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tmt_pns);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_suami_istri);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nip_suami_istri);
	    xlsWriteLabel($tablebody, $kolombody++, $data->sk_cpns);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tgl_sk_cpns);
	    xlsWriteLabel($tablebody, $kolombody++, $data->sk_angkat);
	    xlsWriteLabel($tablebody, $kolombody++, $data->tmt_sk_angkat);
	    xlsWriteLabel($tablebody, $kolombody++, $data->npwp);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_wp);
	    xlsWriteNumber($tablebody, $kolombody++, $data->stat_data);
	    xlsWriteNumber($tablebody, $kolombody++, $data->a_lisensi_kepsek);
	    xlsWriteNumber($tablebody, $kolombody++, $data->a_braille);
	    xlsWriteNumber($tablebody, $kolombody++, $data->a_bhs_isyarat);
	    xlsWriteNumber($tablebody, $kolombody++, $data->jml_sekolah_binaan);
	    xlsWriteNumber($tablebody, $kolombody++, $data->a_diklat_awas);
	    xlsWriteLabel($tablebody, $kolombody++, $data->akta_ijin_ajar);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nira);
	    xlsWriteLabel($tablebody, $kolombody++, $data->kewarganegaraan);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_jns_sdm);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_wil);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_stat_aktif);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_blob);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_agama);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_keahlian_lab);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_pekerjaan_suami_istri);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_sumber_gaji);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_lemb_angkat);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_pangkat_gol);
	    xlsWriteNumber($tablebody, $kolombody++, $data->mampu_handle_kk);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_bid_pengawas);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=dosen.doc");

        $data = array(
            'dosen_data' => $this->Dosen_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('dosen/dosen_doc',$data);
    }

}

/* End of file Dosen.php */
/* Location: ./application/controllers/Dosen.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-22 09:20:18 */
/* http://harviacode.com */