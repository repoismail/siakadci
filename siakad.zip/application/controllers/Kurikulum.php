<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Kurikulum extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        is_login();
        $this->load->model('Kurikulum_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->template->load('template','kurikulum/kurikulum_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Kurikulum_model->json();
    }

    public function read($id) 
    {
        $row = $this->Kurikulum_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_kurikulum_sp' => $row->id_kurikulum_sp,
		'id_sms' => $row->id_sms,
		'id_jenj_didik' => $row->id_jenj_didik,
		'id_smt' => $row->id_smt,
		'nm_kurikulum_sp' => $row->nm_kurikulum_sp,
		'jml_sem_normal' => $row->jml_sem_normal,
		'jml_sks_lulus' => $row->jml_sks_lulus,
		'jml_sks_wajib' => $row->jml_sks_wajib,
		'jml_sks_pilihan' => $row->jml_sks_pilihan,
	    );
            $this->template->load('template','kurikulum/kurikulum_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('kurikulum'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('kurikulum/create_action'),
	    'id_kurikulum_sp' => set_value('id_kurikulum_sp'),
	    'id_sms' => set_value('id_sms'),
	    'id_jenj_didik' => set_value('id_jenj_didik'),
	    'id_smt' => set_value('id_smt'),
	    'nm_kurikulum_sp' => set_value('nm_kurikulum_sp'),
	    'jml_sem_normal' => set_value('jml_sem_normal'),
	    'jml_sks_lulus' => set_value('jml_sks_lulus'),
	    'jml_sks_wajib' => set_value('jml_sks_wajib'),
	    'jml_sks_pilihan' => set_value('jml_sks_pilihan'),
	);
        $this->template->load('template','kurikulum/kurikulum_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'id_sms' => $this->input->post('id_sms',TRUE),
		'id_jenj_didik' => $this->input->post('id_jenj_didik',TRUE),
		'id_smt' => $this->input->post('id_smt',TRUE),
		'nm_kurikulum_sp' => $this->input->post('nm_kurikulum_sp',TRUE),
		'jml_sem_normal' => $this->input->post('jml_sem_normal',TRUE),
		'jml_sks_lulus' => $this->input->post('jml_sks_lulus',TRUE),
		'jml_sks_wajib' => $this->input->post('jml_sks_wajib',TRUE),
		'jml_sks_pilihan' => $this->input->post('jml_sks_pilihan',TRUE),
	    );

            $this->Kurikulum_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success 2');
            redirect(site_url('kurikulum'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Kurikulum_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('kurikulum/update_action'),
		'id_kurikulum_sp' => set_value('id_kurikulum_sp', $row->id_kurikulum_sp),
		'id_sms' => set_value('id_sms', $row->id_sms),
		'id_jenj_didik' => set_value('id_jenj_didik', $row->id_jenj_didik),
		'id_smt' => set_value('id_smt', $row->id_smt),
		'nm_kurikulum_sp' => set_value('nm_kurikulum_sp', $row->nm_kurikulum_sp),
		'jml_sem_normal' => set_value('jml_sem_normal', $row->jml_sem_normal),
		'jml_sks_lulus' => set_value('jml_sks_lulus', $row->jml_sks_lulus),
		'jml_sks_wajib' => set_value('jml_sks_wajib', $row->jml_sks_wajib),
		'jml_sks_pilihan' => set_value('jml_sks_pilihan', $row->jml_sks_pilihan),
	    );
            $this->template->load('template','kurikulum/kurikulum_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('kurikulum'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_kurikulum_sp', TRUE));
        } else {
            $data = array(
		'id_sms' => $this->input->post('id_sms',TRUE),
		'id_jenj_didik' => $this->input->post('id_jenj_didik',TRUE),
		'id_smt' => $this->input->post('id_smt',TRUE),
		'nm_kurikulum_sp' => $this->input->post('nm_kurikulum_sp',TRUE),
		'jml_sem_normal' => $this->input->post('jml_sem_normal',TRUE),
		'jml_sks_lulus' => $this->input->post('jml_sks_lulus',TRUE),
		'jml_sks_wajib' => $this->input->post('jml_sks_wajib',TRUE),
		'jml_sks_pilihan' => $this->input->post('jml_sks_pilihan',TRUE),
	    );

            $this->Kurikulum_model->update($this->input->post('id_kurikulum_sp', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('kurikulum'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Kurikulum_model->get_by_id($id);

        if ($row) {
            $this->Kurikulum_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('kurikulum'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('kurikulum'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_sms', 'id sms', 'trim|required');
	$this->form_validation->set_rules('id_jenj_didik', 'id jenj didik', 'trim|required');
	$this->form_validation->set_rules('id_smt', 'id smt', 'trim|required');
	$this->form_validation->set_rules('nm_kurikulum_sp', 'nm kurikulum sp', 'trim|required');
	$this->form_validation->set_rules('jml_sem_normal', 'jml sem normal', 'trim|required|numeric');
	$this->form_validation->set_rules('jml_sks_lulus', 'jml sks lulus', 'trim|required|numeric');
	$this->form_validation->set_rules('jml_sks_wajib', 'jml sks wajib', 'trim|required|numeric');
	$this->form_validation->set_rules('jml_sks_pilihan', 'jml sks pilihan', 'trim|required|numeric');

	$this->form_validation->set_rules('id_kurikulum_sp', 'id_kurikulum_sp', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "kurikulum.xls";
        $judul = "kurikulum";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Sms");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Jenj Didik");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Smt");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Kurikulum Sp");
	xlsWriteLabel($tablehead, $kolomhead++, "Jml Sem Normal");
	xlsWriteLabel($tablehead, $kolomhead++, "Jml Sks Lulus");
	xlsWriteLabel($tablehead, $kolomhead++, "Jml Sks Wajib");
	xlsWriteLabel($tablehead, $kolomhead++, "Jml Sks Pilihan");

	foreach ($this->Kurikulum_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_sms);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_jenj_didik);
	    xlsWriteLabel($tablebody, $kolombody++, $data->id_smt);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_kurikulum_sp);
	    xlsWriteNumber($tablebody, $kolombody++, $data->jml_sem_normal);
	    xlsWriteNumber($tablebody, $kolombody++, $data->jml_sks_lulus);
	    xlsWriteNumber($tablebody, $kolombody++, $data->jml_sks_wajib);
	    xlsWriteNumber($tablebody, $kolombody++, $data->jml_sks_pilihan);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=kurikulum.doc");

        $data = array(
            'kurikulum_data' => $this->Kurikulum_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('kurikulum/kurikulum_doc',$data);
    }

}

/* End of file Kurikulum.php */
/* Location: ./application/controllers/Kurikulum.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-23 00:12:57 */
/* http://harviacode.com */