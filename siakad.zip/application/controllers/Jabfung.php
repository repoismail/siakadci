<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Jabfung extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        is_login();
        $this->load->model('Jabfung_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->template->load('template','jabfung/jabfung_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Jabfung_model->json();
    }

    public function read($id) 
    {
        $row = $this->Jabfung_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_jabfung' => $row->id_jabfung,
		'id_kel_prof' => $row->id_kel_prof,
		'nm_jabfung' => $row->nm_jabfung,
		'angka_kredit' => $row->angka_kredit,
	    );
            $this->template->load('template','jabfung/jabfung_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('jabfung'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('jabfung/create_action'),
	    'id_jabfung' => set_value('id_jabfung'),
	    'id_kel_prof' => set_value('id_kel_prof'),
	    'nm_jabfung' => set_value('nm_jabfung'),
	    'angka_kredit' => set_value('angka_kredit'),
	);
        $this->template->load('template','jabfung/jabfung_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'id_kel_prof' => $this->input->post('id_kel_prof',TRUE),
		'nm_jabfung' => $this->input->post('nm_jabfung',TRUE),
		'angka_kredit' => $this->input->post('angka_kredit',TRUE),
	    );

            $this->Jabfung_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success 2');
            redirect(site_url('jabfung'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Jabfung_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('jabfung/update_action'),
		'id_jabfung' => set_value('id_jabfung', $row->id_jabfung),
		'id_kel_prof' => set_value('id_kel_prof', $row->id_kel_prof),
		'nm_jabfung' => set_value('nm_jabfung', $row->nm_jabfung),
		'angka_kredit' => set_value('angka_kredit', $row->angka_kredit),
	    );
            $this->template->load('template','jabfung/jabfung_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('jabfung'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_jabfung', TRUE));
        } else {
            $data = array(
		'id_kel_prof' => $this->input->post('id_kel_prof',TRUE),
		'nm_jabfung' => $this->input->post('nm_jabfung',TRUE),
		'angka_kredit' => $this->input->post('angka_kredit',TRUE),
	    );

            $this->Jabfung_model->update($this->input->post('id_jabfung', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('jabfung'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Jabfung_model->get_by_id($id);

        if ($row) {
            $this->Jabfung_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('jabfung'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('jabfung'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('id_kel_prof', 'id kel prof', 'trim|required');
	$this->form_validation->set_rules('nm_jabfung', 'nm jabfung', 'trim|required');
	$this->form_validation->set_rules('angka_kredit', 'angka kredit', 'trim|required|numeric');

	$this->form_validation->set_rules('id_jabfung', 'id_jabfung', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "jabfung.xls";
        $judul = "jabfung";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Id Kel Prof");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Jabfung");
	xlsWriteLabel($tablehead, $kolomhead++, "Angka Kredit");

	foreach ($this->Jabfung_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteNumber($tablebody, $kolombody++, $data->id_kel_prof);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_jabfung);
	    xlsWriteNumber($tablebody, $kolombody++, $data->angka_kredit);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=jabfung.doc");

        $data = array(
            'jabfung_data' => $this->Jabfung_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('jabfung/jabfung_doc',$data);
    }

}

/* End of file Jabfung.php */
/* Location: ./application/controllers/Jabfung.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-22 09:34:24 */
/* http://harviacode.com */