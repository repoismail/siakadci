<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Penghasilan extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        is_login();
        $this->load->model('Penghasilan_model');
        $this->load->library('form_validation');        
	$this->load->library('datatables');
    }

    public function index()
    {
        $this->template->load('template','penghasilan/penghasilan_list');
    } 
    
    public function json() {
        header('Content-Type: application/json');
        echo $this->Penghasilan_model->json();
    }

    public function read($id) 
    {
        $row = $this->Penghasilan_model->get_by_id($id);
        if ($row) {
            $data = array(
		'id_penghasilan' => $row->id_penghasilan,
		'nm_penghasilan' => $row->nm_penghasilan,
		'batas_bawah' => $row->batas_bawah,
		'batas_atas' => $row->batas_atas,
	    );
            $this->template->load('template','penghasilan/penghasilan_read', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('penghasilan'));
        }
    }

    public function create() 
    {
        $data = array(
            'button' => 'Create',
            'action' => site_url('penghasilan/create_action'),
	    'id_penghasilan' => set_value('id_penghasilan'),
	    'nm_penghasilan' => set_value('nm_penghasilan'),
	    'batas_bawah' => set_value('batas_bawah'),
	    'batas_atas' => set_value('batas_atas'),
	);
        $this->template->load('template','penghasilan/penghasilan_form', $data);
    }
    
    public function create_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->create();
        } else {
            $data = array(
		'nm_penghasilan' => $this->input->post('nm_penghasilan',TRUE),
		'batas_bawah' => $this->input->post('batas_bawah',TRUE),
		'batas_atas' => $this->input->post('batas_atas',TRUE),
	    );

            $this->Penghasilan_model->insert($data);
            $this->session->set_flashdata('message', 'Create Record Success 2');
            redirect(site_url('penghasilan'));
        }
    }
    
    public function update($id) 
    {
        $row = $this->Penghasilan_model->get_by_id($id);

        if ($row) {
            $data = array(
                'button' => 'Update',
                'action' => site_url('penghasilan/update_action'),
		'id_penghasilan' => set_value('id_penghasilan', $row->id_penghasilan),
		'nm_penghasilan' => set_value('nm_penghasilan', $row->nm_penghasilan),
		'batas_bawah' => set_value('batas_bawah', $row->batas_bawah),
		'batas_atas' => set_value('batas_atas', $row->batas_atas),
	    );
            $this->template->load('template','penghasilan/penghasilan_form', $data);
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('penghasilan'));
        }
    }
    
    public function update_action() 
    {
        $this->_rules();

        if ($this->form_validation->run() == FALSE) {
            $this->update($this->input->post('id_penghasilan', TRUE));
        } else {
            $data = array(
		'nm_penghasilan' => $this->input->post('nm_penghasilan',TRUE),
		'batas_bawah' => $this->input->post('batas_bawah',TRUE),
		'batas_atas' => $this->input->post('batas_atas',TRUE),
	    );

            $this->Penghasilan_model->update($this->input->post('id_penghasilan', TRUE), $data);
            $this->session->set_flashdata('message', 'Update Record Success');
            redirect(site_url('penghasilan'));
        }
    }
    
    public function delete($id) 
    {
        $row = $this->Penghasilan_model->get_by_id($id);

        if ($row) {
            $this->Penghasilan_model->delete($id);
            $this->session->set_flashdata('message', 'Delete Record Success');
            redirect(site_url('penghasilan'));
        } else {
            $this->session->set_flashdata('message', 'Record Not Found');
            redirect(site_url('penghasilan'));
        }
    }

    public function _rules() 
    {
	$this->form_validation->set_rules('nm_penghasilan', 'nm penghasilan', 'trim|required');
	$this->form_validation->set_rules('batas_bawah', 'batas bawah', 'trim|required');
	$this->form_validation->set_rules('batas_atas', 'batas atas', 'trim|required');

	$this->form_validation->set_rules('id_penghasilan', 'id_penghasilan', 'trim');
	$this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');
    }

    public function excel()
    {
        $this->load->helper('exportexcel');
        $namaFile = "penghasilan.xls";
        $judul = "penghasilan";
        $tablehead = 0;
        $tablebody = 1;
        $nourut = 1;
        //penulisan header
        header("Pragma: public");
        header("Expires: 0");
        header("Cache-Control: must-revalidate, post-check=0,pre-check=0");
        header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream");
        header("Content-Type: application/download");
        header("Content-Disposition: attachment;filename=" . $namaFile . "");
        header("Content-Transfer-Encoding: binary ");

        xlsBOF();

        $kolomhead = 0;
        xlsWriteLabel($tablehead, $kolomhead++, "No");
	xlsWriteLabel($tablehead, $kolomhead++, "Nm Penghasilan");
	xlsWriteLabel($tablehead, $kolomhead++, "Batas Bawah");
	xlsWriteLabel($tablehead, $kolomhead++, "Batas Atas");

	foreach ($this->Penghasilan_model->get_all() as $data) {
            $kolombody = 0;

            //ubah xlsWriteLabel menjadi xlsWriteNumber untuk kolom numeric
            xlsWriteNumber($tablebody, $kolombody++, $nourut);
	    xlsWriteLabel($tablebody, $kolombody++, $data->nm_penghasilan);
	    xlsWriteNumber($tablebody, $kolombody++, $data->batas_bawah);
	    xlsWriteNumber($tablebody, $kolombody++, $data->batas_atas);

	    $tablebody++;
            $nourut++;
        }

        xlsEOF();
        exit();
    }

    public function word()
    {
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=penghasilan.doc");

        $data = array(
            'penghasilan_data' => $this->Penghasilan_model->get_all(),
            'start' => 0
        );
        
        $this->load->view('penghasilan/penghasilan_doc',$data);
    }

}

/* End of file Penghasilan.php */
/* Location: ./application/controllers/Penghasilan.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-22 23:59:35 */
/* http://harviacode.com */