<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Dosen_model extends CI_Model
{

    public $table = 'dosen';
    public $id = 'id_sdm';
    public $order = 'DESC';

    function __construct()
    {
        parent::__construct();
    }

    // datatables
    function json() {
        $this->datatables->select('id_sdm,nm_sdm,jk,tmpt_lahir,tgl_lahir,nm_ibu_kandung,stat_kawin,nik,nip,niy_nigk,nuptk,nidn,nsdmi,jln,rt,rw,nm_dsn,ds_kel,kode_pos,no_tel_rmh,no_hp,email,tmt_pns,nm_suami_istri,nip_suami_istri,sk_cpns,tgl_sk_cpns,sk_angkat,tmt_sk_angkat,npwp,nm_wp,stat_data,a_lisensi_kepsek,a_braille,a_bhs_isyarat,jml_sekolah_binaan,a_diklat_awas,akta_ijin_ajar,nira,kewarganegaraan,id_jns_sdm,id_wil,id_stat_aktif,id_blob,id_agama,id_keahlian_lab,id_pekerjaan_suami_istri,id_sumber_gaji,id_lemb_angkat,id_pangkat_gol,mampu_handle_kk,id_bid_pengawas');
        $this->datatables->from('dosen');
        //add this line for join
        //$this->datatables->join('table2', 'dosen.field = table2.field');
        $this->datatables->add_column('action', anchor(site_url('dosen/read/$1'),'<i class="fa fa-eye" aria-hidden="true"></i>', array('class' => 'btn btn-danger btn-sm'))." 
            ".anchor(site_url('dosen/update/$1'),'<i class="fa fa-pencil-square-o" aria-hidden="true"></i>', array('class' => 'btn btn-danger btn-sm'))." 
                ".anchor(site_url('dosen/delete/$1'),'<i class="fa fa-trash-o" aria-hidden="true"></i>','class="btn btn-danger btn-sm" onclick="javasciprt: return confirm(\'Are You Sure ?\')"'), 'id_sdm');
        return $this->datatables->generate();
    }

    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }
    
    // get total rows
    function total_rows($q = NULL) {
        $this->db->like('id_sdm', $q);
	$this->db->or_like('nm_sdm', $q);
	$this->db->or_like('jk', $q);
	$this->db->or_like('tmpt_lahir', $q);
	$this->db->or_like('tgl_lahir', $q);
	$this->db->or_like('nm_ibu_kandung', $q);
	$this->db->or_like('stat_kawin', $q);
	$this->db->or_like('nik', $q);
	$this->db->or_like('nip', $q);
	$this->db->or_like('niy_nigk', $q);
	$this->db->or_like('nuptk', $q);
	$this->db->or_like('nidn', $q);
	$this->db->or_like('nsdmi', $q);
	$this->db->or_like('jln', $q);
	$this->db->or_like('rt', $q);
	$this->db->or_like('rw', $q);
	$this->db->or_like('nm_dsn', $q);
	$this->db->or_like('ds_kel', $q);
	$this->db->or_like('kode_pos', $q);
	$this->db->or_like('no_tel_rmh', $q);
	$this->db->or_like('no_hp', $q);
	$this->db->or_like('email', $q);
	$this->db->or_like('tmt_pns', $q);
	$this->db->or_like('nm_suami_istri', $q);
	$this->db->or_like('nip_suami_istri', $q);
	$this->db->or_like('sk_cpns', $q);
	$this->db->or_like('tgl_sk_cpns', $q);
	$this->db->or_like('sk_angkat', $q);
	$this->db->or_like('tmt_sk_angkat', $q);
	$this->db->or_like('npwp', $q);
	$this->db->or_like('nm_wp', $q);
	$this->db->or_like('stat_data', $q);
	$this->db->or_like('a_lisensi_kepsek', $q);
	$this->db->or_like('a_braille', $q);
	$this->db->or_like('a_bhs_isyarat', $q);
	$this->db->or_like('jml_sekolah_binaan', $q);
	$this->db->or_like('a_diklat_awas', $q);
	$this->db->or_like('akta_ijin_ajar', $q);
	$this->db->or_like('nira', $q);
	$this->db->or_like('kewarganegaraan', $q);
	$this->db->or_like('id_jns_sdm', $q);
	$this->db->or_like('id_wil', $q);
	$this->db->or_like('id_stat_aktif', $q);
	$this->db->or_like('id_blob', $q);
	$this->db->or_like('id_agama', $q);
	$this->db->or_like('id_keahlian_lab', $q);
	$this->db->or_like('id_pekerjaan_suami_istri', $q);
	$this->db->or_like('id_sumber_gaji', $q);
	$this->db->or_like('id_lemb_angkat', $q);
	$this->db->or_like('id_pangkat_gol', $q);
	$this->db->or_like('mampu_handle_kk', $q);
	$this->db->or_like('id_bid_pengawas', $q);
	$this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db->order_by($this->id, $this->order);
        $this->db->like('id_sdm', $q);
	$this->db->or_like('nm_sdm', $q);
	$this->db->or_like('jk', $q);
	$this->db->or_like('tmpt_lahir', $q);
	$this->db->or_like('tgl_lahir', $q);
	$this->db->or_like('nm_ibu_kandung', $q);
	$this->db->or_like('stat_kawin', $q);
	$this->db->or_like('nik', $q);
	$this->db->or_like('nip', $q);
	$this->db->or_like('niy_nigk', $q);
	$this->db->or_like('nuptk', $q);
	$this->db->or_like('nidn', $q);
	$this->db->or_like('nsdmi', $q);
	$this->db->or_like('jln', $q);
	$this->db->or_like('rt', $q);
	$this->db->or_like('rw', $q);
	$this->db->or_like('nm_dsn', $q);
	$this->db->or_like('ds_kel', $q);
	$this->db->or_like('kode_pos', $q);
	$this->db->or_like('no_tel_rmh', $q);
	$this->db->or_like('no_hp', $q);
	$this->db->or_like('email', $q);
	$this->db->or_like('tmt_pns', $q);
	$this->db->or_like('nm_suami_istri', $q);
	$this->db->or_like('nip_suami_istri', $q);
	$this->db->or_like('sk_cpns', $q);
	$this->db->or_like('tgl_sk_cpns', $q);
	$this->db->or_like('sk_angkat', $q);
	$this->db->or_like('tmt_sk_angkat', $q);
	$this->db->or_like('npwp', $q);
	$this->db->or_like('nm_wp', $q);
	$this->db->or_like('stat_data', $q);
	$this->db->or_like('a_lisensi_kepsek', $q);
	$this->db->or_like('a_braille', $q);
	$this->db->or_like('a_bhs_isyarat', $q);
	$this->db->or_like('jml_sekolah_binaan', $q);
	$this->db->or_like('a_diklat_awas', $q);
	$this->db->or_like('akta_ijin_ajar', $q);
	$this->db->or_like('nira', $q);
	$this->db->or_like('kewarganegaraan', $q);
	$this->db->or_like('id_jns_sdm', $q);
	$this->db->or_like('id_wil', $q);
	$this->db->or_like('id_stat_aktif', $q);
	$this->db->or_like('id_blob', $q);
	$this->db->or_like('id_agama', $q);
	$this->db->or_like('id_keahlian_lab', $q);
	$this->db->or_like('id_pekerjaan_suami_istri', $q);
	$this->db->or_like('id_sumber_gaji', $q);
	$this->db->or_like('id_lemb_angkat', $q);
	$this->db->or_like('id_pangkat_gol', $q);
	$this->db->or_like('mampu_handle_kk', $q);
	$this->db->or_like('id_bid_pengawas', $q);
	$this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }

    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);
    }

    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }

    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }

}

/* End of file Dosen_model.php */
/* Location: ./application/models/Dosen_model.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-22 09:20:18 */
/* http://harviacode.com */