<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Satuan_pendidikan_model extends CI_Model
{

    public $table = 'satuan_pendidikan';
    public $id = 'id_sp';
    public $order = 'DESC';

    function __construct()
    {
        parent::__construct();
    }

    // datatables
    function json() {
        $this->datatables->select('id_sp,nm_lemb,nss,npsn,nm_singkat,jln,rt,rw,nm_dsn,ds_kel,kode_pos,lintang,bujur,no_tel,no_fax,email,website,stat_sp,sk_pendirian_sp,tgl_sk_pendirian_sp,tgl_berdiri,sk_izin_operasi,tgl_sk_izin_operasi,no_rek,nm_bank,unit_cabang,nm_rek,a_mbs,luas_tanah_milik,luas_tanah_bukan_milik,a_lptk,kode_reg,npwp,nm_wp,flag,id_pembina,id_blob,id_stat_milik,id_wil,id_kk,id_bp');
        $this->datatables->from('satuan_pendidikan');
        //add this line for join
        //$this->datatables->join('table2', 'satuan_pendidikan.field = table2.field');
        $this->datatables->add_column('action', anchor(site_url('satuanpendidikan/read/$1'),'<i class="fa fa-eye" aria-hidden="true"></i>', array('class' => 'btn btn-danger btn-sm'))." 
            ".anchor(site_url('satuanpendidikan/update/$1'),'<i class="fa fa-pencil-square-o" aria-hidden="true"></i>', array('class' => 'btn btn-danger btn-sm'))." 
                ".anchor(site_url('satuanpendidikan/delete/$1'),'<i class="fa fa-trash-o" aria-hidden="true"></i>','class="btn btn-danger btn-sm" onclick="javasciprt: return confirm(\'Are You Sure ?\')"'), 'id_sp');
        return $this->datatables->generate();
    }

    // get all
    function get_all()
    {
        $this->db->order_by($this->id, $this->order);
        return $this->db->get($this->table)->result();
    }

    // get data by id
    function get_by_id($id)
    {
        $this->db->where($this->id, $id);
        return $this->db->get($this->table)->row();
    }
    
    // get total rows
    function total_rows($q = NULL) {
        $this->db->like('id_sp', $q);
	$this->db->or_like('nm_lemb', $q);
	$this->db->or_like('nss', $q);
	$this->db->or_like('npsn', $q);
	$this->db->or_like('nm_singkat', $q);
	$this->db->or_like('jln', $q);
	$this->db->or_like('rt', $q);
	$this->db->or_like('rw', $q);
	$this->db->or_like('nm_dsn', $q);
	$this->db->or_like('ds_kel', $q);
	$this->db->or_like('kode_pos', $q);
	$this->db->or_like('lintang', $q);
	$this->db->or_like('bujur', $q);
	$this->db->or_like('no_tel', $q);
	$this->db->or_like('no_fax', $q);
	$this->db->or_like('email', $q);
	$this->db->or_like('website', $q);
	$this->db->or_like('stat_sp', $q);
	$this->db->or_like('sk_pendirian_sp', $q);
	$this->db->or_like('tgl_sk_pendirian_sp', $q);
	$this->db->or_like('tgl_berdiri', $q);
	$this->db->or_like('sk_izin_operasi', $q);
	$this->db->or_like('tgl_sk_izin_operasi', $q);
	$this->db->or_like('no_rek', $q);
	$this->db->or_like('nm_bank', $q);
	$this->db->or_like('unit_cabang', $q);
	$this->db->or_like('nm_rek', $q);
	$this->db->or_like('a_mbs', $q);
	$this->db->or_like('luas_tanah_milik', $q);
	$this->db->or_like('luas_tanah_bukan_milik', $q);
	$this->db->or_like('a_lptk', $q);
	$this->db->or_like('kode_reg', $q);
	$this->db->or_like('npwp', $q);
	$this->db->or_like('nm_wp', $q);
	$this->db->or_like('flag', $q);
	$this->db->or_like('id_pembina', $q);
	$this->db->or_like('id_blob', $q);
	$this->db->or_like('id_stat_milik', $q);
	$this->db->or_like('id_wil', $q);
	$this->db->or_like('id_kk', $q);
	$this->db->or_like('id_bp', $q);
	$this->db->from($this->table);
        return $this->db->count_all_results();
    }

    // get data with limit and search
    function get_limit_data($limit, $start = 0, $q = NULL) {
        $this->db->order_by($this->id, $this->order);
        $this->db->like('id_sp', $q);
	$this->db->or_like('nm_lemb', $q);
	$this->db->or_like('nss', $q);
	$this->db->or_like('npsn', $q);
	$this->db->or_like('nm_singkat', $q);
	$this->db->or_like('jln', $q);
	$this->db->or_like('rt', $q);
	$this->db->or_like('rw', $q);
	$this->db->or_like('nm_dsn', $q);
	$this->db->or_like('ds_kel', $q);
	$this->db->or_like('kode_pos', $q);
	$this->db->or_like('lintang', $q);
	$this->db->or_like('bujur', $q);
	$this->db->or_like('no_tel', $q);
	$this->db->or_like('no_fax', $q);
	$this->db->or_like('email', $q);
	$this->db->or_like('website', $q);
	$this->db->or_like('stat_sp', $q);
	$this->db->or_like('sk_pendirian_sp', $q);
	$this->db->or_like('tgl_sk_pendirian_sp', $q);
	$this->db->or_like('tgl_berdiri', $q);
	$this->db->or_like('sk_izin_operasi', $q);
	$this->db->or_like('tgl_sk_izin_operasi', $q);
	$this->db->or_like('no_rek', $q);
	$this->db->or_like('nm_bank', $q);
	$this->db->or_like('unit_cabang', $q);
	$this->db->or_like('nm_rek', $q);
	$this->db->or_like('a_mbs', $q);
	$this->db->or_like('luas_tanah_milik', $q);
	$this->db->or_like('luas_tanah_bukan_milik', $q);
	$this->db->or_like('a_lptk', $q);
	$this->db->or_like('kode_reg', $q);
	$this->db->or_like('npwp', $q);
	$this->db->or_like('nm_wp', $q);
	$this->db->or_like('flag', $q);
	$this->db->or_like('id_pembina', $q);
	$this->db->or_like('id_blob', $q);
	$this->db->or_like('id_stat_milik', $q);
	$this->db->or_like('id_wil', $q);
	$this->db->or_like('id_kk', $q);
	$this->db->or_like('id_bp', $q);
	$this->db->limit($limit, $start);
        return $this->db->get($this->table)->result();
    }

    // insert data
    function insert($data)
    {
        $this->db->insert($this->table, $data);
    }

    // update data
    function update($id, $data)
    {
        $this->db->where($this->id, $id);
        $this->db->update($this->table, $data);
    }

    // delete data
    function delete($id)
    {
        $this->db->where($this->id, $id);
        $this->db->delete($this->table);
    }

}

/* End of file Satuan_pendidikan_model.php */
/* Location: ./application/models/Satuan_pendidikan_model.php */
/* Please DO NOT modify this information : */
/* Generated by Harviacode Codeigniter CRUD Generator 2020-10-22 23:58:03 */
/* http://harviacode.com */